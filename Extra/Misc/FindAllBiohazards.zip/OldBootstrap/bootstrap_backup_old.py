from pathlib import Path as áÌî
moon_dir = áÌî('/home/ganer/Projects/Moon_BETA')
__dir__=(__file__:=áÌî(moon_dir/'/home/ganer/Projects/Moon_BETA/Header/base.☾')).parent
import os, sys, inspect, traceback, threading
from threading import get_ident as áÐèþÂÐðþáÐØ
from os import environ as env
from sys import stdin, stdout, stderr, setrecursionlimit, path as syspath, exit, argv as áÑË
from math import *
from site import getsitepackages
from json import dumps as jdumps__, loads as jloads__
from time import time, sleep
from cmath import *
from types import UnionType
from random import shuffle, choice, uniform, randint
from tempfile import gettempdir
from builtins import setattr as setattr_
from operator import setitem as setitem_, __gt__, __lt__, __ge__, __le__, rshift, lshift, getitem, delitem
from itertools import chain, filterfalse, product, accumulate, zip_longest
from functools import partial as MOD, reduce, cache
from pickle import dumps as pdump, loads as pload
from zlib import compress as zibe, decompress as zibd
from base64 import b85encode as b85e, b85decode as b85d
getattr(syspath, 'extend')(getsitepackages())
setrecursionlimit(100000)
del (getsitepackages, factorial, e, pi, tau, sqrt, cbrt, pow)
(setattr := (lambda x, y, z: setattr_(x, y, z) or z))
(setitem := (lambda x, y, z: setitem_(x, y, z) or z))
(ÄÊSTK := {})
(ÄÊPSH := (lambda x: getattr(getattr(ÄÊSTK, 'setdefault')(áÐèþÂÐðþáÐØ(), []), 'append')(x) or x))
(ÄÊPKE := (lambda x=0: getattr(ÄÊSTK, 'setdefault')(áÐèþÂÐðþáÐØ(), [])[-1 - x]))
(ÄÊPOP := (lambda x=0: getattr(getattr(ÄÊSTK, 'setdefault')(áÐèþÂÐðþáÐØ(), []), 'pop')(-1 - x)))
(ÄÊDEL := (lambda x: getattr(getattr(ÄÊSTK, 'setdefault')(áÐèþÂÐðþáÐØ(), []), '__delitem__')(slice(-x, None))))
(ÂÞÅCAT := (lambda x, y: y(x) if callable(y) else x * y))

def ÄÊCUR(áÍÊ, áÍÅ, *áÎç):

    def Ëðá(*áÌú):
        if len(áÌú) < len(áÍÊ):
            return lambda *áÑË: Ëðá(*áÌú, *áÑË)
        (ÄÊPSH(([*áÎç], {**áÍÅ})), ((áÖÒ := ÄÊPKE(0)[0]), (áÖÝ := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
        for k, v in zip(áÍÊ, áÌú):
            (ÄÊPSH(áÖÒ if isinstance(k, int) else áÖÝ), ÄÊPSH(k), ÄÊPSH(v), setitem(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3]
        return áÖÒ[0](*áÖÒ[slice(1, None)], *áÌú[slice(len(áÍÊ), None)], **áÖÝ)
    return Ëðá()
(ÄÊPSH((Exception, object, dict, bool, list, tuple, set, str, int, float, bytes)), ((áÍÚ := ÄÊPKE(0)[0]), (áÍä := ÄÊPKE(0)[1]), (áÍÙ := ÄÊPKE(0)[2]), (áÍÖ := ÄÊPKE(0)[3]), (áÍá := ÄÊPKE(0)[4]), (áÍé := ÄÊPKE(0)[5]), (áÍè := ÄÊPKE(0)[6]), (ÁÜÙ := ÄÊPKE(0)[7]), (áÍÞ := ÄÊPKE(0)[8]), (áÍÛ := ÄÊPKE(0)[9]), (áÍî := ÄÊPKE(0)[10])), ÄÊDEL(1))[1]
(ÁØã := '')
(ÄÊPSH((1 / 2, 1 / 3, 1 / 4, 1 / 5, 1 / 6, 1 / 7, 1 / 8, 1 / 9, 1 / 10, 2 / 3, 2 / 5, 2 / 7, 2 / 9, 3 / 4, 3 / 5, 3 / 7, 3 / 8, 3 / 10, 4 / 5, 4 / 7, 4 / 9, 5 / 6, 5 / 7, 5 / 8, 5 / 9, 6 / 7, 7 / 8, 7 / 9, 7 / 10, 8 / 9, 9 / 10, 0, 1 / 100)), ((ÃÆ := ÄÊPKE(0)[0]), (ÂÑõ := ÄÊPKE(0)[1]), (ÃÅ := ÄÊPKE(0)[2]), (ÂÑø := ÄÊPKE(0)[3]), (ÂÑü := ÄÊPKE(0)[4]), (ÂÑò := ÄÊPKE(0)[5]), (ÂÑÿ := ÄÊPKE(0)[6]), (ÂÑó := ÄÊPKE(0)[7]), (ÂÑô := ÄÊPKE(0)[8]), (ÂÑö := ÄÊPKE(0)[9]), (ÂÑù := ÄÊPKE(0)[10]), (ÄÝóú := ÄÊPKE(0)[11]), (ÄÝôÀ := ÄÊPKE(0)[12]), (ÃÇ := ÄÊPKE(0)[13]), (ÂÑú := ÄÊPKE(0)[14]), (ÄÝóû := ÄÊPKE(0)[15]), (ÂÒÀ := ÄÊPKE(0)[16]), (ÄÝôÏ := ÄÊPKE(0)[17]), (ÂÑû := ÄÊPKE(0)[18]), (ÄÝóü := ÄÊPKE(0)[19]), (ÄÝôË := ÄÊPKE(0)[20]), (ÂÑý := ÄÊPKE(0)[21]), (ÄÝóý := ÄÊPKE(0)[22]), (ÂÒÁ := ÄÊPKE(0)[23]), (ÄÝôÂ := ÄÊPKE(0)[24]), (ÄÝóÿ := ÄÊPKE(0)[25]), (ÂÒÂ := ÄÊPKE(0)[26]), (ÄÝôÃ := ÄÊPKE(0)[27]), (ÄÝôÐ := ÄÊPKE(0)[28]), (ÄÝôÄ := ÄÊPKE(0)[29]), (ÄÝôÑ := ÄÊPKE(0)[30]), (ÂÒî := ÄÊPKE(0)[31]), (ÄÝôÒ := ÄÊPKE(0)[32])), ÄÊDEL(1))[1]
(ÄÊPSH((3.141592653589793, 2.718281828459045)), ((Ïî := ÄÊPKE(0)[0]), (ÂÐæ := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
(ÄÊPSH((inf, complex(0, 1), ÂÞÅCAT(2, Ïî), ÂÞÅCAT(ÃÆ, Ïî), ÂÞÅCAT(ÃÅ, Ïî), ÂÞÅCAT(ÂÑÿ, Ïî))), ((ÂÕË := ÄÊPKE(0)[0]), (Ãù := ÄÊPKE(0)[1]), (Ïò := ÄÊPKE(0)[2]), (ÄÝøà := ÄÊPKE(0)[3]), (ÄÝøá := ÄÊPKE(0)[4]), (ÄÝøâ := ÄÊPKE(0)[5])), ÄÊDEL(1))[1]
(ÄÊPSH((-ÂÕË, -Ãù, -Ïò, -Ïî, -ÄÝøà, -ÄÝøá, -ÄÝøâ, -ÂÐæ)), ((ÄÝîá := ÄÊPKE(0)[0]), (ÄÝîâ := ÄÊPKE(0)[1]), (ÄÝîä := ÄÊPKE(0)[2]), (ÄÝîå := ÄÊPKE(0)[3]), (ÄÝîæ := ÄÊPKE(0)[4]), (ÄÝîç := ÄÊPKE(0)[5]), (ÄÝîè := ÄÊPKE(0)[6]), (ÄÝîã := ÄÊPKE(0)[7])), ÄÊDEL(1))[1]
(ÂÒå := (2 ** 3 ** 4))
(ÄÊPSH((lambda *áÑË: áÑË[0], lambda *áÑË: áÑË[-1])), ((Âåß := ÄÊPKE(0)[0]), (ÂåÔ := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]

class Named:
    (ÄÊPSH((lambda áÑÞ, s: ÂåÔ((ÄÊPSH(s), ÄÊPSH(áÑÞ), ÄÊPSH('s'), setattr(ÄÊPKE(1), ÄÊPKE(0), ÄÊPKE(2)), ÄÊDEL(3))[3], None), lambda áÑÞ: getattr(áÑÞ, 's'))), ((__init__ := ÄÊPKE(0)[0]), (__repr__ := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
(ÂÞÅ := (NULL := Named('␀')))
(ÄÊPSH((Named('\U000f0b88'), Named('\U000f18e9'), Named('⬤'))), ((ÄÔýò := ÄÊPKE(0)[0]), (ÄÕøü := ÄÊPKE(0)[1]), (ÂýÃ := ÄÊPKE(0)[2])), ÄÊDEL(1))[1]

class ÂÐô:
    None
(ÂÑÅ := áÍÞ)
(ÂÐý := (áÍÛ | ÂÑÅ))
(ÂÐá := complex)
(ÂÁÍ := (lambda Æå, *áÑË, **áÑÕ: lambda *áÑË, **áÑÕ: Æå(áÑË[1], áÑË[0], *áÑË[slice(2, None)], **áÑÕ) if ãÊú(áÑË) >= 2 else Æå(*áÑË, **áÑÕ)))
(ÂÖë := (lambda Æå, *áÑË, **áÑÕ: lambda *áÑË, **áÑÕ: Æå(*áÑË[0], **áÑÕ)))
(ãÊú := len)
(ÄÕÍÔ := (lambda *áÑË, áØÁ=ÂÞÅ: (áÑË[0] if áØÁ is ÂÞÅ else áØÁ) if áÑË else (lambda *áÑË: áÑË[0] if áÑË else ÄÕÍÔ) if áØÁ is ÂÞÅ else lambda *áÑË: áØÁ))
(CUR := (lambda Æå, *áÖÒ, **áÖÝ: Æå(*áÖÒ, **áÖÝ) if ãÊú(áÖÒ) >= 2 else lambda *áÖÓ, **áÖÞ: CUR(Æå, *áÖÒ, *áÖÓ, **áÖÝ | áÖÞ)))
(CURR := (lambda Æå, *áÖÒ, **áÖÝ: Æå(*áÖÒ, **áÖÝ) if ãÊú(áÖÒ) >= 2 else lambda *áÖÓ, **áÖÞ: CUR(Æå, áÖÓ[0], *áÖÒ, *áÖÓ[slice(1, None)], **áÖÝ | áÖÞ)))
(ÁØò := (ÁÙÇ := (lambda Æå: lambda áØÆ, *áÖÒ, **áÖÝ: [áÑÿ for v in áØÆ if (áÑÿ := Æå(v, *áÖÒ, **áÖÝ)) is not ÄÔýò])))
(ÁØÿþÁÙÄ := (lambda Æå: Æå))
(ÁØòþÁÙÄ := (lambda Æå: lambda áØÆ, áØÇ, *áÖÒ, **áÖÝ: [áÑÿ for x in áØÆ if (áÑÿ := Æå(x, áØÇ, *áÖÒ, **áÖÝ)) is not ÄÔýò]))
(ÁØÿþÁÙÇ := (lambda Æå: lambda áØÆ, áØÇ, *áÖÒ, **áÖÝ: [áÑÿ for y in áØÇ if (áÑÿ := Æå(áØÆ, y, *áÖÒ, **áÖÝ)) is not ÄÔýò]))
(ÁØòþÁÙÇ := (lambda Æå: lambda áØÆ, áØÇ, *áÖÒ, **áÖÝ: [áÑÿ for x, y in ÄÕåØ(áØÆ, áØÇ) if (áÑÿ := Æå(x, y, *áÖÒ, **áÖÝ)) is not ÄÔýò]))
(ÄÊPSH((lambda x, y: (False if y else x) if x else y, lambda x, y: (y if y else False) if x else x if y else True)), ((ÄÝøø := ÄÊPKE(0)[0]), (ÄÝøú := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
(ÂÕÕ := (Âùè := (lambda x, y: x or y)))
(ÄÝøù := (ÄÝùÀ := (lambda x, y: not (x or y))))
(ÂÕÔ := (Âùç := (lambda x, y: x and y)))
(ÄÝøå := (ÄÝùÁ := (lambda x, y: (False if y else x) if x else y if y else True)))
(ÄÊPSH((__lt__, __gt__, __le__, __ge__)), ((ÿ := ÄÊPKE(0)[0]), (ÁÁ := ÄÊPKE(0)[1]), (ÂÖÔ := ÄÊPKE(0)[2]), (ÂÖÕ := ÄÊPKE(0)[3])), ÄÊDEL(1))[1]
(ÄÊPSH((lambda x, y: x == y, lambda x, y: x != y)), ((ÂÖÑ := ÄÊPKE(0)[0]), (ÂÖÐ := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
(ÄÊPSH((lambda x, y: gcd(x, y) == x, lambda x, y: gcd(x, y) != x)), ((ÂÕÐ := ÄÊPKE(0)[0]), (ÂÕÑ := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
(ÄÊPSH((lambda x, y: x in y, lambda x, y: x not in y)), ((ÂÔó := ÄÊPKE(0)[0]), (ÂÔô := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
(ÄÊPSH((lambda x, y: y in x, lambda x, y: y not in x)), ((ÂÔö := ÄÊPKE(0)[0]), (ÂÔø := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
(ÄÊPSH((lambda x, y: getattr({*x}, 'issubset')({*y}), lambda x, y: getattr({*y}, 'issubset')({*x}))), ((ÂÖó := ÄÊPKE(0)[0]), (ÂÖô := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
(ÄÊPSH((lambda x, y: not ÂÖó(x, y), lambda x, y: not ÂÖô(x, y))), ((ÂÖõ := ÄÊPKE(0)[0]), (ÂÖö := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
(ÄÊPSH((lambda x, y: getattr((Ïß := {*x}), 'issubset')((Ïà := {*y})) and Ïß != Ïà, lambda x, y: getattr((Ïß := {*y}), 'issubset')((Ïà := {*x})) and Ïß != Ïà)), ((ÂÖü := ÄÊPKE(0)[0]), (ÂÖý := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
(ÄÊPSH((lambda x, y: not ÂÖü(x, y), lambda x, y: not ÂÖý(x, y))), ((ÄÝøÄ := ÄÊPKE(0)[0]), (ÄÝøÅ := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
(ÄÝöú := (lambda x, y: ÂÕÃ(ÂÕØ(x, y), ÂÕÖ(x, y))))
(ÂÕØ := (lambda x, y: {*x} | {*y} if ÁØö(x, áÍè) else [*x, *[z for z in y if z not in x]]))
(ÂÕÖ := (lambda x, y: {*x} & {*y} if ÁØö(x, áÍè) else [z for z in x if z in y]))
(ÂÕÃ := (lambda x, y: x - {*y} if ÁØö(x, áÍè) else [z for z in x if z not in y]))
(ÂøÚ := (lambda áØÆ=ÂÞÅ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ: Áÿú(product(*([áØÆ] * áØÁ if áØÇ is ÂÞÅ and áØÁ is not ÂÞÅ else (áØÆ if áØÇ is ÂÞÅ else [áØÆ, áØÇ]) * (1 if áØÁ is ÂÞÅ else áØÁ))), áÍá)))
(ÂØÑ := (lambda *áÑË, áØÁ=1: (Æå := (lambda *áÑË, n=1, r=[]: (lambda ÂîÓ: Áÿú(ÂîÓ[0], lambda x: Æå(*ÂîÓ[slice(1, None)], r=r + [áØÆ]) if ãÊú(ÂîÓ) > 1 else r + [áØÆ]))(áÑË * n)))(*áÑË, n=áØÁ)))
(ÄÊPSH((lambda x, y: x % y, lambda x, y: x // y)), ((æ := ÄÊPKE(0)[0]), (ÃËÕ := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
(ÄÊPSH((lambda x, y: x is y, lambda x, y: x is not y)), ((ÂÕó := ÄÊPKE(0)[0]), (ÂÕõ := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
(ÄÊPSH((lambda x: ~x, lambda x, y: x @ y)), ((ÂÄ := ÄÊPKE(0)[0]), (ÁÃ := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
(ÄÊPSH((lambda x, y: x | y, lambda x, y: x & y, lambda x, y: x ^ y)), ((ÂÂ := ÄÊPKE(0)[0]), (ç := ÄÊPKE(0)[1]), (Áâ := ÄÊPKE(0)[2])), ÄÊDEL(1))[1]
(ÄÊPSH((lshift, rshift)), ((Âúù := ÄÊPKE(0)[0]), (Âúú := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
(ÄÊPSH((lambda x, y: x ** y, lambda x: not x, lambda áØÆ, áØÁ=ÂÞÅ: lambda x: MOD(î, áØÁ=áØÁ)(áØÆ))), ((ÂÙû := ÄÊPKE(0)[0]), (Âó := ÄÊPKE(0)[1]), (Âö := ÄÊPKE(0)[2])), ÄÊDEL(1))[1]
(ÂÀÇ := (lambda áØÆ: ÄÝöì(ÂÀÇ(ÄÝöì(áØÆ))) if ÁØö(áØÆ, áÍÞ) else áØÆ[slice(None, None, -1)] if ÁØö(áØÆ, ÁÜÙ | áÍá | áÍé) else getattr(áØÆ, '__reversed__')() if hasattr(áØÆ, '__reversed__') else [*áØÆ][slice(None, None, -1)]))
(ÄÝöí := (lambda áØÆ=ÂÞÅ, áØÁ=ÂÞÅ: chr(áØÆ) if ÁØö(áØÆ, áÍÞ) else ord(áØÆ) if ÁØö(áØÆ, ÁÜÙ) and (ãÊú(áØÆ) == 1 and áØÁ is not áÍá) else MOD(Áëý, áØÁ=ÁØö(áØÆ[0], áÍÞ))(Áÿú(áØÆ, ÄÝöí), Âøî)))
(ÂÛê := (lambda áØÆ, áØÁ=ÂÞÅ: MOD(ÂÛê, áØÁ=ÂÔö(áØÆ, '\u205f') * '\u205f' + '\u2009')(áØÆ) if áØÁ is ÂÞÅ else MOD(Áëý, áØÁ=ãÊú(áØÁ) > 1)(getattr(áØÆ, 'split')(áØÁ[0]), MOD(ÁØò(lambda ÂîÓ: MOD(ÂÛê, áØÁ=áØÁ[slice(1, None)])(ÂîÓ))))))
(Âäû := (lambda áØÆ, áØÁ=ÂÞÅ: ÄÝõé(Áÿú(ÄÝõé(áØÆ), MOD(Âäû, áØÁ=áØÁ))) if MOD(ÁØö, áØÁ=ÂÕó)(áØÆ, ÂÐá) else áÍÞ(round(áØÆ)) if áØÁ is ÂÞÅ else round(áØÆ, áØÁ)))
(ÄÊPSH((floor, ceil)), ((Âüð := ÄÊPKE(0)[0]), (Âüï := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
(ÄÊPSH((lambda áØÆ: getattr(áØÆ, 'real'), lambda áØÆ: getattr(áØÆ, 'imag'))), ((ÄÝõè := ÄÊPKE(0)[0]), (ÄÝõç := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
(ÄÝõé := (lambda áØÆ: ÂÐá(*áØÆ) if ÁØö(áØÆ, áÍá | áÍé) else (ÄÝõè(áØÆ), ÄÝõç(áØÆ))))
(ÂÛÅ := (lambda áØÆ, áØÁ=ÂÞÅ: MOD(ÄÕåØ, áØÁ=áØÁ)(áØÆ)))
(Âüá := getattr(ÁÜÙ, 'strip'))
(ÂÌú := (lambda áØÆ, áØÇ: [*range(áØÆ, áØÇ)]))
(ÂÕÀ := (lambda áØÆ=ÂÞÅ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ: (MOD(î, áØÁ=áØÁ)(áØÆ), MOD(ì, áØÁ=áØÁ)(áØÆ)) if áØÇ is ÂÞÅ else (MOD(î, áØÁ=áØÁ)(áØÆ, áØÇ), MOD(ì, áØÁ=áØÁ)(áØÆ, áØÇ))))
(Âù := (lambda áØÆ=ÂÞÅ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ: (MOD(ì, áØÁ=áØÁ)(áØÆ), MOD(î, áØÁ=áØÁ)(áØÆ)) if áØÇ is ÂÞÅ else (MOD(ì, áØÁ=áØÁ)(áØÆ, áØÇ), MOD(î, áØÁ=áØÁ)(áØÆ, áØÇ))))

def ì(áØÆ=ÂÞÅ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ):
    (v := (+áØÆ if áØÇ is ÂÞÅ else áØÆ + áØÇ))
    return v if áØÁ is ÂÞÅ else v % MOD(Áëý, áØÁ=áÓö)(áØÁ, ãÊú)

def î(áØÆ=ÂÞÅ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ):
    (v := (-áØÆ if áØÇ is ÂÞÅ else áØÆ - áØÇ))
    return v if áØÁ is ÂÞÅ else v % MOD(Áëý, áØÁ=áÓö)(áØÁ, ãÊú)

def ÂØú(áØÆ=ÂÞÅ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ):
    return áØÆ * áØÇ if áØÁ is ÂÞÅ else áØÆ * áØÇ % MOD(Áëý, áØÁ=áÓö)(áØÁ, ãÊú)

def ÄÃ(áØÆ=ÂÞÅ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ):
    return áØÆ / áØÇ if áØÁ is ÂÞÅ else áØÆ / áØÇ % MOD(Áëý, áØÁ=áÓö)(áØÁ, ãÊú)

def ÃËÕ(áØÆ=ÂÞÅ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ):
    return áØÆ // áØÇ if áØÁ is ÂÞÅ else MOD(ÂÙû, áØÁ=-MOD(Áëý, áØÁ=áÓö)(áØÁ, ãÊú))(áØÆ, áØÇ)

def ÂÙû(áØÆ=ÂÞÅ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ):
    return áØÆ ** áØÇ if áØÁ is ÂÞÅ else pow(áØÆ, áØÇ, MOD(Áëý, áØÁ=áÓö)(áØÁ, ãÊú))

def ÐÌü(Æå, *áÑË, **áÑÕ):
    if áÓó(Æå):
        return Æå(*áÑË, **áÑÕ)
    if áÓö(Æå):
        for x in Æå:
            None
        return Æå
    ÂùÆ(False, '%s is not iterable or callable.' % (Æå,))

def ÂØô(áÍÒ, áØÁ=True):
    for áØÁ in áÍÒ:
        if not áØÁ:
            break
    return áØÁ

def ÂØõ(áÍÒ, áØÁ=False):
    for áØÁ in áÍÒ:
        if áØÁ:
            break
    return áØÁ

class Ticker:
    (__slots__ := ('i',))
    (__init__ := (lambda áÑÞ, i: ÂåÔ((ÄÊPSH(áÑÞ), ÄÊPSH('i'), ÄÊPSH(i), setattr(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3], None)))
    (__call__ := (lambda áÑÞ, *áÑË, **áÑÕ: ÂåÔ((ÄÊPSH(áÑÞ), ÄÊPSH('i'), ÄÊPSH(getattr(ÄÊPKE(1), ÄÊPKE(0))), ÄÊPSH(ÄÊPKE(0) - 1), setattr(ÄÊPKE(3), ÄÊPKE(2), ÄÊPKE(0)), ÄÊDEL(4))[4], áÑÞ)))
    (__bool__ := (lambda áÑÞ: not getattr(áÑÞ, 'i')))
    (__repr__ := (lambda áÑÞ: 'Ticker[i=%s]' % (getattr(áÑÞ, 'i'),)))

class TimerState:
    (__init__ := (lambda áÑÞ, áÓË: ÂåÔ((ÄÊPSH(áÑÞ), ÄÊPSH('áÓË'), ÄÊPSH(áÓË), setattr(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3], None)))
    (__bool__ := (lambda áÑÞ: getattr(getattr(áÑÞ, 'áÓË'), 's')))
    (__call__ := (lambda áÑÞ: getattr(getattr(áÑÞ, 'áÓË'), 'r') if áÑÞ else ÐÌü(getattr(getattr(getattr(áÑÞ, 'áÓË'), 'r'), 'copy'))))
    (__repr__ := (lambda áÑÞ: 'Timer[%s; %ss; %s; %s Remaining loops]=%s' % ('ID'[getattr(getattr(áÑÞ, 'áÓË'), 'y') >= 0], ÂüÌ(getattr(getattr(áÑÞ, 'áÓË'), 'y')), 'Running' if áÑÞ else 'Completed', getattr(getattr(áÑÞ, 'áÓË'), 'n'), getattr(getattr(áÑÞ, 'áÓË'), 'r'))))
(tmp := {'ᴍ': 'Áÿú', 'ꟿ': 'ËãÂ', 'ſ': 'ÆÑ', 'Ϝ': 'ÐÌ', '\U000f0233': 'ÄÔÔè', '\U000f0232': 'ÄÔÔç', '\ueb86': 'ÐÌÛ', '\U000f04bc': 'ÄÔàÑ', '\U000f04bd': 'ÄÔàÒ', 'ᙎ': 'Ááæ', 'ᙡ': 'Ááú', 'ᗢ': 'Áßô', 'ᙧ': 'ÁâÁ', '⊚': 'ÂØÍ', '⊜': 'ÂØÏ', '🟕': 'ãéÜ', '🟖': 'ãéÝ', '⊛': 'ÂØÎ', '⍟': 'ÂÛÜ', '○': 'Âåæ', '⍜': 'ÂÛÙ', '\U000f0b2b': 'ÄÔüÑ', '\U000f0b29': 'ÄÔüÏ', '\uf071': 'ÐâÄ', '\U000f0536': 'ÄÔâÑ', '\uea6c': 'ÐÇò', '\U000f147c': 'ÄÕåØ', '\U000f7e45': 'ÄÝöÔ', '⪡': 'Âúù', '⪢': 'Âúú', '\U000f0e35': 'ÄÕÊÂ', '\U000f0e37': 'ÄÕÊÄ', '⤉': 'ÂóÍ', '⤈': 'ÂóÌ', '⟷': 'Âîí', '\U000f7e4c': 'ÄÝöÜ', '\U000f7e4d': 'ÄÝöÝ', '\U000f7e4e': 'ÄÝöÞ', '\U000f7e39': 'ÄÝöÈ', '\U000f7e3a': 'ÄÝöÉ', '\U000f7e38': 'ÄÝöÇ', '\U000f7e3b': 'ÄÝöÊ', '⨝': 'Âøî', '⟕': 'ÂîÊ', '⟖': 'ÂîË', '⟗': 'ÂîÌ', '⫰': 'ÂüÌ', '⫯': 'ÂüË', '\U000f7e52': 'ÄÝöâ', '\U000f7e53': 'ÄÝöã', '\U000f7e54': 'ÄÝöä', '\U000f7e55': 'ÄÝöå', '\U000f7e56': 'ÄÝöæ', '\U000f7e13': 'ÄÝõà', '\U000f7e3c': 'ÄÝöË', '\U000f7e14': 'ÄÝõá', '\ue270': 'ÏäÒ', '\U000f114f': 'ÄÕØÃ', '\uf074': 'ÐâÇ'})
(ENC := 'ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõöøùúûüýÿ')
(RCD := CURR(lambda ÂîÓ, ÂîÒ: ÂîÓ not in ÂîÒ, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_'))
(SPE := (lambda ÂîÓ: ÂîÓ in ENC + 'þ'))
(PEV := (lambda ÂîÓ: Âøî(MOD(ÄÔÔç, áØÁ=Âåæ(Âøî, MOD(ÁØò(lambda ÂîÓ: ÄÝöì(ÄÝöí(ÂîÓ), ãÊú(ENC), C=ENC)))))(áÇù(ÂîÓ, RCD), lambda ÂîÓ: ÂÞÅCAT(ÂîÓ[0], RCD)), 'Þ')))
(VEP := (lambda ÂîÓ: Âøî(MOD(ÄÔÔç, áØÁ=lambda ÂîÓ: Âøî(ÁØò(lambda ÂîÓ: MOD(Áëý, áØÁ=ÄÊCUR((1,), {}, ÂÖó, ÂýÃ, ENC))(ÂîÓ, ÄÔâÑ(Âåæ(Âåæ(Âøî, ÄÝöí), ÄÊCUR((1,), {'C': ENC}, ÄÝöì, ÂýÃ)), lambda x: '⸮%s?' % (x,))))(ÄÝöÞ(ÂîÓ, 'þ'))))(áÇù(ÂîÓ, SPE), lambda ÂîÓ: ÂÞÅCAT(ÂîÓ[0], SPE)))))

def OPWRAP_(*áÖê):

    def R(Æå):
        for x in áÖê:
            (ÄÊPSH(globals()), ÄÊPSH(tmp[x] if x in tmp else PEV(x)), ÄÊPSH(MOD(Æå, x)), setitem(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3]
    return R
(ÄÊPSH((callable, lambda x: hasattr(x, '__iter__'))), ((áÓó := ÄÊPKE(0)[0]), (áÓö := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]

def áÓõ(x):
    try:
        return hash(x)
    except:
        pass
    return False
(áÍÇ := (lambda x, y='utf-8', *áÑË, **áÑÕ: getattr(x, 'encode')(y, *áÑË, **áÑÕ) if ÁØö(x, ÁÜÙ) else getattr(x, 'decode')(y, *áÑË, **áÑÕ)))

class ÃÆë(áÍÞ):
    (__new__ := (lambda ÂÑÎ: getattr(áÍÞ, '__new__')(ÂÑÎ, 1)))
    (__call__ := (lambda *áÑË, **áÑÕ: ÃÆë))
    (__repr__ := (lambda áÑÞ: 'ⴳ'))

class ÃÆì(áÍÞ):
    (__new__ := (lambda ÂÑÎ: getattr(áÍÞ, '__new__')(ÂÑÎ, 0)))
    (__call__ := (lambda *áÑË, **áÑÕ: ÃÆì))
    (__repr__ := (lambda áÑÞ: 'ⴴ'))
(ÃÆë := ÃÆë())
(ÃÆì := ÃÆì())

def ÂùÆ(áØÆ=ÂÞÅ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ):
    if áØÆ:
        return áØÆ
    (áØÅ := ('MOON_WARNING_IS_ERR' in env))
    (áÖð := (áØÅ or 'MOON_DEPRECATION_IS_ERR' in env))
    if áØÁ is ÄÔáô:
        (ÄÊPSH((áÖð, 'Deprecation %s' % ('Error' if áÖð else 'Warning',))), ((áÓÔ := ÄÊPKE(0)[0]), (áÓà := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    elif áØÁ is ÂÄ:
        (ÄÊPSH((áØÅ, 'Warning%s' % (' [as Error]' if áØÅ else ÁØã,))), ((áÓÔ := ÄÊPKE(0)[0]), (áÓà := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    else:
        (ÄÊPSH((True, 'Assertion failed')), ((áÓÔ := ÄÊPKE(0)[0]), (áÓà := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    (áÓà := ('%s! ⟨𝓿=%s⟩%s' % (áÓà, ÂÞÅCAT(áØÆ, repr), ' ' + áØÇ if áØÇ is not ÂÞÅ else ÁØã)))
    try:
        (áÓà := termclr(áÓà, 'f22' if áÓÔ else 'ff2'))
    except:
        None
    Âçß(áÓà)
    if áÓÔ:
        raise AssertionError
    return áØÆ

@OPWRAP_(*'\uf071\U000f0536\uea6c')
def _(t, Æå=ÂÞÅ, áÍÜ=ÂÞÅ, áØÁ=áÍÚ):
    (ÄÊPSH((áØÁ, ÂÕÃ([Æå, áÍÜ], [ÂÞÅ]))), ((áÍÎ := ÄÊPKE(0)[0]), (v := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    if ãÊú(v) == 1:
        (Æå := v[0])
        if t == '\uf071':
            raise Æå

    def r(*áÑË, **áÑÕ):
        try:
            return Æå(*áÑË, **áÑÕ)
        except áÍÎ as Ïã:
            if ãÊú(v) == 1:
                if t == '\U000f0536':
                    return áÑË[0] if áÑË else None
                if t == '\uea6c':
                    return Ïã
            if t == '\uf071':
                return áÍÜ
            if t == '\U000f0536':
                return áÍÜ(*áÑË, **áÑÕ)
            if t == '\uea6c':
                return áÍÜ(Ïã)
    return r

def Âáõ(*áÑË, áÌÄ=None):
    (ÄÊPSH(áÑË), (*(áÑË := ÄÊPKE(0)[slice(0, -1, None)]), (Æå := ÄÊPKE(0)[-1])), ÄÊDEL(1))[1]
    if not áÌÄ:
        (áÌÄ := ÂÚü())
    if not áÑË:
        return Æå(*áÌÄ)
    with áÑË[0] as áÌß:
        return getattr(áÌÄ, 'append')(áÌß) or Âáõ(*áÑË[slice(1, None)], Æå, áÌÄ=áÌÄ)

def Âçß(*áÑË, ÂìÆ=False, áÖý=' ', áØÁ='\n'):
    getattr((Æå := (stderr if ÂìÆ else stdout)), 'write')(Âøî(áÑË, ÁÜÙ(áÖý)) + ÁÜÙ(áØÁ))
    getattr(Æå, 'flush')()
    if áÑË:
        return áÑË[0]

def ÁØö(áØÆ=ÂÞÅ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ, TYPELIKE={áÓó, áÓõ, áÓö}, TYPEE=type | UnionType):
    if áØÇ is ÂÞÅ:
        return type(áØÆ)
    elif áØÇ in TYPELIKE:
        return áØÇ(áØÆ)
    if áØÁ is ÂÞÅ:
        if áØÇ is ÂÐô:
            return ÁØö(áØÆ, áÍÖ | áÍÞ) and áØÆ >= 0
        elif áØÇ is ÂÑÅ:
            return ÁØö(áØÆ, ÂÐô | áÍÞ)
        elif áØÇ is ÂÐý:
            return ÁØö(áØÆ, ÂÑÅ | ÂÐý)
        elif áØÇ is ÂÐá:
            return ÁØö(áØÆ, ÂÐý | complex)
    return isinstance(áØÆ, áØÇ if isinstance(áØÇ, TYPEE) else type(áØÇ))
(ÄÊPSH((lambda áØÆ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ: MOD(ÁØö, áØÁ=áØÁ)(áØÇ, áØÆ), lambda áØÆ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ: not MOD(ÁØö, áØÁ=áØÁ)(áØÆ, áØÇ), lambda áØÆ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ: not MOD(ÁØö, áØÁ=áØÁ)(áØÇ, áØÆ))), ((ÁØñ := ÄÊPKE(0)[0]), (ÄÝøÇ := ÄÊPKE(0)[1]), (ÄÝøÆ := ÄÊPKE(0)[2])), ÄÊDEL(1))[1]
(Âõ := (lambda áØÁ: lambda x: ÁØò(lambda ÂîÓ: ÄóÌÁ(ÂÞÅCAT(Ïò, áØÁ ** (-1)) * (ÂîÓ + ÃÆ * (áØÁ < 0))) + ÂÞÅCAT(Ãù, ÄóÌÀ(ÂÞÅCAT(Ïò, áØÁ ** (-1)) * (ÂîÓ + ÃÆ * (áØÁ < 0)))))(ÂÿÇ(ÂüÌ(áØÁ)))))
(ÂÕÇ := (lambda áØÆ=ÂÞÅ, áØÁ=2: áØÆ ** áØÁ ** (-1)))
(ÚÑ := (lambda áØÆ, áØÁ=2: ÁØò(lambda ÂîÓ: ÂîÓ * áØÆ ** áØÁ ** (-1))(MOD(Âõ, áØÁ=ÂüÌ(áØÁ)))))
(ÐàÒ := (lambda áØÆ, *áÑË, **áÑÕ: lambda *áÑË, **áÑÕ: áØÆ(*ÄÔÙù(áÑË), **áÑÕ)))
(ÂÕì := (lambda áØÆ, *áÑË, **áÑÕ: lambda *áÑË, **áÑÕ: áØÆ(*ÂÀÇ(áÑË), **áÑÕ)))
(ë := (lambda x, y: x * y))
(ð := (lambda x, y: x / y))
(ÄÔáô := áÍä())

class Holder:
    (__slots__ := ('x',))

    def __init__(áÑÞ, x=ÂÞÅ):
        (ÄÊPSH(áÑÞ), ÄÊPSH('x'), ÄÊPSH(x), setattr(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3]

    def __pos__(áÑÞ):
        return Âåß(getattr(áÑÞ, 'x'), ÂùÆ(getattr(áÑÞ, 'x') is not ÂÞÅ, 'Holder value unset!'))

    def __call__(áÑÞ, x=ÂÞÅ):
        (ÄÊPSH(áÑÞ), ÄÊPSH('x'), ÄÊPSH(x), setattr(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3]

    def __bool__(áÑÞ):
        return getattr(áÑÞ, 'x') is not ÂÞÅ
__dir__=(__file__:=áÌî(moon_dir/'/home/ganer/Projects/Moon_BETA/Header/system.☾')).parent
def PL_SLEEP(x):
    from time import sleep
    ÂÞÅCAT(x, sleep)

def PL_TIME():
    from time import time
    return ÐÌü(time)

def PL_CPU_COUNT():
    import multiprocessing
    return ÐÌü(getattr(multiprocessing, 'cpu_count'))

def PL_THREAD(Æå, *áÑË, **áÑÕ):
    from threading import Thread as T
    (atom := [])
    ÐÌü(getattr((t := T(target=lambda: ÂÞÅCAT(Æå(*áÑË, **áÑÕ), getattr(atom, 'append')))), 'start'))
    return lambda: ÂåÔ(ÐÌü(getattr(t, 'join')), atom[0])

def PL_FORK(Æå, *áÑË, **áÑÕ):
    (f := ÂÞÅCAT('/tmp/%s' % (ÂÞÅCAT(ÄÕØÃ(NULL, NULL), ÁÜÙ)[slice(2, None)],), áÌî))
    (p := ÐÌü(getattr(os, 'fork')))
    if p:
        return (p, lambda: Âåß(ÂåÔ(getattr(os, 'waitpid')(p, 0), ÂÞÅCAT(ÂÞÅCAT(f, getattr(ÐØó, 'b')), pload)), ÂÞÅCAT(f, getattr(os, 'remove'))))
    MOD(ÄÕéý, áØÁ=getattr(ÐØì, 'b'))(f, ÂÞÅCAT(Æå(*áÑË, **áÑÕ), pdump))
    ÂÞÅCAT(0, getattr(os, '_exit'))

def PL_TEXT_COPY(x):
    try:
        from clipboard import copy
        return ÐÌü(copy)
    except Exception:
        Âçß('WARNING: Failed to copy.')

def PL_TEXT_PASTE():
    try:
        from clipboard import paste
        return ÐÌü(paste)
    except Exception:
        Âçß('WARNING: Failed to paste.')

def PL_CHECK_PID(p):
    try:
        return ÂåÔ(getattr(os, 'kill')(p, 0), True)
    except Exception:
        return False
__dir__=(__file__:=áÌî(moon_dir/'/home/ganer/Projects/Moon_BETA/Header/ops_A.☾')).parent
def _map_d(x, y, n=1):
    (mapwd := (lambda x, y: [áÑÿ for z in x if (áÑÿ := y(z)) is not ÄÔýò]))

    def _get_d(x):
        if not áÓö(x):
            return {0}
        if ÁØö(x, ÁÜÙ):
            return {1}
        return {*ÁØò(lambda ÂîÓ: ÂîÓ + 1)(ÄÔÒØ([_get_d(z) for z in x]))}

    def _map_m_d(x, y, n):
        if ÁØö(x, ÁÜÙ):
            return y(x) if n == 1 else x if n else mapwd(x, y)
        if (d := _get_d(x)) in 0:
            return x if n else y(x)
        (x := mapwd(x, lambda x: _map_m_d(x, y, n)))
        return y(x) if n in d else x

    def _map_p_d(x, y, i):
        if not i:
            return y(x)
        if ÁØö(x, ÁÜÙ):
            return mapwd(x, y)
        if áÓö(x):
            return mapwd(x, lambda x: _map_p_d(x, y, i - 1))
        return y(x)
    return _map_m_d(x, y, -1 - n) if n < 0 else _map_p_d(x, y, ÂÒå if n is ÂÕË else n)

@OPWRAP_(*'ᴍꟿ')
def _(áÑã, áØÆ=ÂÞÅ, Æå=ÂÞÅ, áØÁ=1):
    (áÖß := (_map_d if áÑã == 'ᴍ' else lambda x, y, z: _map_d(x, lambda x: y(*(x if áÓö(x) else [x])), z)))
    if ÄÝøÇ(áØÁ, áÍÞ):
        if áØÁ is ë:
            return ÁØö(áØÆ)(áÖß(getattr(áØÆ, 'items')(), Æå, 1))
        elif áØÁ is î:
            return ÁØö(áØÆ)(ÄÕåØ(áÖß(getattr(áØÆ, 'items')(), Æå, 1), getattr(áØÆ, 'values')()))
        elif áØÁ is ì:
            return ÁØö(áØÆ)(ÄÕåØ(getattr(áØÆ, 'keys')(), áÖß(getattr(áØÆ, 'items')(), Æå, 1)))
    return _map_d(áØÆ, (lambda x: Æå(*(x if áÓö(x) else [x]))) if áÑã == 'ꟿ' else Æå, áØÁ)

def ÐôÅ(áØÆ=ÂÞÅ, áØÇ=ÐÌü, áØÁ=ÐÌü(PL_CPU_COUNT)):
    (ÄÊPSH(MOD(ÂÚü, áØÁ=2)()), ((P := ÄÊPKE(0)[0]), (G := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    for Æå in ÁØò(lambda ÂîÓ: lambda: PL_FORK(áØÇ, ÂîÓ))(áØÆ):
        while ãÊú((ÄÊPSH(P), ÄÊPSH(ÄÔÔç(ÄÊPKE(0), PL_CHECK_PID)), (P := ÄÊPKE(0)), ÄÊDEL(2))[2]) >= áØÁ:
            PL_SLEEP(ÄÝôÒ)
        ÁØòþÁÙÇ(lambda ÂîÓ, ÂîÒ: ÂÕÅ(getattr(ÂîÓ, 'append'), ÂîÒ))((P, G), ÐÌü(Æå))
    return Áÿú(G, ÐÌü)

@OPWRAP_(*'\U000f04bc\U000f04bd')
def _(áÑã, áØÆ=ÂÞÅ, áØÇ=ÄÕÍÔ, ÁÜñ=False):
    (áØÆ := [*áØÆ])
    (áÖê := [(áØÆ, i) for i, v in ÂÓÏ(áØÆ) if (áÑÿ := áØÇ(v)) is not ÄÔýò])
    getattr(áÖê, 'sort')(reverse=áÑã == '\U000f04bd')
    return Áÿú(áÖê, lambda x: x[1] if ÁÜñ else áØÆ[x[1]])

@OPWRAP_(*'\U000f0233\U000f0232')
def _(áÑã, áØÆ=ÂÞÅ, Æå=ÂÞÅ, áØÁ=ÂÞÅ, ÁÜñ=False):
    if ÁÜñ:
        ÂùÆ(áØÁ is not ÂÞÅ, '"%sˣᔨ" is invalid' % (áÑã,))
    (Æå := (ÄÕÍÔ if Æå is ÂÞÅ else Æå if áÓó(Æå) else CUR(lambda ÂîÓ, ÂîÒ: ÂîÓ == ÂîÒ, Æå)))
    if áÑã == '\U000f0233':
        (ÄÊPSH(Æå), ÄÊPSH(CUR(lambda ÂîÓ, ÂîÒ: not ÂîÓ(ÂîÒ), ÄÊPKE(0))), (Æå := ÄÊPKE(0)), ÄÊDEL(2))[2]
    if ÁÜñ:
        return [i for i, z in ÂÓÏ(áØÆ) if (áÑÿ := Æå(z)) and áÑÿ is not ÄÔýò]
    if áØÁ is ÂÞÅ:
        return [z for z in áØÆ if (áÑÿ := Æå(z)) and áÑÿ is not ÄÔýò]
    if áØÁ == ë:
        return [áÑÿ for z in áØÆ if (áÑÿ := Æå(z)) and áÑÿ is not ÄÔýò]
    if not áÓó(áØÁ):
        (áØÁ := MOD(ÄÕÍÔ, áØÁ=áØÁ))
    return [áØÁ(z) if áÑÿ else z for z in áØÆ if (áÑÿ := Æå(z)) is not ÄÔýò]

@OPWRAP_(*'ᙎᙡᗢᙧ')
def _(áÑã, áØÆ=ÂÞÅ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ, ÁÜñ=False):
    if ÁÜñ:
        (ÄÊPSH(áØÆ), ÄÊPSH(ÂÿÇ(ÄÊPKE(0))), (áØÆ := ÄÊPKE(0)), ÄÊDEL(2))[2]
    (chnk := 1)
    if áÓö(áØÇ) and ãÊú(áØÇ) > 2:
        (ÄÊPSH(áØÇ), (*(áØÇ := ÄÊPKE(0)[slice(0, -1, None)]), (chnk := ÄÊPKE(0)[-1])), ÄÊDEL(1))[1]
    if áØÇ is not ÂÞÅ:
        (ÄÊPSH([áØÇ, áØÇ] if ÁØö(áØÇ, áÍÞ) else áØÇ), ((áÝÍ := ÄÊPKE(0)[0]), (áÝÎ := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    elif áÑã in 'ᙎᙡ':
        (ÄÊPSH([1, 1]), ((áÝÍ := ÄÊPKE(0)[0]), (áÝÎ := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    elif áÑã in 'ᗢᙧ':
        (ÄÊPSH([1, 1] if áØÁ is ÂÞÅ else [0, áØÁ]), ((áÝÍ := ÄÊPKE(0)[0]), (áÝÎ := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    (áÝÏ := (áÑã in 'ᙡᙧ'))
    (áÝÐ := ((None if áØÁ is ÂÞÅ else áØÁ) if áÑã in 'ᙎᙡ' else ÂÞÅ))
    (áÝÑ := ((chnk if áØÁ is ÂÞÅ else áØÁ + 1) if áÑã in 'ᗢᙧ' else chnk))
    (ÄÊPSH((áØÆ, áÝÍ, áÝÎ, áÝÏ, áÝÐ, áÝÑ)), ((áÖê := ÄÊPKE(0)[0]), (l := ÄÊPKE(0)[1]), (r := ÄÊPKE(0)[2]), (m := ÄÊPKE(0)[3]), (áØÁ := ÄÊPKE(0)[4]), (ÏÁ := ÄÊPKE(0)[5])), ÄÊDEL(1))[1]
    if ÁØö(l, áÍÛ):
        (l := áÍÞ(l))
    if ÁØö(r, áÍÛ):
        (r := áÍÞ(r))
    if ÁØö(ÏÁ, áÍÛ):
        (ÏÁ := áÍÞ(ÏÁ))
    (c := ãÊú((áÖê := [*áÖê])))
    if áØÁ is ÂÞÅ:
        return Áÿú(ÂÿÇ(áÖê)[slice(l, c - r, ÏÁ)], lambda x: áÖê[slice(x - l, x)] + MOD(Âêà, áØÁ=áÍÖ(m))(áÖê[x]) + áÖê[slice(x + 1, x + r + 1)])
    (V := (MOD(Âêà, áØÁ=l)(áØÁ) + áÖê + MOD(Âêà, áØÁ=r)(áØÁ)))
    (r := Áÿú(ÂÿÇ(áÖê)[slice(None, None, ÏÁ)], lambda x: V[slice(x, x + l)] + MOD(Âêà, áØÁ=áÍÖ(m))(V[x + l]) + V[slice(x + l + 1, x + l + r + 1)]))
    if áØÁ is ÄÔýò:
        return MOD(Áÿú, áØÁ=2)(r, ÄÕÍÔ)
    return r

def ÐÌÛ(áØÆ, Æå=áÍÖ, áØÁ=ÂÞÅ, ÁÜñ=False):
    if not áÓó(Æå):
        (ÄÊPSH(Æå), ÄÊPSH(CUR(lambda ÂîÓ, ÂîÒ: ÂîÓ == ÂîÒ, ÄÊPKE(0))), (Æå := ÄÊPKE(0)), ÄÊDEL(2))[2]
    if áØÁ is not ÂÞÅ:
        (X := MOD(ÐÌÛ, ÁÜñ=ÁÜñ)(áØÆ, Æå))
        if áØÁ is ë:
            return ÄÔàÑ(getattr(X, 'items')())
        if áØÁ is ì:
            return Áÿú(ÄÔàÑ(getattr(X, 'items')()), lambda x: x[1])
        if áØÁ is áÍÖ:
            return [getattr(X, 'get')(False, ÂÚü()), getattr(X, 'get')(True, ÂÚü())]
        ÂùÆ(False, 'Invalid modifier for \ueb86!')
    (r := {})
    for i, z in ÂÓÏ(áØÆ):
        if (áÑÿ := Æå(z)) is ÄÔýò:
            continue
        if ÁÜñ:
            (z := i)
        if áÑÿ in r:
            getattr(r[áÑÿ], 'append')(z)
        else:
            (ÄÊPSH(r), ÄÊPSH(áÑÿ), ÄÊPSH([z]), setitem(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3]
    return r

def ÁÞç(áØÆ=ÂÞÅ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ):
    if áØÇ is ÂÞÅ:
        (ÄÊPSH((áØÇ, áØÆ)), ((áØÆ := ÄÊPKE(0)[0]), (áØÇ := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    ÂùÆ(áØÇ is not ÂÞÅ, 'ᖘ needs right side')

    def Æå(áØÆ):
        (áØÆ := (ÄÔÙù(áØÆ) if (is_str := ÁØö(áØÆ, ÁÜÙ)) else ÐÌü(getattr(áØÆ, 'copy')) if ÁØö(áØÆ, áÍÙ) else [*áØÆ]))
        (ÄÊPSH((MOD(Áëý, áØÁ=áÓó)(áØÁ, lambda ÂîÓ: ÂîÓ(áØÆ)), [])), ((ids := ÄÊPKE(0)[0]), (TD := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
        if (ÄÝøÆ(ÁÜÙ, ÄÊPSH(ids)) and ÁØö(ÄÊPOP(), ÄÊPSH(áÓö))) and (ÄÊDEL(1) or True) or (ÄÊDEL(1) or False):
            ÁØòþÁÙÇ(lambda ÂîÓ, ÂîÒ: getattr(TD, 'append')(ÂîÓ) if ÂîÒ is ÄÔýò else (ÄÊPSH(áØÆ), ÄÊPSH(ÂîÓ), ÄÊPSH(ÂîÒ), setitem(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3])(ids, (V := áØÇ(ÄÝöÊ(áØÆ, ids))))
        else:
            ÁØÿþÁÙÇ(lambda ÂîÓ, ÂîÒ: getattr(TD, 'append')(ÂîÓ) if ÂîÒ is ÄÔýò else (ÄÊPSH(áØÆ), ÄÊPSH(ÂîÓ), ÄÊPSH(ÂîÒ), setitem(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3])(ids, (V := Âêà(áØÇ(áØÆ[ids]))))
        for x in ÄÔàÒ(TD):
            del áØÆ[x]
        return Âøî(áØÆ, ÁØã) if is_str else áØÆ
    return Æå if áØÆ is ÂÞÅ else Æå(áØÆ)
(ÆÑ := (lambda áØÆ, áØÇ, áØÁ=ÂÞÅ: reduce(áØÇ, áØÆ, *(() if áØÁ is ÂÞÅ else (áØÁ,)))))
(ÐÌ := (lambda áØÆ, áØÇ, áØÁ=ÂÞÅ: [*accumulate(áØÆ, áØÇ, initial=None if áØÁ is ÂÞÅ else áØÁ)]))
(ÂøÑ := (lambda áØÆ, áØÁ=ÂÞÅ: (ÁØã if ÁØö(áØÆ, ÁÜÙ) else 0) if ((ÄÊDEL(1), False)[1] if ÄÊPSH(áØÆ) else ÄÊPOP() if áØÁ is not ÂÞÅ else (ÄÊDEL(1), True)[1]) else MOD(ÆÑ, áØÁ=áØÁ)(áØÆ, ì)))
(ÂøÐ := (lambda áØÆ, áØÁ=ÂÞÅ: 1 if ((ÄÊDEL(1), False)[1] if ÄÊPSH(áØÆ) else ÄÊPOP() if áØÁ is not ÂÞÅ else (ÄÊDEL(1), True)[1]) else MOD(ÆÑ, áØÁ=áØÁ)(áØÆ, ÂØú)))
(ÄÕéý := (lambda áØÆ=ÂÞÅ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ: (lambda Æå: Æå(*ÂÕÃ([áØÆ, áØÇ], [ÂÞÅ]))) if áØÁ is ÂÞÅ else áØÁ(*ÂÕÃ([áØÆ, áØÇ], [ÂÞÅ]))))
(ÂÔð := (lambda áØÁ=ÂÞÅ: áÍè() if áØÁ is ÂÞÅ else ÁØò(lambda ÂîÓ: áÍè())(ÂÿÇ(áØÁ))))
(ÂÚü := (lambda áØÁ=ÂÞÅ: áÍá() if áØÁ is ÂÞÅ else ÁØò(lambda ÂîÓ: [])(ÂÿÇ(áØÁ)) if áØÁ > 0 else ÂØÍ(Âêà, -áØÁ)([])))
__dir__=(__file__:=áÌî(moon_dir/'/home/ganer/Projects/Moon_BETA/Header/ops_B.☾')).parent
@OPWRAP_(*'⤉⤈⟷')
def _(áÑã, áØÆ=ÂÞÅ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ, ÁÜñ=False):
    if áÑã == '⟷':
        return (MOD(ÂóÌ, áØÁ=áØÁ, ÁÜñ=ÁÜñ)(áØÆ, áØÇ), MOD(ÂóÍ, áØÁ=áØÁ, ÁÜñ=ÁÜñ)(áØÆ, áØÇ))
    (áÍÛ := (ÿ if áÑã == '⤉' else ÁÁ))
    if áØÇ is ÂÞÅ:
        (ÄÊPSH((áØÆ, ÄÕÍÔ)), ((v := ÄÊPKE(0)[0]), (Æå := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    elif áÓó(áØÇ):
        (ÄÊPSH((áØÆ, áØÇ)), ((v := ÄÊPKE(0)[0]), (Æå := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    else:
        (ÄÊPSH(([áØÆ, áØÇ], ÄÕÍÔ)), ((v := ÄÊPKE(0)[0]), (Æå := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    (áÐð := (áÑÈ := (áÐø := ÂÞÅ)))
    for áÖõ, áÖî in ÂÓÏ(v):
        if not (áØÆ := Æå(áÖî)) is not ÄÔýò:
            continue
        if (ÄÊDEL(1), False)[1] if ÄÊPSH(áÑÈ is ÂÞÅ) else ÄÊPOP() if áÍÛ(áÑÈ, áØÆ) else (ÄÊDEL(1), True)[1]:
            continue
        (ÄÊPSH((áÖî, áØÆ, áÖõ)), ((áÐð := ÄÊPKE(0)[0]), (áÑÈ := ÄÊPKE(0)[1]), (áÐø := ÄÊPKE(0)[2])), ÄÊDEL(1))[1]
    return (áÐø if ÁÜñ else áÐð) if áÐð is not ÂÞÅ else áØÁ if áØÁ is not ÂÞÅ else ÐâÄ(ValueError)
(ÄÝöÓ := (lambda áØÆ, áØÇ, áØÁ=ÂÞÅ: (lambda x: ÂóÌ(ÂóÍ(áØÆ, x), áØÇ)) if áØÁ is ÂÞÅ else ÂóÌ(ÂóÍ(áØÆ, áØÁ), áØÇ)))

def ÄÔÞÔ(áØÆ, Æå=áÍÖ, áØÁ=None, ÁÜñ=False):
    if Æå is ÂÞÅ:
        (Æå := áÍÖ)
    elif ÄÝøÇ(Æå, áÓó):
        (ÄÊPSH(Æå), ÄÊPSH(CUR(lambda ÂîÓ, ÂîÒ: ÂîÓ == ÂîÒ, ÄÊPKE(0))), (Æå := ÄÊPKE(0)), ÄÊDEL(2))[2]
    for i, x in enumerate(áØÆ):
        if Æå(x):
            return i if ÁÜñ else x
    return áØÁ

@OPWRAP_(*'\U000f7e53\U000f7e54\U000f7e55\U000f7e56')
def _(áÑã, áØÆ, Æå=áÍÖ, áØÁ=ÂÞÅ, ÁÜñ=False):
    if (ÁØö(áØÆ, ÄÊPSH(ÁÜÙ)) and ÁØñ(ÄÊPOP(), ÄÊPSH(Æå))) and (ÄÊDEL(1) or True) or (ÄÊDEL(1) or False):
        (ÄÊPSH(Æå), ÄÊPSH(CUR(lambda ÂîÓ, ÂîÒ: ÂîÓ != ÂîÒ, ÄÊPKE(0))), (Æå := ÄÊPKE(0)), ÄÊDEL(2))[2]
    (áÖõ := MOD(ÄÔÞÔ, ÁÜñ=ÄÕøü)(áØÆ, Æå))
    if áÖõ is None:
        if áØÁ is not ÂÞÅ:
            return áØÁ
        return ÁØã if not ÁÜñ and ÁØö(áØÆ, ÁÜÙ) else ÂÚü()
    if ÁÜñ:
        (ÄÊPSH(áØÆ), ÄÊPSH(ÂÿÇ(ÄÊPKE(0))), (áØÆ := ÄÊPKE(0)), ÄÊDEL(2))[2]
    if áÑã == '\U000f7e53':
        return áØÆ[slice(None, áÖõ + 1)]
    if áÑã == '\U000f7e54':
        return áØÆ[slice(áÖõ, None)]
    if áÑã == '\U000f7e55':
        return áØÆ[slice(None, áÖõ)]
    if áÑã == '\U000f7e56':
        return áØÆ[slice(1 + áÖõ, None)]

def ÁãÁ(áØÆ, áØÇ=ÄÕÍÔ, ÁÜñ=False):
    (ÄÊPSH(([], [])), ((s := ÄÊPKE(0)[0]), (r := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    for i, z in ÂÓÏ(áØÆ):
        if not ((v := áØÇ(z)) not in s and v is not ÄÔýò):
            continue
        getattr(s, 'append')(v)
        getattr(r, 'append')(i if ÁÜñ else z)
    return r

def Âêà(*áÑË, áØÁ=ÂÞÅ):
    if áØÁ is ÂÞÅ:
        return [*áÑË]
    if áØÁ is áÍé:
        return áÍé(áÑË)
    return [*áÑË] * áØÁ if áØÁ >= 0 else ÂØÍ(Âêà, ÂüÌ(áØÁ))(*áÑË)
(ÂÓÏ := (lambda áØÆ, áØÁ=ÂÞÅ: Áÿú(ÂÿÇ(áØÆ), lambda x: (x, áØÆ[x])) if áØÁ is ÂÞÅ else ÄÕåØ(Áÿú(ÂÿÇ(áØÆ), MOD(Âêà, áØÁ=áÍé)), áØÆ) if ÂüÌ(áØÁ) == 1 else MOD(Áëý, áØÁ=áØÁ > 0)(ËãÂ(ÂÓÏ(áØÆ), lambda x, y: ÁØò(lambda ÂîÓ: ((x, *ÂîÓ[0]), ÂîÓ[1]))(MOD(ÂÓÏ, áØÁ=áØÁ - ÃÆí(áØÁ))(y))), ÄÔÙù)))
(ÂÿÇ := (lambda áØÆ, áØÁ=ÂÞÅ: ÄÝöÈ(MOD(Áëý, áØÁ=áÓö)(áØÆ, ãÊú)) if áØÁ is ÂÞÅ else MOD(Áÿú, áØÁ=ÂüÌ(áØÁ) if áØÁ < 0 else 1)(MOD(ÂÓÏ, áØÁ=áØÁ)(MOD(Áëý, áØÁ=Âåæ(Âó, áÓö))(áØÆ, Âåæ(MOD(ÂØÑ, áØÁ=ÂüÌ(áØÁ)), ÂÿÇ))), lambda ÂîÓ: ÂîÓ[0])))
(ÄÕÊÂ := (lambda áØÆ, áØÇ, áØÁ=ÂÞÅ: MOD(Áëý, áØÁ=ÁØö(áØÆ, ÁÜÙ))(ÄÔÙù([áØÁ if áØÁ is not ÂÞÅ else ' ' if ÁØö(áØÆ, ÁÜÙ) else False] * l, áØÆ) if (l := (áØÇ - ãÊú(áØÆ))) > 0 else áØÆ, Âøî)))
(ÄÕÊÄ := (lambda áØÆ, áØÇ, áØÁ=ÂÞÅ: MOD(Áëý, áØÁ=ÁØö(áØÆ, ÁÜÙ))(ÄÔÙù(áØÆ, [áØÁ if áØÁ is not ÂÞÅ else ' ' if ÁØö(áØÆ, ÁÜÙ) else False] * l) if (l := (áØÇ - ãÊú(áØÆ))) > 0 else áØÆ, Âøî)))
(ÄÔéÄ := (lambda áØÆ, áØÇ, áØÁ=ÂÞÅ: ÂåÔ(ÂåÔ((R := (lambda ÂîÓ: Âêà(ÁØã) if ÂîÓ is ÂÞÅ else Âêà(ÂîÓ) if ÁØö(ÂîÓ, ÁÜÙ) else Áÿú(ÁãÁ(ÂîÓ), ÁÜÙ))), (Æå := (lambda ÂîÓ: MOD(ÆÑ, áØÁ=ÂîÓ)((lambda ÂîÓ, ÂîÒ: MOD(ÄÕåØ, áØÁ=ÄÝöÉ(ÂîÒ))(ÂîÓ, ÂîÒ))(R(áØÆ), R(áØÇ)), lambda x, y: getattr(x, 'replace')(*y))))), Æå if áØÁ is ÂÞÅ else ÂÞÅCAT(áØÁ, Æå))))

@OPWRAP_(*'\U000f7e39\U000f7e3a\U000f7e38\U000f7e3b')
def _(áÑã, áØÆ=ÂÞÅ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ, ÁÜñ=False):
    ÂùÆ(áØÆ is not ÂÞÅ or ÂÞÅ is not áØÇ, 'Range missing both values!')
    if (áÑÃ := (áØÁ is ÂÞÅ)):
        (áØÁ := 1)
    (v := (áØÇ if áØÆ is ÂÞÅ else áØÆ if áØÇ is ÂÞÅ else ÂÞÅ))
    if (áØÆ is not ÂÞÅ and ÂÞÅ is not áØÇ) and ((ÁØö(áØÆ, ÄÊPSH(áÍÞ)) and ÁØñ(ÄÊPOP(), ÄÊPSH(áØÇ))) and (ÄÊDEL(1) or True) or (ÄÊDEL(1) or False)) if v is ÂÞÅ else ÁØö(v, áÍÞ):
        if v is not ÂÞÅ:
            (ÄÊPSH((0, v)), ((áØÆ := ÄÊPKE(0)[0]), (áØÇ := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
        (ÏÁ := (-1 if áØÇ < áØÆ else 1))
        if áÑÃ and ÏÁ == -1:
            (áØÁ := (-1))
        if áÑã == '\U000f7e39':
            return [*range(áØÆ, áØÇ, áØÁ)]
        if áÑã == '\U000f7e3a':
            return [*range(áØÆ + ÏÁ, áØÇ + ÏÁ, áØÁ)]
        if áÑã == '\U000f7e38':
            return [*range(áØÆ + ÏÁ, áØÇ, áØÁ)]
        if áÑã == '\U000f7e3b':
            return [*range(áØÆ, áØÇ + ÏÁ, áØÁ)]
    if v is not ÂÞÅ:
        ÂùÆ(ÁØö(v, áÓö))
        (v := [*v])
        if áÑã == '\U000f7e38':
            return (v[0], v[slice(1, -1, áØÁ)], v[-1])
        if áÑÃ:
            (áØÁ := 0)
        if áÑã == '\U000f7e39':
            return v[0 + áØÁ]
        if áÑã == '\U000f7e3a':
            return v[-1 - áØÁ]
        if áÑã == '\U000f7e3b':
            return (v[0 + áØÁ], v[-1 - áØÁ])
    if ÁØö(áØÆ, slice):
        (áØÆ := [*range(getattr(áØÆ, 'start'), getattr(áØÆ, 'stop'), getattr(áØÆ, 'step'))])
    if ÁÜñ:
        if áÓö(áØÆ):
            (ÄÊPSH(áØÆ), ÄÊPSH(ÂÿÇ(ÄÊPKE(0))), (áØÆ := ÄÊPKE(0)), ÄÊDEL(2))[2]
        elif áÓö(áØÇ):
            (ÄÊPSH(áØÇ), ÄÊPSH(ÂÿÇ(ÄÊPKE(0))), (áØÇ := ÄÊPKE(0)), ÄÊDEL(2))[2]
    if áÓö(áØÆ) and áÓö(áØÇ):
        return [áØÆ[h % ãÊú(áØÆ)] for h in áØÇ[slice(None, None, áØÁ)]]
    if áÓö(áØÆ) and ÁØö(áØÇ, slice):
        return áØÆ[áØÇ]
    if áÓö(áØÆ) and ÁØö(áØÇ, áÍÞ):
        if áÑã == '\U000f7e39':
            return áØÆ[slice(None, áØÇ, áØÁ)]
        if áÑã == '\U000f7e3a':
            return áØÆ[slice(1, áØÇ + 1, áØÁ)]
        if áÑã == '\U000f7e38':
            return áØÆ[slice(1, áØÇ, áØÁ)]
        if áÑã == '\U000f7e3b':
            return áØÆ[slice(None, áØÇ + 1, áØÁ)]
    if ÁØö(áØÆ, áÍÞ) and áÓö(áØÇ):
        if áÑã == '\U000f7e39':
            return áØÇ[slice(áØÆ, -1, áØÁ)]
        if áÑã == '\U000f7e3a':
            return áØÇ[slice(áØÆ + 1, None, áØÁ)]
        if áÑã == '\U000f7e38':
            return áØÇ[slice(áØÆ + 1, -1, áØÁ)]
        if áÑã == '\U000f7e3b':
            return áØÇ[slice(áØÆ, None, áØÁ)]
    ÂùÆ(False, 'Invalid argument types! %s %s' % (ÁØö(áØÆ), ÁØö(áØÇ)))

def áÇù(x, y=ÂÞÅ, áØÁ=ÂÒå, ÁÜñ=False):
    if not x:
        return []
    if ÁØö(x, áÍÞ):
        (ÄÊPSH(x), ÄÊPSH(ÂÿÇ(ÄÊPKE(0))), (x := ÄÊPKE(0)), ÄÊDEL(2))[2]
    if y is ÂÞÅ:
        (y := ÄÕÍÔ)
    if ÁÜñ:
        return MOD(áÇù, áØÁ=áØÁ)(ÂÿÇ(x), (lambda i: y(x[i])) if áÓó(y) else y)
    elif ÁØö(y, áÍÞ):
        return [x[slice(None, y)], x[slice(y, None)]]
    elif not áÓó(y):
        ÂùÆ(áÓö(y))
        (y := áÍè(MOD(ÄÔÔç, áØÁ=lambda ÂîÓ: ÂÁÍ(ì)(ÂîÓ, ãÊú(x)))(y, lambda ÂîÓ: ÂîÓ < 0)))
        (ÄÊPSH(([], [])), ((R := ÄÊPKE(0)[0]), (áÍÌ := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
        for áÑî, áÑü in ÂÓÏ(x):
            if áÑî in y:
                getattr(áÍÌ, 'append')(R)
                (R := [])
            getattr(R, 'append')(áÑü)
        if R:
            getattr(áÍÌ, 'append')(R)
        return áÍÌ
    (ÄÊPSH((y((áÝÌ := x[0])), [áÝÌ] * (áÝÌ is not ÄÔýò), [])), ((áÍç := ÄÊPKE(0)[0]), (R := ÄÊPKE(0)[1]), (áÍÌ := ÄÊPKE(0)[2])), ÄÊDEL(1))[1]
    for áÑî, áÑü in ÂÓÏ(x)[slice(1, None)]:
        if (r := y(áÑü)) != áÍç:
            getattr(áÍÌ, 'append')(R)
            (ÄÊPSH((r, [])), ((áÍç := ÄÊPKE(0)[0]), (R := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
            if not (ÄÊPSH(áØÁ), ÄÊPSH(ÄÊPKE(0) - 1), (áØÁ := ÄÊPKE(0)), ÄÊDEL(2))[2]:
                getattr(áÍÌ, 'append')(x[slice(áÑî + (r is ÄÔýò), None)])
                break
        if r is not ÄÔýò:
            getattr(R, 'append')(áÑü)
    if R:
        getattr(áÍÌ, 'append')(R)
    (áÍÌ := ÄÔÔè(áÍÌ, lambda ÂîÓ: ÂîÓ == []))
    if ÁØö(x, ÁÜÙ):
        (áÍÌ := MOD(ÄÔÔç, áØÁ=lambda ÂîÓ: Âøî(ÂîÓ, ÁØã))(áÍÌ, lambda ÂîÓ: ÄÝøÇ(ÂîÓ, ÁÜÙ)))
    return áÍÌ

@OPWRAP_(*'⨝⟕⟖⟗')
def _(áÑã, áØÆ=ÂÞÅ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ, LR_def=None, bound_mode=ÂÞÅ):
    ÂùÆ(áØÆ is not ÂÞÅ or ÂÞÅ is not áØÇ, 'Join missing both values!')
    if áØÁ is not ÂÞÅ:
        (bound_mode := áØÁ)
    if bound_mode is ÂÞÅ:
        (bound_mode := (áÑã == '⟗' and 1 or 0))
    if áØÆ is ÂÞÅ:
        (ÄÊPSH((áØÇ, áØÆ)), ((áØÆ := ÄÊPKE(0)[0]), (áØÇ := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    if áØÇ is ÂÞÅ:
        ÂùÆ(áÓö(áØÆ), 'Single-arg %s needs an iterable' % (áÑã,))
        return '\n' * (áÑã in '⟕⟗') + getattr(ÁØã, 'join')(Áÿú(áØÆ, ÁÜÙ)) + ÂÔö('⟗⟖', áÑã) * '\n'
    (Y := áØÇ)
    if not áÓó(áØÇ):
        (ÄÊPSH(áØÇ), ÄÊPSH((lambda ÂîÓ: lambda *áÑË: ÂîÓ)(ÄÊPKE(0))), (áØÇ := ÄÊPKE(0)), ÄÊDEL(2))[2]
    (ÄÊPSH(([*áØÆ], [])), ((áØÆ := ÄÊPKE(0)[0]), (R := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    if ãÊú(áØÆ) == 0 and (áÑã != '⨝' or bound_mode > 0):
        if (v := áØÇ(LR_def, LR_def)) is ÄÔýò:
            (R := [])
        if áÑã in '⟕⟖' or bound_mode == 1:
            (R := [v])
        else:
            (R := [v, v])
    else:
        if áÑã in '⟕⟗' and ÄÔýò is not (áÑÿ := áØÇ(LR_def, áØÆ[0])):
            getattr(R, 'append')(áÑÿ)
        for i in ÄÝöÇ(ãÊú(áØÆ)):
            getattr(R, 'extend')([áØÆ[i - 1]] if (áÑÿ := áØÇ(áØÆ[i - 1], áØÆ[i])) is ÄÔýò else [áØÆ[i - 1], áÑÿ])
        if ãÊú(áØÆ):
            getattr(R, 'append')(áØÆ[-1])
        if áÑã in '⟖⟗' and ÄÔýò is not (áÑÿ := áØÇ(áØÆ[-1], LR_def)):
            getattr(R, 'append')(áÑÿ)
    return getattr(ÁØã, 'join')(Áÿú(R, ÁÜÙ)) if ÁØö(Y, ÁÜÙ) else R

@OPWRAP_(*'\U000f7e4c\U000f7e4d\U000f7e4e')
def _(áÑã, áØÆ=ÂÞÅ, áØÇ=ÂÞÅ, áØÁ=-1):
    if ÁØö(áØÁ, áÍé):
        (ÄÊPSH(ÂÀÇ(áØÁ) if áØÁ[0] == áÍá else áØÁ), ((n := ÄÊPKE(0)[0]), (L := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    else:
        (ÄÊPSH([-1, True] if áØÁ == áÍá else [áØÁ, False]), ((n := ÄÊPKE(0)[0]), (L := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    if (not L and ÁØö(áØÆ, ÁÜÙ)) and (áØÇ is ÂÞÅ or ÁØö(áØÇ, ÁÜÙ)):
        (áÏÞ := (() if áØÇ is ÂÞÅ else (áØÇ,)))
        if áÑã == '\U000f7e4e':
            return ÄÔÔç(getattr(áØÆ, 'split')(*áÏÞ, maxsplit=n))
    if áØÇ is ÂÞÅ:
        (áØÇ := Âó)
    if (YS := ÁØö(áØÇ, ÁÜÙ)) and (not L):
        (ÄÊPSH((Áÿú(Ááú(áØÆ, [0, ãÊú(áØÇ) - 1]), lambda ÂîÓ: Âøî(ÄÔÔç(ÂîÓ))), CUR(lambda ÂîÓ, ÂîÒ: ÂîÓ == ÂîÒ, áØÇ), ãÊú(áØÇ), ãÊú(áØÇ) - 1)), ((áØÆ := ÄÊPKE(0)[0]), (áØÇ := ÄÊPKE(0)[1]), (Y := ÄÊPKE(0)[2]), (ÏÁ := ÄÊPKE(0)[3])), ÄÊDEL(1))[1]
    else:
        (ÄÊPSH(([*áØÆ], áØÇ if áÓó(áØÇ) else CUR(lambda ÂîÓ, ÂîÒ: ÂîÓ == ÂîÒ, áØÇ), 0)), ((áØÆ := ÄÊPKE(0)[0]), (áØÇ := ÄÊPKE(0)[1]), (ÏÁ := ÄÊPKE(0)[2])), ÄÊDEL(1))[1]
    (ÄÊPSH(([], [], -1, 0)), ((r := ÄÊPKE(0)[0]), (b := ÄÊPKE(0)[1]), (Ïç := ÄÊPKE(0)[2]), (Ïñ := ÄÊPKE(0)[3])), ÄÊDEL(1))[1]
    (last_v := False)
    while (ÄÊPSH(Ïç), ÄÊPSH(ÄÊPKE(0) + 1), (Ïç := ÄÊPKE(0)), ÄÊDEL(2))[2] < ãÊú(áØÆ) and Ïñ < (ÂÕË if n == -1 else n):
        (áÐÏ := áØÆ[Ïç])
        if (áÑÿ := áØÇ(áÐÏ)):
            if b or áÑã != '\U000f7e4e':
                if áÑã == '\U000f7e4e':
                    getattr(r, 'append')(b)
                elif áÑã == '\U000f7e4c' or (áÑã == '\U000f7e4d' and (not last_v)):
                    getattr(r, 'extend')([b] if áÑÿ is ÄÔýò else [b, áÐÏ])
                    (last_v := True)
            (b := [])
            (ÄÊPSH(Ïç), ÄÊPSH(ÄÊPKE(0) + ÏÁ), (Ïç := ÄÊPKE(0)), ÄÊDEL(2))[2]
            (ÄÊPSH(Ïñ), ÄÊPSH(ÄÊPKE(0) + 1), (Ïñ := ÄÊPKE(0)), ÄÊDEL(2))[2]
        elif áÑÿ is not ÄÔýò:
            getattr(b, 'append')(áÐÏ)
            (last_v := False)
    if b or áÑã != '\U000f7e4e':
        getattr(b, 'extend')(áØÆ[slice(Ïç, None)])
        getattr(r, 'append')(b)
    elif áØÆ[slice(Ïç, None)]:
        getattr(r, 'append')(áØÆ[slice(Ïç, None)])
    return ÁØò(lambda ÂîÓ: Âøî(ÁØò(lambda ÂîÓ: ÂîÓ[0])(ÂîÓ)) if ÁØö(ÂîÓ, áÍá) else ÂîÓ)(r) if YS else r

@OPWRAP_(*'⫰⫯\U000f7e52')
def _(áÑã, áØÆ, áØÁ=ÂÞÅ, ÁÜñ=ÂÞÅ):
    if ÁÜñ is not ÂÞÅ:
        ÂùÆ(ÁØö(áØÆ, ÁÜÙ) and áÑã != '\U000f7e52')
        return MOD(ÄÔÔç, ÁÜñ=ÄÕøü)(áØÆ, CURR(lambda ÂîÓ, ÂîÒ: ÃÆí(ÂîÓ) == ÂîÒ, áÑã == '⫰' or -1))
    if áÑã == '⫰':
        (v := (TO_UPPERCASE(áØÆ) if ÁØö(áØÆ, ÁÜÙ) else +abs(áØÆ)))
    elif áÑã == '⫯':
        (v := (TO_LOWERCASE(áØÆ) if ÁØö(áØÆ, ÁÜÙ) else -abs(áØÆ)))
    elif áÑã == '\U000f7e52':
        if áØÁ is not ÂÞÅ and ÁØö(áØÁ, ÂÑÅ):
            return ((ÂüÌ if v == 1 else ÂüË) if (v := ÃÆí(áØÁ)) else ÄÝöâ)(áØÆ, áØÁ=ÂÞÅ, ÁÜñ=ÁÜñ)
        (v := (REVERSE_CASE(áØÆ) if ÁØö(áØÆ, ÁÜÙ) else -áØÆ))
    if áØÁ is ÂÞÅ:
        return v
    ÂùÆ(áÓó(áØÁ))
    (áØÁ := áØÁ(v))
    if ÄÝøÇ(áØÆ, ÁÜÙ):
        if áÑã == '⫰':
            return -áØÁ if áØÆ < 0 else áØÁ
        elif áÑã == '⫯':
            return -áØÁ if áØÆ > 0 else áØÁ
        elif áÑã == '\U000f7e52':
            return áØÁ if not áØÆ else -áØÁ
    return Âøî(ËãÂ(ÂÛÅ([áØÆ, v, áØÁ]), lambda x, y, z: MOD(Áëý, áØÁ=ÃÆí(x) != ÃÆí(y))(z, MOD(ÄÝöâ, áØÁ=ÃÆí(x)))))

def ÄÝöì(áØÆ=ÂÞÅ, áØÁ=ÂÞÅ, C=ÂÞÅ):
    (nc := (C is ÂÞÅ))
    if nc:
        (C := (num + ABC + abc))
    elif áØÁ is ÂÞÅ:
        (áØÁ := ãÊú(C))
    if áØÁ is ÂÞÅ:
        if ÄÝøÇ(áØÆ, ÁÜÙ):
            if áØÆ != Âäû(áØÆ):
                return ÁÜÙ(áØÆ)
        elif '.' in áØÆ:
            return áÍÛ(áØÆ)
        (áØÇ := 10)
    elif ÁØö(áØÁ, áÓö):
        (ÄÊPSH([áØÁ[0], ÂÞÅ] if ãÊú(áØÁ) == 1 else áØÁ), ((áØÇ := ÄÊPKE(0)[0]), (áØÁ := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    elif ÁØö(áØÁ, ÂÐý):
        (ÄÊPSH((Âüð(áØÁ), ÂÞÅ)), ((áØÇ := ÄÊPKE(0)[0]), (áØÁ := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    else:
        (ÄÊPSH(MOD(ÁÞç, áØÁ=0)(Áÿú(ÄÝõé(áØÁ), Âüð), lambda ÂîÓ: ÂîÓ or 10)), ((áØÇ := ÄÊPKE(0)[0]), (áØÁ := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    if MOD(ÁØö, áØÁ=ÂÕó)(áØÆ, áÍÛ):
        (ÄÊPSH(áØÆ), ÄÊPSH(Âäû(ÄÊPKE(0))), (áØÆ := ÄÊPKE(0)), ÄÊDEL(2))[2]
    elif ÁØö(áØÆ, ÁÜÙ):
        if áØÆ and áØÆ[0] == '-':
            (ÄÊPSH((áØÆ[slice(1, None)], -1)), ((áØÆ := ÄÊPKE(0)[0]), (p := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
        else:
            (p := 1)
        if nc and áØÇ <= 36:
            (ÄÊPSH(áØÆ), ÄÊPSH(ÂüÌ(ÄÊPKE(0))), (áØÆ := ÄÊPKE(0)), ÄÊDEL(2))[2]
        (áØÆ := (MOD(ÆÑ, áØÁ=0)(ÁØò(lambda ÂîÓ: MOD(ÄÔÞÔ, ÁÜñ=ÄÕøü)(C, ÂîÓ))(áØÆ), CUR(lambda ÂîÓ, ÂîÒ: ÂîÓ * áØÇ + ÂîÒ)) * p))
        if áØÁ is ÂÞÅ:
            return áØÆ
    if áØÁ is ÂÞÅ:
        (áØÁ := 1)
    (ÂÐôþáÏß := CUR(lambda ÂîÓ, ÂîÒ: Âøî(ÂÀÇ(ÁØò(lambda ÂîÓ: ÂîÒ[ÂîÓ % ãÊú(ÂîÒ)])(ÂÛÜ(lambda ÂîÓ: ÂîÓ // ãÊú(ÂîÒ), Âó)(ÂîÓ))))))
    (ÂÑÅþáÏß := CUR(lambda ÂîÓ, ÂîÒ, *áÏÞ: (ÂîÓ < 0) * '-' + MOD(ÄÕÊÂ, áØÁ=ÂîÒ[0])(ÂÐôþáÏß(ÂüÌ(ÂîÓ), ÂîÒ), áÏÞ[0])))
    return ÂÑÅþáÏß(áØÆ, ÄÝöÈ(C, áØÇ), áØÁ)
(ÄÔóÅ := (lambda áØÆ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ: phase(áØÆ + ÂÞÅCAT(áØÇ, Ãù)) if áØÇ is not ÂÞÅ else phase(áØÆ) if ÁØö(áØÆ, ÂÐá) else phase(ÄÝõé(áØÆ))))
(Âõì := (lambda áØÆ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ: rect(áØÆ, áØÇ) if áØÇ is not ÂÞÅ else rect(*áØÆ) if ÁØö(áØÆ, áÓö) else polar(áØÆ) if s is ÂÞÅ else ÂÞÅCAT(áØÆ, ÂÐæ ** ÂÞÅCAT(áØÁ, Ãù))))

@OPWRAP_(*'\U000f7e13\U000f7e3c\U000f7e14')
def _(áÑã, áØÆ, áØÁ=ÂÞÅ, ÁÜñ=ÂÞÅ):
    if áØÆ is ë:
        ÂùÆ(ÁÜñ is ÂÞÅ and áØÁ is ÂÞÅ, 'no')
        return SUBSCRIPT if áÑã == '\U000f7e13' else SUPSCRIPT if áÑã == '\U000f7e14' else (ÄÝõà(ë), ÄÝõá(ë))
    (áØÆ := ÁÜÙ(áØÆ))
    if ÁÜñ is not ÂÞÅ:
        if áÑã == '\U000f7e3c':
            ÂùÆ(áØÁ is ÂÞÅ, '\U000f0931')
            ÂùÆ(ÁØö(ÁÜñ, áÓó), '\U000f0931')
            return under_script(áØÆ, ÁÜñ)
        ÂùÆ(False, '\U000f0931')
    if áØÁ is ÂÞÅ:
        (áØÁ := 1)
    if áØÁ > 0:
        (Æå := (subscript if áÑã == '\U000f7e13' else supscript if áÑã == '\U000f7e14' else nrmscript))
        return ÂÕÅ(ÂØÍ(Æå, áØÁ), áØÆ)

@OPWRAP_(*'\ue270\U000f114f\uf074')
def _(áÑã, áØÆ=ÂÞÅ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ):

    def Æå():
        if áÑã == '\uf074':
            ÂùÆ(áÓö(áØÆ) or áÓö(áØÇ))
            (ÄÊPSH((áØÆ, áØÇ) if áÓö(áØÆ) else (áØÇ, áØÆ)), ((áÏË := ÄÊPKE(0)[0]), (n := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
            if n is ÂÞÅ:
                return ÂåÔ(shuffle((áÑÿ := [*áÏË])), áÑÿ)
            return Áÿú(ÂÿÇ(n), lambda: choice(áÏË))
        if ÂÞÅ is áØÆ and áØÇ is ÂÞÅ:
            return uniform(*(ÂÕÀ(1) if áÑã == '\ue270' else [0, 1]))
        (Æå := (uniform if áÑã == '\ue270' else randint))
        if ÂÞÅ is not áØÆ and áØÇ is not ÂÞÅ:
            return Æå(áØÆ, áØÇ)
        if áÓö((áÑÿ := áÑø([áØÆ, áØÇ])[0])):
            return Æå(*áÑÿ)
        else:
            return Æå(0, áÑÿ)
        ÂùÆ(False)
    return ÐÌü(Æå) if áØÁ is ÂÞÅ else ËãÂ(MOD(ÂÚü, áØÁ=áØÁ)(), Æå)
__dir__=(__file__:=áÌî(moon_dir/'/home/ganer/Projects/Moon_BETA/Header/ops_C.☾')).parent
@OPWRAP_(*'\U000f147c\U000f7e45')
def _(áÑã, áØÆ=ÂÞÅ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ):
    (áÖÒ := (áØÆ if áØÇ is ÂÞÅ else (áØÆ, áØÇ)))
    (ÄÊPSH(MOD(ÐÌÛ, áØÁ=áÍÖ, ÁÜñ=ÄÕøü)(áÖÒ, áÓö)), ((N := ÄÊPKE(0)[0]), (I := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    (ÄÊPSH(Âîí(Áÿú(ÄÝöÊ(áÖÒ, I), ãÊú))), ((l := ÄÊPKE(0)[0]), (h := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    if N:
        (ÄÊPSH(áÖÒ), ÄÊPSH(MOD(ÁÞç, áØÁ=N)(ÄÊPKE(0), MOD(ÁØò(lambda ÂîÓ: MOD(Âêà, áØÁ=h)(ÂîÓ))))), (áÖÒ := ÄÊPKE(0)), ÄÊDEL(2))[2]
    if áØÁ is ÂÞÅ:
        if áÑã == '\U000f7e45':
            (ÄÊPSH(áÖÒ), ÄÊPSH(ÁØòþÁÙÄ(lambda ÂîÓ, ÂîÒ: ÂîÓ[slice(ãÊú(ÂîÓ) - ÂîÒ, None)])(ÄÊPKE(0), l)), (áÖÒ := ÄÊPKE(0)), ÄÊDEL(2))[2]
    else:
        (ÄÊPSH(áÖÒ), ÄÊPSH(Áÿú(ÄÊPKE(0), Âåæ((lambda ÂîÓ: MOD(ÄÕÊÄ, áØÁ=ÂîÓ[-1] if áØÁ is ÄÕøü else áØÁ)(ÂîÓ, h)) if áÑã == '\U000f147c' else lambda ÂîÓ: MOD(ÄÕÊÂ, áØÁ=ÂîÓ[0] if áØÁ is ÄÕøü else áØÁ)(ÂîÓ, h), áÍá))), (áÖÒ := ÄÊPKE(0)), ÄÊDEL(2))[2]
    return [*zip(*áÖÒ)]

def ÁÛÛ(áØÆ, áØÁ=ÂÞÅ):

    def Æå(áØÁ):
        if ÄÝøÇ(áØÁ, áÓö) or ÁØñ(ÁÜÙ, áØÁ):
            (ÄÊPSH(áØÁ), ÄÊPSH(Âêà(ÄÊPKE(0))), (áØÁ := ÄÊPKE(0)), ÄÊDEL(2))[2]
        (áÓÕ := (MOD(ÁÛÛ, áØÁ=áØÁ[slice(1, None)]) if ãÊú(áØÁ) > 1 else ÄÕÍÔ))
        (áÓÙ := (lambda x, y: áÓÕ(x[y % ãÊú(x)]) if ÁØö(y, ÂÑÅ) else áÓÕ(x[y]) if ÁØö(y, ÁÜÙ) or ((ÄÝøÆ(áÓö, ÄÊPSH(y)) and ÄÝøÇ(ÄÊPOP(), ÄÊPSH(slice))) and (ÄÊDEL(1) or True) or (ÄÊDEL(1) or False)) else MOD(Áëý, áØÁ=áÓÕ is not ÄÕÍÔ)(ÄÝöÊ(x, y), lambda ÂîÓ: Áÿú(ÂîÓ, áÓÕ))))
        return áÓÙ(áØÆ, áØÁ[0])
    return Æå if áØÁ is ÂÞÅ else Æå(áØÁ)

def ÁÝÖ(áØÆ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ):
    ÂùÆ(ÁØö(áØÆ, áÓö), '%s\U000f7e75𝗜' % (áØÆ,))
    ÂùÆ(áØÁ is not ÂÞÅ, 'ᕋ requires modifier')
    (áØÆ := (ÄÔÙù(áØÆ) if (is_str := ÁØö(áØÆ, ÁÜÙ)) else ÐÌü(getattr(áØÆ, 'copy'))))
    (áØÇ := (ÂÚü() if áØÇ is ÂÞÅ else MOD(Áëý, áØÁ=ÄÝøÇ(áØÇ, áÓö))(áØÇ, Âêà)))
    (áØÁ := (slice((ÄÊPSH(áØÁ), ÄÊPSH(ÄÊPKE(0) % ãÊú(áØÆ)), (áØÁ := ÄÊPKE(0)), ÄÊDEL(2))[2], áØÁ + 1) if ÁØö(áØÁ, áÍÞ) else áØÁ))
    if ÁØö(áØÁ, slice):
        (ÄÊPSH(áØÆ), ÄÊPSH(áØÁ), ÄÊPSH(áØÇ), setitem(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3]
    elif ÁØö(áØÁ, áÓö):
        for i, (z, n) in ÂÓÏ(ÁØò(lambda ÂîÓ: [ÂîÓ[0], ãÊú(ÂîÓ)])(áÇù(ÄÔàÒ(ÁØò(lambda ÂîÓ: ÂîÓ % ãÊú(áØÆ))(áØÁ))))):
            if áØÇ is ÂÞÅ or i >= ãÊú(áØÇ):
                del áØÆ[z]
            else:
                (ÄÊPSH(áØÆ), ÄÊPSH(slice(z, z + 1)), ÄÊPSH(MOD(Âêà, áØÁ=n)(áØÇ[i])), setitem(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3]
    else:
        ÂùÆ(False, 'Modifier \U000f7e75 slice|𝑖|𝗜')
    return Âøî(áØÆ, ÁØã) if is_str else áØÆ
(ÂÕÅ := (lambda áØÆ, áØÇ, áØÁ=1: áØÆ(*MOD(Âêà, áØÁ=áØÁ)(áØÇ))))

def Áëý(áØÆ, áØÇ, áØÁ=ÂÞÅ):
    (v := (áØÆ if áØÁ is ÂÞÅ else áØÁ(áØÆ) if áÓó(áØÁ) else áØÁ))
    if áÓó(áØÇ):
        return áØÇ(áØÆ) if v else áØÆ
    if áÓö(áØÇ):
        if ãÊú(áØÇ) == 1:
            return áØÇ[0](áØÆ) if v else v
        if ãÊú(áØÇ) == 2:
            return áØÇ[áÍÖ(v)](áØÆ)
    ÂùÆ(False)

@OPWRAP_(*'○⍜\U000f0b2b\U000f0b29')
def _(áÑã, áÍÛ, áÍÜ, áØÁ=1):
    if áÑã in '\U000f0b29\U000f0b2b':
        ÂùÆ((ÄÊDEL(1), False)[1] if ÄÊPSH(áØÁ == ì) else ÄÊPOP() if î == áØÁ else (ÄÊDEL(1), True)[1], '\U000f0931 generalize')
        if not áØÁ or ÁØö(áÍÜ, áÓö):

            def Æå(*áÑË):
                if áØÁ == 0:
                    (áÖÒ := [Áÿú(MOD(Áëý, áØÁ=ÁØö(áÍÜ, áÓó))(áÍÜ, Âêà), ÐÌü), áÑË])
                else:
                    (áÖû := (ãÊú(áÍÜ) * (S := ÂüÌ(áØÁ))))
                    if áØÁ < 0:
                        (ÄÊPSH(áÑË), ÄÊPSH(Âúú(ÄÊPKE(0), ãÊú(áÑË) - áÖû)), (áÑË := ÄÊPKE(0)), ÄÊDEL(2))[2]
                    if áÑã == '\U000f0b2b':
                        (ÄÊPSH(MOD(ÄÕÊÄ, áØÁ=[])(áÇù(áÑË, áÖû), 2)), ((Ïß := ÄÊPKE(0)[0]), (Ïà := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
                    elif áÑã == '\U000f0b29':
                        (ÄÊPSH(MOD(ÄÕÊÂ, áØÁ=[])(áÇù(áÑË, ÂóÍ(ãÊú(áÑË) - áÖû, 0)), 2)), ((Ïà := ÄÊPKE(0)[0]), (Ïß := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
                    (áÖÒ := [ÁØò(lambda ÂîÓ: ÂîÓ[1](*ÂîÓ[0]))((ÄÕåØ if áØÁ < 0 else ÄÝöÔ)[[]](MOD(Ááú, áØÁ=ÄÔýò)(Ïß, [0, S - 1, S]), áÍÜ)), Ïà])
                return ÄÔÙù(MOD(Áëý, áØÁ=áÑã == '\U000f0b29')(áÖÒ, ÂÀÇ))
        else:

            def Æå(*áÑË):
                (áÖí := (ãÊú(áÑË) // ((S := ÂüÌ(áØÁ)) or 1) * S))
                (ÄÊPSH(áÇù(ÂÿÇ(áÑË), áÖí if áÑã == '\U000f0b2b' else ãÊú(áÑË) - áÖí)), ((Ïß := ÄÊPKE(0)[0]), (Ïà := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
                if Ïß and áØÁ < 0:
                    (ÄÊPSH((ÁØò(lambda ÂîÓ: ÂîÓ + ãÊú(Ïà))(Ïß), ÂÿÇ(Ïà))), ((Ïß := ÄÊPKE(0)[0]), (Ïà := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
                (ÄÊPSH((ÄÝöÊ(áÑË, Ïß), ÄÝöÊ(áÑË, Ïà))), ((Ïß := ÄÊPKE(0)[0]), (Ïà := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
                if áÑã == '\U000f0b2b':
                    return (*ËãÂ(MOD(ÁâÁ, áØÁ=ÂóÍ(S - 1, 0))(Ïß), áÍÜ), *Ïà)
                elif áÑã == '\U000f0b29':
                    return (*Ïß, *ËãÂ(MOD(ÁâÁ, áØÁ=ÂóÍ(S - 1, 0))(Ïà), áÍÜ))
    elif ÁØö(áÍÜ, áÓó):

        def Æå(*áÑË):
            (ÄÊPSH(((L := ãÊú(áÑË)) // (S := ÂüÌ(áØÁ)), L % S)), ((n := ÄÊPKE(0)[0]), (m := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
            ÂùÆ(n != 0, '\U000f0931 generalize')
            (áÖÒ := (MOD(ÄÕÊÄ, áØÁ=ÂýÃ) if áÑã == '○' else MOD(ÄÕÊÂ, áØÁ=ÂýÃ))(áÑË, L + (n - m) % n))
            (v := MOD(ÁâÁ, áØÁ=n - 1)(áÖÒ))
            if m != 0:
                (ÄÊPSH((-1, 0) if áÑã == '○' else (0, -1)), ((Ïß := ÄÊPKE(0)[0]), (Ïà := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
                if ÄÝøø(áÑã == '⍜', áØÁ < 0):
                    (ÄÊPSH(v), ÄÊPSH(Ïß), ÄÊPSH(ÄÔÙù(ÂÀÇ(áÇù(v[Ïß], lambda ÂîÓ: ÂîÓ is ÂýÃ)))), setitem(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3]
                (ÄÊPSH(v), ÄÊPSH(Ïß), ÄÊPSH(ÁØòþÁÙÇ(lambda ÂîÓ, ÂîÒ: ÂîÓ if ÂîÓ is not ÂýÃ else ÂîÒ)(v[Ïß], v[Ïà])), setitem(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3]
            return ËãÂ(v, áÍÜ)
    elif ÁØö(áÍÜ, áÓö):

        def Æå(*áÑË):
            ÂùÆ(ãÊú(áÑË) >= ãÊú(áÍÜ) * (S := ÂüÌ(áØÁ)), '\U000f0931 generalize')
            ÂùÆ(áØÁ > 0, '\U000f0931 generalize')
            ÂùÆ(áÑã != '⍜', '\U000f0931 generalize')
            (ÄÊPSH(áÇù(áÑË, ãÊú(áÍÜ) * (S := ÂüÌ(áØÁ)))), ((l := ÄÊPKE(0)[0]), (r := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
            (áÖÒ := ÁØòþÁÙÄ(lambda ÂîÓ, ÂîÒ: ÄÔÙù(ÂîÓ, ÂîÒ))(MOD(ÁâÁ, áØÁ=S - 1)(l), r))
            return ËãÂ(ÄÕåØ(áÖÒ, áÍÜ), lambda x, y: y(*x))
    return lambda *áÑË, **áÑÕ: áÍÛ(*Æå(*áÑË), **áÑÕ)

@OPWRAP_(*'⊚⊜🟕🟖⊛⍟')
def _(áÑã, Æå=ÂÞÅ, áÍÜ=ÂÞÅ, áØÁ=ÂÕË):
    if not áÓó(Æå):
        (ÄÊPSH((áÍÜ, Æå)), ((Æå := ÄÊPKE(0)[0]), (áÍÜ := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    if áÍÜ is ÂÞÅ:
        (áÍÜ := ÄÕÍÔ)
    elif ÁØö(áÍÜ, áÍÞ) and áÑã in '⊚⊛⍟':
        (áÍÜ := Ticker(áÍÜ + 1))

    def r(*áÑË, **áÑÕ):
        (ÄÊPSH((ÂüÌ(áØÁ), áÑË[0] if áÑË else None, áÍÜ(*áÑË, **áÑÕ))), ((n := ÄÊPKE(0)[0]), (f := ÄÊPKE(0)[1]), (g := ÄÊPKE(0)[2])), ÄÊDEL(1))[1]
        if áÑã == '⊚':
            if g:
                return f
            while 0 < (ÄÊPSH(n), ÄÊPSH(ÄÊPKE(0) - 1), (n := ÄÊPKE(0)), ÄÊDEL(2))[2]:
                if áÍÜ((f := Æå(f))):
                    return f
        elif áÑã == '⊜':
            while 0 < (ÄÊPSH(n), ÄÊPSH(ÄÊPKE(0) - 1), (n := ÄÊPKE(0)), ÄÊDEL(2))[2]:
                if g == (g := áÍÜ((nf := Æå(f)))):
                    return f
                (f := nf)
        elif áÑã in '⊛⍟':
            (rf := [f])
            if g:
                return rf if áÑã == '⊛' else []
            while 0 < (ÄÊPSH(n), ÄÊPSH(ÄÊPKE(0) - 1), (n := ÄÊPKE(0)), ÄÊDEL(2))[2]:
                (g := áÍÜ((f := Æå(f))))
                if not g or áÑã == '⊛':
                    getattr(rf, 'append')(f)
                if g:
                    return rf
            if áØÁ < 0:
                return rf
        elif áÑã in '🟕🟖':
            (ÄÊPSH(([f], [g])), ((rf := ÄÊPKE(0)[0]), (rg := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
            while 0 < (ÄÊPSH(n), ÄÊPSH(ÄÊPKE(0) - 1), (n := ÄÊPKE(0)), ÄÊDEL(2))[2]:
                if (g := áÍÜ((f := Æå(f)))) in rg:
                    if áÑã == '🟖':
                        return rf
                    return ÄÝöÊ(MOD(ÄÔÞÔ, ÁÜñ=ÄÕøü)(rg, lambda x: x == g), rf)
                getattr(rf, 'append')(f)
                getattr(rg, 'append')(g)
        return None
    return r
__dir__=(__file__:=áÌî(moon_dir/'/home/ganer/Projects/Moon_BETA/Header/ops_\uea8c.☾')).parent
(áÍù := áÓö)

def adjust_depth(áØÆ, áØÁ, áÍù=áÓö):
    if áØÁ is ÂÞÅ:
        return 1
    if áØÁ >= 0:
        return áØÁ
    (ÄÊPSH((áØÆ, 0)), ((áØÆ := ÄÊPKE(0)[0]), (k := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    while (ÄÊPSH(k), ÄÊPSH(ÄÊPKE(0) + 1), (k := ÄÊPKE(0)), ÄÊDEL(2))[2] if áÍù(áØÆ) else None:
        if ÁØö(áØÆ, ÁÜÙ):
            break
        if ÁØö(áØÆ, ÁÜÙ) or not ãÊú(áØÆ):
            break
        (ÄÊPSH(áØÆ), ÄÊPSH(ÄÊPKE(0)[0]), (áØÆ := ÄÊPKE(0)), ÄÊDEL(2))[2]
    return ÂóÍ(áØÁ + k - 1, 0)

def flatten(áØÆ, áØÁ=ÂÞÅ, áÖÞ=None, áÍù=áÓö):
    (áØÁ := adjust_depth(áØÆ, áØÁ))
    if áÖÞ is None:
        (áÖÞ := ÂÚü())
    if (áØÁ <= 0 or not áÍù(áØÆ)) or ÁØñ(ÁÜÙ, áØÆ):
        return ÂåÔ((getattr(áÖÞ, 'extend') if áÍù(áØÆ) else getattr(áÖÞ, 'append'))(áØÆ), áÖÞ)
    for x in áØÆ:
        flatten(x, áØÁ - 1, áÖÞ, áÍù=áÍù)
    return áÖÞ

def chain_structure(áØÆ, áØÁ=ÂÞÅ, áÍù=áÓö):
    (áØÁ := adjust_depth(áØÆ, áØÁ))
    if (áØÁ <= 0 or not áÍù(áØÆ)) or ÁØö(áØÆ, ÁÜÙ):
        return MOD(Âêà, áØÁ=ãÊú(áØÆ))(None) if áÍù(áØÆ) else None
    return ÁØò(lambda ÂîÓ: chain_structure(ÂîÓ, áØÁ - 1, áÍù=áÍù))(áØÆ)

def deflatten(áØÆ, áÖÛ, áÍù=áÓö):
    if áÖÛ is None:
        return getattr(áØÆ, 'pop')(0) if áØÆ else ÄÔýò
    return ÁØò(lambda ÂîÓ: deflatten(áØÆ, ÂîÓ, áÍù=áÍù))(áÖÛ)

def flatten_under(áØÆ, Æå, áØÁ=ÂÞÅ, ÁÜñ=ÂÞÅ, áÍù=áÓö):
    (áØÁ := adjust_depth(áØÆ, áØÁ))
    if ÁÜñ is ÂÞÅ:
        (ÁÜñ := flatten(áØÆ, áØÁ, áÍù=áÍù))
    return deflatten(Æå(ÁÜñ), chain_structure(áØÆ, áØÁ, áÍù=áÍù))

def ÄÔÙù(áØÆ=ÂÞÅ, áØÇ=ÂÞÅ, áØÁ=ÂÞÅ, ÁÜñ=ÂÞÅ):
    if ((áØÆ is not ÄÊPSH(ÂÞÅ) and ÄÊPOP() is not ÄÊPSH(áØÇ)) and (ÄÊDEL(1) or True) or (ÄÊDEL(1) or False)) and ((ÁØö(áØÆ, ÄÊPSH(áÍÞ)) and ÁØñ(ÄÊPOP(), ÄÊPSH(áØÇ))) and (ÄÊDEL(1) or True) or (ÄÊDEL(1) or False)):
        ÂùÆ(ÁÜñ is ÂÞÅ, '\U000f0931')
        return ÄÝöì('%s%s' % (ÄÝöì(ÂüÌ(áØÆ)), ÄÝöì(ÂüÌ(áØÇ)))) * (ÃÆí(áØÆ) * ÃÆí(áØÇ) or 1)
    if áØÇ is not ÂÞÅ:
        (áØÆ := [áØÆ, áØÇ])
    if ÁÜñ is not ÂÞÅ:
        if áÍù(ÁÜñ):
            return flatten_under(áØÆ, ÄÕÍÔ, áØÁ, [*ÁÜñ])
        return flatten_under(áØÆ, ÁÜñ, áØÁ)
    return flatten(áØÆ, áØÁ, áÍù=áÓö)
(ÄÝõÞ := (lambda áØÆ, áØÁ=ÂÕË: ÂÚü() if ÄÝøÇ(áØÆ, áÓö) else ÁØò(lambda ÂîÓ: ãÊú(ÂîÓ) if ÁØö(ÂîÓ, áÓö) else ÄÔýò)(ÂÕÅ(MOD(ÂØÎ, áØÁ=-áØÁ)(lambda ÂîÓ: ÂîÓ[0] if ãÊú(ÂîÓ) else 0, lambda ÂîÓ: ÄÝøÇ(ÂîÓ, áÓö) or ÁØö(ÂîÓ, ÁÜÙ)), áØÆ))))
(ÄÝõß := (lambda áØÆ, áØÁ=ÂÕË: ãÊú(MOD(ÄÝõÞ, áØÁ=áØÁ)(áØÆ))))
(ÐÈÔ := (lambda áØÆ, áØÇ, áØÁ=ÂÞÅ: MOD(ÆÑ, áØÁ=áØÆ)(ÂÀÇ(áØÇ), lambda x, y: MOD(ÁâÁ, áØÁ=y - 1)(x))))
(ÄÔÒØ := (lambda áØÆ, áØÁ=ÂÕË: MOD(ÄÔÙù, áØÁ=MOD(ÄÝõß, áØÁ=áØÁ)(áØÆ) - 1)(áØÆ)))

@OPWRAP_(*'⪡⪢')
def _(áÑã, áØÆ=ÂÞÅ, áØÇ=1, áØÁ=ÂÞÅ):
    if ÁØö(áØÆ, ÂÑÅ):
        return (áØÆ > ÄÊPSH(ÂýÃ) and ÄÊPOP() > ÄÊPSH(áØÇ)) and (ÄÊDEL(1) or True) or (ÄÊDEL(1) or False) if áÑã == '⪢' else (áØÆ < ÄÊPSH(ÂýÃ) and ÄÊPOP() < ÄÊPSH(áØÇ)) and (ÄÊDEL(1) or True) or (ÄÊDEL(1) or False)
    if áÑã == '⪡':
        (ÄÊPSH(áØÇ), ÄÊPSH(ÄÝöâ(ÄÊPKE(0))), (áØÇ := ÄÊPKE(0)), ÄÊDEL(2))[2]
    if áØÁ is ÂÞÅ:
        return áØÆ and áØÆ[slice((i := (-áØÇ % ãÊú(áØÆ))), None)] + áØÆ[slice(None, i)]
    return ÐÈÔ(MOD(ÄÔÒØ, áØÁ=áØÁ)(áØÆ), Âúú(MOD(ÄÝõÞ, áØÁ=áØÁ)(áØÆ), áØÇ))
__dir__=(__file__:=áÌî(moon_dir/'/home/ganer/Projects/Moon_BETA/Header/ugex.☾')).parent
class winder:

    def __init__(áÑÞ, áÖï, áÖõ=-1):
        (ÄÊPSH(áÑÞ), ÄÊPSH('áÖï'), ÄÊPSH(áÑÞ), ÄÊPSH('áÖõ'), ÄÊPSH(áÑÞ), ÄÊPSH('áÖà'), ÄÊPSH((áÖï, áÖõ, ÂÚü())), (setattr(ÄÊPKE(6), ÄÊPKE(5), ÄÊPKE(0)[0]), setattr(ÄÊPKE(4), ÄÊPKE(3), ÄÊPKE(0)[1]), setattr(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)[2])), ÄÊDEL(7))[7]
    (__bool__ := (lambda áÑÞ: getattr(áÑÞ, 'áÖõ') + 1 < ãÊú(getattr(áÑÞ, 'áÖï'))))
    (__repr__ := (lambda áÑÞ: '[%s│%s]⟨%s⟩' % (ÂîË(getattr(áÑÞ, 'áÖï')[slice(None, getattr(áÑÞ, 'áÖõ') + 1)], ' '), ÂîÊ(getattr(áÑÞ, 'áÖï')[slice(getattr(áÑÞ, 'áÖõ') + 1, None)], ' '), Âøî(getattr(áÑÞ, 'áÖà'), ' '))))
    (peek := (lambda áÑÞ: getattr(áÑÞ, 'áÖï')[getattr(áÑÞ, 'áÖõ') + 1]))
    (next := (lambda áÑÞ: getattr(áÑÞ, 'áÖï')[(ÄÊPSH(áÑÞ), ÄÊPSH('áÖõ'), ÄÊPSH(getattr(ÄÊPKE(1), ÄÊPKE(0))), ÄÊPSH(ÄÊPKE(0) + 1), setattr(ÄÊPKE(3), ÄÊPKE(2), ÄÊPKE(0)), ÄÊDEL(4))[4]]))
    (note := (lambda áÑÞ: ÂåÔ(getattr(getattr(áÑÞ, 'áÖà'), 'append')(getattr(áÑÞ, 'áÖõ')), áÑÞ)))
    (eton := (lambda áÑÞ: ÂåÔ(ÐÌü(getattr(getattr(áÑÞ, 'áÖà'), 'pop')), áÑÞ)))
    (wind := (lambda áÑÞ: ÂåÔ((ÄÊPSH(áÑÞ), ÄÊPSH('áÖõ'), ÄÊPSH(ÐÌü(getattr(getattr(áÑÞ, 'áÖà'), 'pop'))), setattr(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3], áÑÞ)))
(ARROW_TARG := ÂÚü())

def ÄÝöç(áØÆ, áØÁ=ÂÞÅ):
    (áÖí := ARROW_TARG[-1])
    if áØÁ is ÂÞÅ:
        getattr(áÖí, 'append')(áØÆ)
        return áØÆ
    if áØÁ == ÂÕË:
        getattr(áÖí, 'extend')(áØÆ)
        return áØÆ
    getattr(áÖí, 'extend')((h := MOD(Âêà, áØÁ=áØÁ)(áØÆ)))
    return h

def ÄÝöè(áØÁ=ÂÞÅ):
    (áÖí := ARROW_TARG[-1])
    if áØÁ is ÂÞÅ:
        return getattr(áÖí, 'pop')(-1)
    if áØÁ == ÂÕË:
        (r := áÖí[slice(None, None)])
        del áÖí[slice(None, None)]
        return r
    if (ÄÊPSH(áØÁ), ÄÊPSH(ÄÊPKE(0) * -1 == 0), (áØÁ := ÄÊPKE(0)), ÄÊDEL(2))[2]:
        return ÂÚü()
    (r := áÖí[slice(áØÁ, None)])
    del áÖí[slice(áØÁ, None)]
    return r

def ÂÛÒ(áØÁ=ÂÞÅ):
    (áÖí := ARROW_TARG[-1])
    if áØÁ is ÂÞÅ:
        return áÖí[-1]
    if áØÁ == ÂÕË:
        return áÖí[slice(None, None)]
    if (ÄÊPSH(áØÁ), ÄÊPSH(ÄÊPKE(0) * -1 == 0), (áØÁ := ÄÊPKE(0)), ÄÊDEL(2))[2]:
        return ÂÚü()
    return áÖí[slice(áØÁ, None)]
(UGX_CREATE := (lambda x, d=False: lambda ÂîÓ: d if (y := UGX_RUN(winder([*ÂîÓ]), x)) is ÂÞÅ else y[0]))

def UGX_SCAN(áÖÿ, Æå, áÓà):
    if not áÖÿ:
        return ÂÚü() if '*' == áÓà or áÓà == '?' else ÂÞÅ
    (áÍí := Æå((p := ÐÌü(getattr(áÖÿ, 'peek')))))
    if áÓà == '¬':
        return ÂÞÅ if áÍí else ÂÚü()
    if áÓà == '⮞':
        return ÂÚü() if áÍí else ÂÞÅ
    if not áÍí:
        return ÂÞÅ if áÓà in '+' else ÂÚü()
    (V := (ÂÚü() if ÐÌü(getattr(áÖÿ, 'next')) is ÄÔýò or ÄÔýò is áÍí else Âêà(p)))
    if áÓà in '?':
        return V
    while áÖÿ:
        if not (v := Æå((p := ÐÌü(getattr(áÖÿ, 'peek'))))):
            break
        if v is ÄÔýò or ÄÔýò is ÐÌü(getattr(áÖÿ, 'next')):
            continue
        getattr(V, 'append')(p)
    return V

def UGX_RUN(áÖÿ, áØÃ):
    (ÄÊPSH(áØÃ), ((áÓç := ÄÊPKE(0)[0]), *(áÒø := ÄÊPKE(0)[slice(1, None, None)])), ÄÊDEL(1))[1]
    if ÁØö(áÓç, áÓó):
        return UGX_SCAN(áÖÿ, áÓç, áÒø[0])
    elif áÓç in 'BP':
        (ÄÊPSH(áÒø), ((áÓæ := ÄÊPKE(0)[0]), (áÓà := ÄÊPKE(0)[1]), (áÓå := ÄÊPKE(0)[2]), (áÓÕ := ÄÊPKE(0)[3])), ÄÊDEL(1))[1]
        getattr(ARROW_TARG, 'append')(áÓæ)
        ÂåÔ(ÐÌü(getattr(áÖÿ, 'note')), (V := (r := UGX_RUN(áÖÿ, áÓÕ))))
        if áÓà == '⮞':
            ÂåÔ(ÐÌü(getattr(áÖÿ, 'wind')), (V := (ÂÞÅ if r is ÂÞÅ else ÂÚü())))
        elif áÓà == '¬':
            ÂåÔ(ÐÌü(getattr(áÖÿ, 'wind')), (V := (ÂÚü() if r is ÂÞÅ else ÂÞÅ)))
        elif áÓà == '?':
            ÂåÔ(ÐÌü(getattr(áÖÿ, 'wind')), (V := (ÂÚü() if r is ÂÞÅ else ÂÞÅ)))
        elif r is ÂÞÅ:
            ÂåÔ(ÐÌü(getattr(áÖÿ, 'wind')), (V := (ÂÚü() if áÓà == '∗' else ÂÞÅ)))
        elif áÓà not in '?':
            while áÖÿ:
                ÂåÔ(ÐÌü(getattr(áÖÿ, 'note')), (r := UGX_RUN(áÖÿ, áÓÕ)))
                if r is ÂÞÅ:
                    ÐÌü(getattr(áÖÿ, 'wind'))
                    break
                ÂåÔ(ÐÌü(getattr(áÖÿ, 'eton')), getattr(V, 'extend')(r))
            ÐÌü(getattr(áÖÿ, 'eton'))
        if áÓå is ÄÔýò:
            (V := ÂÚü())
        if V is not ÂÞÅ and áÓó(áÓå):
            (V := áÓå(V))
        getattr(ARROW_TARG, 'pop')(-1)
        if V is ÂÞÅ:
            return V
        return MOD(Áëý, áØÁ=áÓç == 'B')(V, Âêà)
    elif áÓç in '∧∨':
        if áÓç == '∧':
            ÂåÔ(ÐÌü(getattr(áÖÿ, 'note')), (V := ÂÚü()))
            for U in áÒø:
                if (r := UGX_RUN(áÖÿ, U)) is ÂÞÅ:
                    return ÂåÔ(ÐÌü(getattr(áÖÿ, 'wind')), ÂÞÅ)
                getattr(V, 'extend')(r)
            return ÂåÔ(ÐÌü(getattr(áÖÿ, 'eton')), V)
        elif áÓç == '∨':
            for U in áÒø:
                ÐÌü(getattr(áÖÿ, 'note'))
                if (r := UGX_RUN(áÖÿ, U)) is not ÂÞÅ:
                    return ÂåÔ(ÐÌü(getattr(áÖÿ, 'eton')), r)
                ÐÌü(getattr(áÖÿ, 'wind'))
            return ÂÞÅ
__dir__=(__file__:=áÌî(moon_dir/'/home/ganer/Projects/Moon_BETA/Header/ℵ.☾')).parent
class aleph_wrapper:
    (__slots__ := ('x',))
    (__init__ := (lambda áÑÞ, y: Âåß(None, (ÄÊPSH(áÑÞ), ÄÊPSH('x'), ÄÊPSH(y), setattr(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3])))
    (__repr__ := (lambda áÑÞ: getattr(áÑÞ, 'x')))
    (__call__ := (lambda áÑÞ, *áÑË, **áÑÕ: getattr(áÑÞ, 'x')(*áÑË, **áÑÕ)))

class ÂÑÖ(áÍÙ):
    (áÌüþáÍã := 'ℵ')

    def __getitem__(áÑÞ, x):
        if x in áÑÞ:
            return getattr(áÍÙ, '__getitem__')(áÑÞ, x)
        if getattr(áÑÞ, 'hasdef')():
            return getattr(áÑÞ, 'getdef')(x)
        ÐâÄ(KeyError('%s ∉ %s, and I have no default value!' % (x, áÑÞ)))

    def __init__(áÑÞ, *áÑË, áØÁ=ÂÞÅ, **áÑÕ):
        getattr(super(), '__init__')(*áÑË, **áÑÕ)
        if áØÁ is not ÂÞÅ:
            getattr(áÑÞ, 'setdef')(áØÁ)
    (__repr__ := (lambda áÑÞ: '%s%s(%s)' % (getattr(getattr(áÑÞ, '__class__'), 'áÌüþáÍã'), '[%s]' % (h[0] or 'ᐦ',) if 0 in (h := getattr(áÑÞ, '__dict__')) else ÁØã, Âøî(ËãÂ(ÐÌü(getattr(áÑÞ, 'items')), lambda x, y: '%s=%s' % (x, y)), ', '))))
    (__json__ := (lambda áÑÞ, cb, *áÏÞ, **áÏè: MOD(ËãÂ, áØÁ=ì)(áÍÙ(áÑÞ), lambda x, y: cb(y, *áÏÞ, **áÏè))))
    (__iter__ := (lambda áÑÞ: iter(getattr(áÑÞ, 'items')())))
    (__call__ := (lambda áÑÞ, *áÑË, **áÑÕ: ÂåÔ(getattr(áÍÙ, 'update')(áÑÞ, *áÑË, **áÑÕ), áÑÞ)))
    (__bool__ := (lambda áÑÞ: ãÊú(áÑÞ) > 0))
    (__or__ := (lambda áÑÞ, x: getattr(áÑÞ, 'copy')()(x)))
    (__setattr__ := getattr(áÍÙ, '__setitem__'))
    (__getattr__ := __getitem__)

    def __getstate__(áÑÞ):
        if getattr(áÑÞ, 'hasdef')():
            return (áÍÙ(áÑÞ), getattr(áÑÞ, 'getdef')())
        else:
            return (áÍÙ(áÑÞ),)

    def __setstate__(áÑÞ, s):
        getattr(áÑÞ, '__init__')(s[0])
        if ãÊú(s) > 1:
            getattr(áÑÞ, 'setdef')(s[1])

    def __pow__(áÑÞ, x):
        if x is î:
            return [*ÐÌü(getattr(áÑÞ, 'keys'))]
        if x is ì:
            return [*ÐÌü(getattr(áÑÞ, 'values'))]
        if x is ë:
            return [*ÐÌü(getattr(áÑÞ, 'items'))]
        if x is ÂÕì:
            return MOD(Áÿú, áØÁ=ë)(áÑÞ, ÂÀÇ)
        if x is Áâ:
            return MOD(Áëý, áØÁ=ÄÝøÇ((v := ÐÌü(getattr(áÑÞ, 'getdef'))), (C := aleph_wrapper)))(ÐÌü(getattr(áÑÞ, 'copy')), lambda x: getattr(x, 'setdef')(C(v)))
        ÂùÆ(False)
    (hasdef := (lambda áÑÞ: 0 in getattr(áÑÞ, '__dict__')))
    (setdef := (lambda áÑÞ, x: ÂåÔ((ÄÊPSH(getattr(áÑÞ, '__dict__')), ÄÊPSH(0), ÄÊPSH(x), setitem(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3], áÑÞ)))

    def getdef(áÑÞ, k=ÂÞÅ):
        (d := getattr(áÑÞ, '__dict__')[0])
        if ÁØö(d, aleph_wrapper):
            (ÄÊPSH(d), ÄÊPSH(ÐÌü(ÄÊPKE(0))), (d := ÄÊPKE(0)), ÄÊDEL(2))[2]
            (ÄÊPSH(áÑÞ), ÄÊPSH(k), ÄÊPSH(d), setitem(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3]
        return d

    def copy(áÑÞ):
        (r := type(áÑÞ)(getattr(super(), 'copy')()))
        if getattr(áÑÞ, 'hasdef')():
            getattr(r, 'setdef')(getattr(áÑÞ, 'getdef')())
        return r

class ÂÑØ(ÂÑÖ):
    (áÌüþáÍã := 'ℶ')
    (__iter__ := (lambda áÑÞ: iter(getattr(áÑÞ, 'values')())))

class _hwrap(áÍÙ):

    def __init__(áÑÞ, áÍØ):
        (ÄÊPSH(áÑÞ), ÄÊPSH('áÍØ'), ÄÊPSH(áÑÞ), ÄÊPSH('áÍã'), ÄÊPSH((áÍØ, getattr(áÍØ, 'áÌüþáÍã'))), (setattr(ÄÊPKE(4), ÄÊPKE(3), ÄÊPKE(0)[0]), setattr(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)[1])), ÄÊDEL(5))[5]
    (__getitem__ := (lambda áÑÞ, x: getattr(getattr(áÑÞ, 'áÍØ')(), 'setdef')(x)))
    (__setitem__ := (lambda áÑÞ, x, y: ÂåÔ(getattr((Âàü := getattr(áÑÞ, 'áÍØ')()), '__setitem__')(x, y), Âàü)))
    (__call__ := (lambda áÑÞ, *áÑË, **áÑÕ: getattr(áÑÞ, 'áÍØ')(*áÑË, **áÑÕ)))
    (__or__ := (lambda áÑÞ, x: getattr(áÑÞ, 'áÍØ')() | x))
    (__pow__ := (lambda áÑÞ, x: getattr(áÑÞ, 'áÍØ')() ** x))
    (__repr__ := (lambda áÑÞ: '%s()' % (getattr(áÑÞ, 'áÍã'),)))
    (__bool__ := (lambda: False))
(ÂÑÖ := _hwrap(ÂÑÖ))
(ÂÑØ := _hwrap(ÂÑØ))
__dir__=(__file__:=áÌî(moon_dir/'/home/ganer/Projects/Moon_BETA/Header/!.☾')).parent
def ÏÀ(z):
    if ÄÝõè(z) < ÃÆ:
        return ÂÞÅCAT(Ïò, Ãù) / ((ÂÐæ ** ÂÞÅCAT(ÂÞÅCAT(Ãù, Ïî), z) - ÂÐæ ** ÂÞÅCAT(ÂÞÅCAT(ÄÝîâ, Ïî), z)) * ÏÀ(1 - z))
    (p := [1.000000000190015, 76.18009172947146, -86.50532032941676, 24.01409824083091, -1.2317395724501554, 0.0012086509738661786, -5.395239384953128e-06])
    return MOD(ÂøÑ, áØÁ=p[0])(ÁÙÇ(lambda ÂîÒ: p[ÂîÒ] / (z + ÂîÒ))(ÄÝöÊ(1, 6))) * ÂÐæ ** (-5.5 - z) * (5.5 + z) ** (ÃÆ + z) * ÂÕÇ(Ïò) / z

def â(áØÆ, áØÁ=ÂÞÅ):
    if áØÁ is ÂÞÅ:
        if ÁØö(áØÆ, ÂÑÅ):
            return nan if áØÆ < 0 else MOD(ÂøÐ, áØÁ=1)(ÄÝöÉ(0, áÍÞ(áØÆ)))
        return áØÆ * ÏÀ(áØÆ)
    if ÁØö(áØÁ, áÍÞ):
        return MOD(ÂøÐ, áØÁ=1)(ÁØò(lambda ÂîÓ: ÂîÓ + áØÆ)(ÂÿÇ(áØÁ)))
    if ÁØö(áØÁ, ÂÐá):
        if áØÆ == 0:
            return 1
        if (d := Âüð(ÄÝõç(áØÁ))) >= 0 and áØÆ > 0:
            return ÂÕË
        if d <= 0 and áØÆ < 0:
            return nan
        (ÄÊPSH((1, áØÆ)), ((t := ÄÊPKE(0)[0]), (c := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
        while ÃÆí(c) == ÃÆí(áØÆ):
            (ÄÊPSH(t), ÄÊPSH(ÄÊPKE(0) * c), (t := ÄÊPKE(0)), ÄÊDEL(2))[2]
            (ÄÊPSH(c), ÄÊPSH(ÄÊPKE(0) + d), (c := ÄÊPKE(0)), ÄÊDEL(2))[2]
        return t
    if ÁØö(áØÁ, áÓö):
        return MOD(ÂøÐ, áØÁ=1)(ÁØò(lambda ÂîÓ: ÂîÓ * áØÁ[-1] + áØÆ)(ÂÿÇ(áØÁ[0])))
    ÂùÆ(False, 'what do you meeeeaaaaaannnnnn!?!?!?')
__dir__=(__file__:=áÌî(moon_dir/'/home/ganer/Projects/Moon_BETA/Header/𝔍.☾')).parent
(áÐÞ := ÂÞÅCAT({ÁÁ: ÄÊCUR((1,), {'ensure_ascii': False, 'indent': None, 'separators': ',:'}, jdumps__, ÂýÃ), ÿ: jloads__}, ÂÑÖ()))
__dir__=(__file__:=áÌî(moon_dir/'/home/ganer/Projects/Moon_BETA/Header/🌈.☾')).parent
def h2r(c=ÁØã):
    if ÁØö(c, áÍÞ):
        (ÄÊPSH(c), ÄÊPSH(MOD(ÄÝöì, áØÁ=16)(ÄÊPKE(0))), (c := ÄÊPKE(0)), ÄÊDEL(2))[2]
    (c := getattr(getattr(c, 'strip')(), 'lstrip')('#'))
    if getattr(c, 'startswith')('0x'):
        (ÄÊPSH(c), ÄÊPSH(ÄÊPKE(0)[slice(2, None)]), (c := ÄÊPKE(0)), ÄÊDEL(2))[2]
    (ÄÊPSH((ÄÊCUR((1,), {}, áÍÞ, ÂýÃ, 16), ãÊú(c))), ((ÂÐí := ÄÊPKE(0)[0]), (n := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    if n == 0:
        return (0, 0, 0, 255)
    if n == 1:
        return (ÂÕÅ(ÂÐí, c[0] * 2), ÂÕÅ(ÂÐí, c[0] * 2), ÂÕÅ(ÂÐí, c[0] * 2), 255)
    if n == 2:
        return (ÂÕÅ(ÂÐí, c[0] * 2), ÂÕÅ(ÂÐí, c[0] * 2), ÂÕÅ(ÂÐí, c[0] * 2), ÂÕÅ(ÂÐí, c[1] * 2))
    if n == 3:
        return (ÂÕÅ(ÂÐí, c[0] * 2), ÂÕÅ(ÂÐí, c[1] * 2), ÂÕÅ(ÂÐí, c[2] * 2), 255)
    if n == 4:
        return (ÂÕÅ(ÂÐí, c[0] * 2), ÂÕÅ(ÂÐí, c[1] * 2), ÂÕÅ(ÂÐí, c[2] * 2), ÂÕÅ(ÂÐí, c[3] * 2))
    if n == 5:
        return (ÂÕÅ(ÂÐí, c[0] * 2), ÂÕÅ(ÂÐí, c[1] * 2), ÂÕÅ(ÂÐí, c[2] * 2), ÂÕÅ(ÂÐí, c[slice(3, 5)]))
    if n == 6:
        return (ÂÕÅ(ÂÐí, c[slice(0, 2)]), ÂÕÅ(ÂÐí, c[slice(2, 4)]), ÂÕÅ(ÂÐí, c[slice(4, 6)]), 255)
    if n == 7:
        return (ÂÕÅ(ÂÐí, c[slice(0, 2)]), ÂÕÅ(ÂÐí, c[slice(2, 4)]), ÂÕÅ(ÂÐí, c[slice(4, 6)]), ÂÕÅ(ÂÐí, c[6] * 2))
    if n == 8:
        return (ÂÕÅ(ÂÐí, c[slice(0, 2)]), ÂÕÅ(ÂÐí, c[slice(2, 4)]), ÂÕÅ(ÂÐí, c[slice(4, 6)]), ÂÕÅ(ÂÐí, c[slice(6, 8)]))
(r2hl := (lambda x: '#%s' % (Âøî(Áÿú(x, MOD(ÄÝöì, áØÁ=16 + ÂÞÅCAT(2, Ãù)))),)))
(h2hl := Âåæ(r2hl, h2r))
(TERM_RESET := '\x1b[0m')

def termclr(t, fg=None, bg=None, rst=True, rl=False):
    (rlw := (lambda x: '\x01%s\x02' % (x,) if rl else x))
    (mkc := Âåæ(rlw, lambda x, y, z, w, v: '\x1b[%s;2;%s;%s;%sm' % (x, y, z, w)))
    (R := Âøî([mkc(n, *h2r(c)) for c, n in ÄÕåØ([fg, bg], [38, 48]) if c is not None]))
    return '%s%s%s' % (R, t, ÂÕÅ(rlw, TERM_RESET) if rst else ÁØã)
__dir__=(__file__:=áÌî(moon_dir/'/home/ganer/Projects/Moon_BETA/Header/kots.☾')).parent
(TMPDIR := ð(ÂÞÅCAT(ÐÌü(gettempdir), áÌî), 'tmp_☾'))
(mkd := (lambda f, e=True, p=True: ÂåÔ(getattr((p := áÌî(f)), 'mkdir')(exist_ok=e, parents=p), p)))
(mkf := (lambda f, e=True: ÂåÔ(getattr(mkd(getattr((p := áÌî(f)), 'parent')), 'touch')(exist_ok=e), p)))
(tmpf := (lambda b=ÁØã, f=ÂÞÅ, n=14: mkf(ð(ð(TMPDIR, b), Âøî(ÄÔÙù(MOD(ÐâÇ, áØÁ=1)(abcABC123, n))) if f is ÂÞÅ else f))))
(tmpd := (lambda b=ÁØã, f=ÂÞÅ, n=14: mkd(ð(ð(TMPDIR, b), Âøî(ÄÔÙù(MOD(ÐâÇ, áØÁ=1)(abcABC123, n))) if f is ÂÞÅ else f))))

class suppar2:
    (__init__ := (lambda áÑÞ, Æå: ÂåÔ((ÄÊPSH(Æå), ÄÊPSH(áÑÞ), ÄÊPSH('Æå'), setattr(ÄÊPKE(1), ÄÊPKE(0), ÄÊPKE(2)), ÄÊDEL(3))[3], None)))
    (__call__ := (lambda áÑÞ, *áÑË, **áÑÕ: getattr(áÑÞ, 'Æå')(*áÑË, **áÑÕ)))
    (__getitem__ := (__getattr__ := (lambda áÑÞ, x, *áÑË, **áÑÕ: lambda *áÑË, **áÑÕ: getattr(áÑÞ, 'Æå')(*áÑË, x, **áÑÕ))))
(ÐâÒ := (lambda x=ÂÞÅ: ÐÌü(PL_TEXT_PASTE) if x is ÂÞÅ else ÂåÔ(ÂÞÅCAT(ÂÞÅCAT(x, ÁÜÙ), PL_TEXT_COPY), x)))
(ÐÈÃ := suppar2(lambda f, o=ÁØã: getattr(áÌî(f), 'open')(o)))
(ÐØó := suppar2(lambda f, o=ÁØã: Âáõ((y := ÐÈÃ['r' + o](f)), lambda x: ÐÌü(getattr(x, 'read')))))
(ÐØì := suppar2(lambda f, áÏû, o=ÁØã: Âáõ((y := ÐÈÃ['w' + o](f)), lambda x: ÂåÔ(getattr(x, 'write')(áÏû), y))))
(pwd := (lambda: áÌî(ÐÌü(getattr(os, 'getcwd')))))

class cd:
    (ÄÊPSH(MOD(ÂÚü, áØÁ=2)()), ((s := ÄÊPKE(0)[0]), (c := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]

    def __init__(áÑÞ, d=None):
        (ÄÊPSH(áÑÞ), ÄÊPSH('d'), ÄÊPSH(d), setattr(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3]

    def __enter__(áÑÞ):
        (x := getattr(áÑÞ, 'd'))
        getattr(getattr(cd, 's'), 'append')((ãÊú(getattr(cd, 'c')), (x := ÐÌü(pwd))))
        if x is not None:
            getattr(os, 'chdir')(áÌî(x))
        return ÐÌü(pwd)

    def __exit__(áÑÞ, *áÑË):
        (ÄÊPSH(getattr(getattr(cd, 's'), 'pop')(-1)), ((i := ÄÊPKE(0)[0]), (d := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
        (ÄÊPSH(cd), ÄÊPSH('c'), ÄÊPSH(getattr(cd, 'c')[slice(None, i)]), setattr(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3]
        getattr(os, 'chdir')(d)
        return ÐÌü(pwd)

    def __call__(áÑÞ, d=None):
        if d is ÁÃ:
            return cd(getattr(áÌî(getattr(getattr(inspect, 'stack')()[1], 'filename')), 'parent'))
        if d is None:
            getattr(os, 'chdir')(getattr(getattr(cd, 'c'), 'pop')(-1))
            return ÐÌü(pwd)
        getattr(getattr(cd, 'c'), 'append')(ÐÌü(pwd))
        getattr(os, 'chdir')(d)
        return ÐÌü(pwd)

    def __getitem__(áÑÞ, d):
        return getattr(áÑÞ, '__class__')(d)
(cd := ÐÌü(cd))

def sha(*áÑË, **áÑÕ):
    from hashlib import sha256 as _sha256
    from base64 import urlsafe_b64encode, urlsafe_b64decode
    return getattr(áÍÇ(urlsafe_b64encode(getattr(_sha256(áÍÇ(ÁÜÙ(áÑË) + ÁÜÙ(áÑÕ))), 'digest')())), 'rstrip')('=')
__dir__=(__file__:=áÌî(moon_dir/'/home/ganer/Projects/Moon_BETA/Header/extra_globals.☾')).parent
(FRAC_CONV := {**dict(ÄÕåØ(ÂÛê('12\u200913\u200914\u200915\u200916\u200917\u200918\u200919\u2009110\u200923\u200925\u200927\u200929\u200934\u200935\u200937\u200938\u2009310\u200945\u200947\u200949\u200956\u200957\u200958\u200959\u200967\u200978\u200979\u2009710\u200989\u2009910\u200903\u20091100'), '½⅓¼⅕⅙⅐⅛⅑⅒⅔⅖\U000f7db2\U000f7db7¾⅗\U000f7db3⅜\U000f7dc6⅘\U000f7db4\U000f7dc2⅚\U000f7db5⅝\U000f7db9\U000f7db6⅞\U000f7dba\U000f7dc7\U000f7dbb\U000f7dc8↉\U000f7dc9'))})
(TOFRAC := (lambda x: getattr(FRAC_CONV, 'get')(x, x)))

class UPSIDEDOWNSYNDROME:
    (NRM := '0123456789abcdefoxABCDEFOXîĵ\U000f7e88ℇτπ\U000f7e8d\U000f7e8f∞')
    (USD := '\U000f7c3d\U000f7c3e\U000f7c3f\U000f7c40\U000f7c41\U000f7c42\U000f7c43\U000f7c44\U000f7c45\U000f7c46\U000f7c47\U000f7c48\U000f7c49\U000f7c4a\U000f7c4b\U000f7c4c\U000f7c4d\U000f7c4e\U000f7c4f\U000f7c50\U000f7c51\U000f7c52\U000f7c53\U000f7c54\U000f7c55\U000f7c56\U000f7c6a\U000f7c7d\U000f7c7e\U000f7c6b\U000f7c6c\U000f7c6d\U000f7c6e\U000f7c70\U000f7c69')
    (MAP := ({**dict(ÄÕåØ(NRM, USD))} | {**dict(ÄÕåØ(USD, NRM))}))
    (flip := (lambda x, m=MAP: Âøî(ÁØò(lambda ÂîÓ: getattr(m, 'get')(ÂîÓ, ÂîÓ))(x), ÁØã)))

class SCRIPT:
    (SCRIPT_FILE_LOC := ð(moon_dir, 'STAGES/.SCRIPT_MAP'))
    (ÄÊPSH(ÄÝöÞ(ÐÌü(getattr(ÐØó(SCRIPT_FILE_LOC), 'strip')), '\n')), ((CHAR_NRM := ÄÊPKE(0)[0]), (CHAR_SUP := ÄÊPKE(0)[1]), (CHAR_SUB := ÄÊPKE(0)[2])), ÄÊDEL(1))[1]
    (SUP := getattr(ÁÜÙ, 'maketrans')(CHAR_NRM, CHAR_SUP))
    (SUB := getattr(ÁÜÙ, 'maketrans')(CHAR_NRM, CHAR_SUB))
    (NRM := getattr(ÁÜÙ, 'maketrans')(CHAR_SUP + CHAR_SUB, ÂÞÅCAT(2, CHAR_NRM)))
    (ÄÊPSH(Áÿú([SUP, SUB, NRM], lambda áÖæ: lambda x: getattr(x, 'translate')(áÖæ))), ((sup := ÄÊPKE(0)[0]), (sub := ÄÊPKE(0)[1]), (nrm := ÄÊPKE(0)[2])), ÄÊDEL(1))[1]
(ÄÊPSH((getattr(SCRIPT, 'sup'), getattr(SCRIPT, 'sub'), getattr(SCRIPT, 'nrm'))), ((supscript := ÄÊPKE(0)[0]), (subscript := ÄÊPKE(0)[1]), (nrmscript := ÄÊPKE(0)[2])), ÄÊDEL(1))[1]
(ÄÊPSH((getattr(SCRIPT, 'CHAR_SUP'), getattr(SCRIPT, 'CHAR_SUB'))), ((SUPSCRIPT := ÄÊPKE(0)[0]), (SUBSCRIPT := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
(ALPHABETS := Áÿú(ÄÝöÞ(Âüá('\n    abcdefghijklmnopqrstuvwxyz\u2009ABCDEFGHIJKLMNOPQRSTUVWXYZ\u20090123456789\n    𝕒𝕓𝕔𝕕𝕖𝕗𝕘𝕙𝕚𝕛𝕜𝕝𝕞𝕟𝕠𝕡𝕢𝕣𝕤𝕥𝕦𝕧𝕨𝕩𝕪𝕫\u2009𝔸𝔹ℂ𝔻𝔼𝔽𝔾ℍ𝕀𝕁𝕂𝕃𝕄ℕ𝕆ℙℚℝ𝕊𝕋𝕌𝕍𝕎𝕏𝕐ℤ\u2009𝟘𝟙𝟚𝟛𝟜𝟝𝟞𝟟𝟠𝟡\n    𝐚𝐛𝐜𝐝𝐞𝐟𝐠𝐡𝐢𝐣𝐤𝐥𝐦𝐧𝐨𝐩𝐪𝐫𝐬𝐭𝐮𝐯𝐰𝐱𝐲𝐳\u2009𝐀𝐁𝐂𝐃𝐄𝐅𝐆𝐇𝐈𝐉𝐊𝐋𝐌𝐍𝐎𝐏𝐐𝐑𝐒𝐓𝐔𝐕𝐖𝐗𝐘𝐙\u2009𝟎𝟏𝟐𝟑𝟒𝟓𝟔𝟕𝟖𝟗\n    𝑎𝑏𝑐𝑑𝑒𝑓𝑔ℎ𝑖𝑗𝑘𝑙𝑚𝑛𝑜𝑝𝑞𝑟𝑠𝑡𝑢𝑣𝑤𝑥𝑦𝑧\u2009𝐴𝐵𝐶𝐷𝐸𝐹𝐺𝐻𝐼𝐽𝐾𝐿𝑀𝑁𝑂𝑃𝑄𝑅𝑆𝑇𝑈𝑉𝑊𝑋𝑌𝑍\u2009◌◌◌◌◌◌◌◌◌◌\n    𝗮𝗯𝗰𝗱𝗲𝗳𝗴𝗵𝗶𝗷𝗸𝗹𝗺𝗻𝗼𝗽𝗾𝗿𝘀𝘁𝘂𝘃𝘄𝘅𝘆𝘇\u2009𝗔𝗕𝗖𝗗𝗘𝗙𝗚𝗛𝗜𝗝𝗞𝗟𝗠𝗡𝗢𝗣𝗤𝗥𝗦𝗧𝗨𝗩𝗪𝗫𝗬𝗭\u2009𝟬𝟭𝟮𝟯𝟰𝟱𝟲𝟳𝟴𝟵\n    𝚊𝚋𝚌𝚍𝚎𝚏𝚐𝚑𝚒𝚓𝚔𝚕𝚖𝚗𝚘𝚙𝚚𝚛𝚜𝚝𝚞𝚟𝚠𝚡𝚢𝚣\u2009𝙰𝙱𝙲𝙳𝙴𝙵𝙶𝙷𝙸𝙹𝙺𝙻𝙼𝙽𝙾𝙿𝚀𝚁𝚂𝚃𝚄𝚅𝚆𝚇𝚈𝚉\u2009𝟶𝟷𝟸𝟹𝟺𝟻𝟼𝟽𝟾𝟿\n    ⓐⓑⓒⓓⓔⓕⓖⓗⓘⓙⓚⓛⓜⓝⓞⓟⓠⓡⓢⓣⓤⓥⓦⓧⓨⓩ\u2009ⒶⒷⒸⒹⒺⒻⒼⒽⒾⒿⓀⓁⓂⓃⓄⓅⓆⓇⓈⓉⓊⓋⓌⓍⓎⓏ\u2009◌\U000f0ca1\U000f0ca3\U000f0ca5\U000f0ca7\U000f0ca9\U000f0cab\U000f0cad\U000f0caf\U000f0cb1\n    ⒜⒝⒞⒟⒠⒡⒢⒣⒤⒥⒦⒧⒨⒩⒪⒫⒬⒭⒮⒯⒰⒱⒲⒳⒴⒵\u2009🄐🄑🄒🄓🄔🄕🄖🄗🄘🄙🄚🄛🄜🄝🄞🄟🄠🄡🄢🄣🄤🄥🄦🄧🄨🄩\u2009◌⑴⑵⑶⑷⑸⑹⑺⑻⑼\n    \U000f0aee\U000f0aef\U000f0af0\U000f0af1\U000f0af2\U000f0af3\U000f0af4\U000f0af5\U000f0af6\U000f0af7\U000f0af8\U000f0af9\U000f0afa\U000f0afb\U000f0afc\U000f0afd\U000f0afe\U000f0aff\U000f0b00\U000f0b01\U000f0b02\U000f0b03\U000f0b04\U000f0b05\U000f0b06\U000f0b07\u2009\U000f0aee\U000f0aef\U000f0af0\U000f0af1\U000f0af2\U000f0af3\U000f0af4\U000f0af5\U000f0af6\U000f0af7\U000f0af8\U000f0af9\U000f0afa\U000f0afb\U000f0afc\U000f0afd\U000f0afe\U000f0aff\U000f0b00\U000f0b01\U000f0b02\U000f0b03\U000f0b04\U000f0b05\U000f0b06\U000f0b07\u2009\U000f0b39\U000f0b3a\U000f0b3b\U000f0b3c\U000f0b3d\U000f0b3e\U000f0b3f\U000f0b40\U000f0b41\U000f0b42\n    \U0001ccd6\U0001ccd7\U0001ccd8\U0001ccd9\U0001ccda\U0001ccdb\U0001ccdc\U0001ccdd\U0001ccde\U0001ccdf\U0001cce0\U0001cce1\U0001cce2\U0001cce3\U0001cce4\U0001cce5\U0001cce6\U0001cce7\U0001cce8\U0001cce9\U0001ccea\U0001cceb\U0001ccec\U0001cced\U0001ccee\U0001ccef\u2009\U0001ccd6\U0001ccd7\U0001ccd8\U0001ccd9\U0001ccda\U0001ccdb\U0001ccdc\U0001ccdd\U0001ccde\U0001ccdf\U0001cce0\U0001cce1\U0001cce2\U0001cce3\U0001cce4\U0001cce5\U0001cce6\U0001cce7\U0001cce8\U0001cce9\U0001ccea\U0001cceb\U0001ccec\U0001cced\U0001ccee\U0001ccef\u2009\U0001ccf0\U0001ccf1\U0001ccf2\U0001ccf3\U0001ccf4\U0001ccf5\U0001ccf6\U0001ccf7\U0001ccf8\U0001ccf9\n    𝖺𝖻𝖼𝖽𝖾𝖿𝗀𝗁𝗂𝗃𝗄𝗅𝗆𝗇𝗈𝗉𝗊𝗋𝗌𝗍𝗎𝗏𝗐𝗑𝗒𝗓\u2009𝖠𝖡𝖢𝖣𝖤𝖥𝖦𝖧𝖨𝖩𝖪𝖫𝖬𝖭𝖮𝖯𝖰𝖱𝖲𝖳𝖴𝖵𝖶𝖷𝖸𝖹\u2009𝟢𝟣𝟤𝟥𝟦𝟧𝟨𝟩𝟪𝟫\n    ɒც𝼝𝼥⋿ꬵꬶҕї𝼚𝼐ꬷӍꬼϙƿ𝼛Ʀ𝼞ŧꭒѵꭐꭘꭚƶ\u2009ѦƁƇƊᗴҒႺⴼΙɈⴿꝈⱮͶⴲƤꝖⴽႽƬŲѴϢҲⵖΖ\u2009◌◌◌◌◌◌◌◌◌◌\n    𝘢𝘣𝘤𝘥𝘦𝘧𝘨𝘩𝘪𝘫𝘬𝘭𝘮𝘯𝘰𝘱𝘲𝘳𝘴𝘵𝘶𝘷𝘸𝘹𝘺𝘻\u2009𝘈𝘉𝘊𝘋𝘌𝘍𝘎𝘏𝘐𝘑𝘒𝘓𝘔𝘕𝘖𝘗𝘘𝘙𝘚𝘛𝘜𝘝𝘞𝘟𝘠𝘡\u2009◌◌◌◌◌◌◌◌◌◌\n    𝒶𝒷𝒸𝒹ℯ𝒻ℊ𝒽𝒾𝒿𝓀𝓁𝓂𝓃ℴ𝓅𝓆𝓇𝓈𝓉𝓊𝓋𝓌𝓍𝓎𝓏\u2009𝒜ℬ𝒞𝒟ℰℱ𝒢ℋℐ𝒥𝒦ℒℳ𝒩𝒪𝒫𝒬ℛ𝒮𝒯𝒰𝒱𝒲𝒳𝒴𝒵\u2009◌◌◌◌◌◌◌◌◌◌\n    𝓪𝓫𝓬𝓭𝓮𝓯𝓰𝓱𝓲𝓳𝓴𝓵𝓶𝓷𝓸𝓹𝓺𝓻𝓼𝓽𝓾𝓿𝔀𝔁𝔂𝔃\u2009𝓐𝓑𝓒𝓓𝓔𝓕𝓖𝓗𝓘𝓙𝓚𝓛𝓜𝓝𝓞𝓟𝓠𝓡𝓢𝓣𝓤𝓥𝓦𝓧𝓨𝓩\u2009◌◌◌◌◌◌◌◌◌◌\n    𝒂𝒃𝒄𝒅𝒆𝒇𝒈𝒉𝒊𝒋𝒌𝒍𝒎𝒏𝒐𝒑𝒒𝒓𝒔𝒕𝒖𝒗𝒘𝒙𝒚𝒛\u2009𝑨𝑩𝑪𝑫𝑬𝑭𝑮𝑯𝑰𝑱𝑲𝑳𝑴𝑵𝑶𝑷𝑸𝑹𝑺𝑻𝑼𝑽𝑾𝑿𝒀𝒁\u2009◌◌◌◌◌◌◌◌◌◌\n    𝔞𝔟𝔠𝔡𝔢𝔣𝔤𝔥𝔦𝔧𝔨𝔩𝔪𝔫𝔬𝔭𝔮𝔯𝔰𝔱𝔲𝔳𝔴𝔵𝔶𝔷\u2009𝔄𝔅ℭ𝔇𝔈𝔉𝔊ℌℑ𝔍𝔎𝔏𝔐𝔑𝔒𝔓𝔔ℜ𝔖𝔗𝔘𝔙𝔚𝔛𝔜ℨ\u2009◌◌◌◌◌◌◌◌◌◌\n    𝖆𝖇𝖈𝖉𝖊𝖋𝖌𝖍𝖎𝖏𝖐𝖑𝖒𝖓𝖔𝖕𝖖𝖗𝖘𝖙𝖚𝖛𝖜𝖝𝖞𝖟\u2009𝕬𝕭𝕮𝕯𝕰𝕱𝕲𝕳𝕴𝕵𝕶𝕷𝕸𝕹𝕺𝕻𝕼𝕽𝕾𝕿𝖀𝖁𝖂𝖃𝖄𝖅\u2009◌◌◌◌◌◌◌◌◌◌\n    𝙖𝙗𝙘𝙙𝙚𝙛𝙜𝙝𝙞𝙟𝙠𝙡𝙢𝙣𝙤𝙥𝙦𝙧𝙨𝙩𝙪𝙫𝙬𝙭𝙮𝙯\u2009𝘼𝘽𝘾𝘿𝙀𝙁𝙂𝙃𝙄𝙅𝙆𝙇𝙈𝙉𝙊𝙋𝙌𝙍𝙎𝙏𝙐𝙑𝙒𝙓𝙔𝙕\u2009◌◌◌◌◌◌◌◌◌◌\n'), '\n'), Âåæ(ÂÛê, Âüá)))
(LOWERCASE := Âøî(Áÿú(ALPHABETS, MOD(ÁÛÛ, áØÁ=0))))
(UPPERCASE := Âøî(Áÿú(ALPHABETS, MOD(ÁÛÛ, áØÁ=1))))
(LETTERS := (LOWERCASE + UPPERCASE))
(TERLETS := (UPPERCASE + LOWERCASE))
(ÄÊPSH(ALPHABETS[0][slice(None, 3)]), ((abc := ÄÊPKE(0)[0]), (ABC := ÄÊPKE(0)[1]), (num := ÄÊPKE(0)[2])), ÄÊDEL(1))[1]
(ÄÊPSH((abc + ABC, abc + num, ABC + num, abc + ABC + num)), ((abcABC := ÄÊPKE(0)[0]), (abc123 := ÄÊPKE(0)[1]), (ABC123 := ÄÊPKE(0)[2]), (abcABC123 := ÄÊPKE(0)[3])), ÄÊDEL(1))[1]
(TO_LOWERCASE := CUR(lambda ÂîÓ, ÂîÒ: under_script(ÂîÒ, ÂîÓ), (lambda ÂîÓ: lambda x: getattr(x, 'translate')(ÂîÓ))(getattr(ÁÜÙ, 'maketrans')(UPPERCASE, LOWERCASE))))
(TO_UPPERCASE := CUR(lambda ÂîÓ, ÂîÒ: under_script(ÂîÒ, ÂîÓ), (lambda ÂîÓ: lambda x: getattr(x, 'translate')(ÂîÓ))(getattr(ÁÜÙ, 'maketrans')(LOWERCASE, UPPERCASE))))
(REVERSE_CASE := CUR(lambda ÂîÓ, ÂîÒ: under_script(ÂîÒ, ÂîÓ), (lambda ÂîÓ: lambda x: getattr(x, 'translate')(ÂîÓ))(getattr(ÁÜÙ, 'maketrans')(LETTERS, TERLETS))))
(GET_CASE := (lambda x: (TO_UPPERCASE(x) == x) - (x == TO_LOWERCASE(x))))

def under_script(áØÆ, Æå, áÕÉ=ÂÞÅ):
    (áÓÕ := (lambda ÂîÓ: supscript if ÂîÓ in SUPSCRIPT else subscript if ÂîÓ in SUBSCRIPT else None))
    return Âøî(ËãÂ(ÄÕåØ(ÁØò(lambda ÂîÓ: MOD(ÆÑ, áØÁ=ÄÕÍÔ)(Áÿú(ÂÕÅ(ÂÛÜ(nrmscript, Âåæ(Âó, áÓÕ)), ÂîÓ), áÓÕ), Âåæ))(áØÆ if áÕÉ is ÂÞÅ else áÕÉ), Æå(ÂÕÅ(ÂØÏ(nrmscript), áØÆ))), ÂÕÅ))
__dir__=(__file__:=áÌî(moon_dir/'/home/ganer/Projects/Moon_BETA/Header/highlighter.☾')).parent
(styf := ð(moon_dir, 'STAGES/style.json'))
(styd := ÂÞÅCAT(ÂÞÅCAT(ÂÞÅCAT(styf, ÐØó), áÐÞ[ÿ]), ÂÑÖ()))

@cache
def sty(s, bg=0, def_='bec'):
    for k, v in styd:
        if s not in k or 'color' not in v:
            continue
        return termclr(s, v['color'], bg)
    return termclr(s, def_, bg)
(__highlighter__ := (lambda l, b=False, clr='bec': Âøî(Áÿú(ÂÞÅCAT(ÂÞÅCAT(l, ÁÜÙ), VEP), ÄÊCUR((1,), {}, sty, ÂýÃ, b, clr)))))

def highlight_tester():
    while (l := ÐÌü(getattr(stdin, 'readline'))):
        Âçß(ÂÞÅCAT(getattr(l, 'rstrip')('\n'), __highlighter__))
__dir__=(__file__:=áÌî(moon_dir/'/home/ganer/Projects/Moon_BETA/Header/meta.☾')).parent
(IMPSIMPS := (('ℍ', 'ℍ\U000f7e19\U000f7e18\U000f7e1b\U000f7e1a\U000f7e17\U000f7e16\U000f7e1c\U000f7e3d\U000f7e15ĵ\U000f7e88\U000f7c7d\U000f7c7e'), ('⫚', '⫚'), ('¶', '¶✿')))
(ÄÊPSH((lambda ÂîÓ: ÂÞÅCAT(ÂÞÅCAT(ÂÞÅCAT(ÂÞÅCAT(ÂîÓ, áÍÇ), zibe), b85e), áÍÇ), lambda ÂîÓ: ÂÞÅCAT(ÂÞÅCAT(ÂÞÅCAT(ÂÞÅCAT(ÂîÓ, áÍÇ), b85d), zibd), áÍÇ))), ((stre := ÄÊPKE(0)[0]), (strd := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
(__ÄÊIMPORTS__ := ÐÌü(ÂÑÖ()))
(TP_CACHE := {})
(TRANSPILE_REF := ÐÌü(Holder))
(EXEC_NATIVE := exec)
(dump_cached_imports := (lambda: 'TP_CACHE.update({%s})' % ((lambda ÂîÓ: Âøî(ÂîÓ, ','))(ÁØò(lambda ÂîÓ: '%s:strd(%s)' % (ÂÞÅCAT(ÂÞÅCAT(ÂÞÅCAT(moon_dir, getattr(ÂîÓ[0], 'relative_to')), ÁÜÙ), repr), ÂÞÅCAT(ÂÞÅCAT(getattr(ÂîÓ[1], 'native_code'), stre), repr)))(ÄÔÔç(__ÄÊIMPORTS__, lambda ÂîÓ: getattr(ÂîÓ[0], 'is_relative_to')(moon_dir)))),)))

@cache
def moon_to_py_cached(áÖï):
    ÂùÆ(TRANSPILE_REF, 'Cannot transpile without transpiler!')
    return ÂÞÅCAT(áÖï, +TRANSPILE_REF)

def ÄÕôñ(áÖï, ns=None, get_code=False, include_builtins=True, native=False, Æå=EXEC_NATIVE, ret=False):
    if not native:
        (áÖï := moon_to_py_cached(áÖï))
    if get_code:
        return áÖï
    (ns := (ÐÌü(getattr(BOOTSTRAP_GLOBALS, 'copy')) | ({} if ns is None else ns)))
    try:
        (r := Æå(áÖï, ns))
        if ret:
            return r
    except áÍÚ as Ïã:
        Âçß('Failed to exec!')
        raise Ïã
    return ns

class Module(ÁØö(ÐÌü(ÂÑÖ()))):

    def __init__(áÑÞ, name, ns, code=None, native_code=None, hardcoded=False):
        getattr(super(), '__init__')(ns)
        (ÄÊPSH(áÑÞ), ÄÊPSH('name'), ÄÊPSH(áÑÞ), ÄÊPSH('code'), ÄÊPSH(áÑÞ), ÄÊPSH('native_code'), ÄÊPSH(áÑÞ), ÄÊPSH('hardcoded'), ÄÊPSH((name, code, native_code, hardcoded)), (setattr(ÄÊPKE(8), ÄÊPKE(7), ÄÊPKE(0)[0]), setattr(ÄÊPKE(6), ÄÊPKE(5), ÄÊPKE(0)[1]), setattr(ÄÊPKE(4), ÄÊPKE(3), ÄÊPKE(0)[2]), setattr(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)[3])), ÄÊDEL(9))[9]

    def __repr__(áÑÞ):
        return 'Module[%s,%s]' % (getattr(áÑÞ, 'name'), '✗✓'[getattr(áÑÞ, 'hardcoded')])

def IMPORT_find_file(p, g_dir=None, w_dir=None, flags=ÁØã):
    (ÄÊPSH((getattr((ÄÊPSH(p), ÄÊPSH(ÂÞÅCAT(ÄÊPKE(0), áÌî)), (p := ÄÊPKE(0)), ÄÊDEL(2))[2], 'name'), None, None, ÂÚü())), ((name := ÄÊPKE(0)[0]), (F := ÄÊPKE(0)[1]), (native := ÄÊPKE(0)[2]), (failed := ÄÊPKE(0)[3])), ÄÊDEL(1))[1]
    (dirs := ÄÔÔè((getattr(p, 'parent') if ÐÌü(getattr(p, 'is_absolute')) else None, g_dir, ÐÌü(pwd) if w_dir is None else w_dir, ð(moon_dir, 'Libraries')), None))
    (sufs := (p, '%s.☾' % (p,), ð(p, 'main.☾'), ð(p, getattr(p, 'name'))))
    for F in ËãÂ(ÂøÚ(dirs, sufs), ð):
        (ÄÊPSH(F), ÄÊPSH(ÐÌü(getattr(ÄÊPKE(0), 'resolve'))), (F := ÄÊPKE(0)), ÄÊDEL(2))[2]
        if ('↺' not in flags and ÂÞÅCAT(moon_dir, getattr(F, 'is_relative_to'))) and (h := ÂÞÅCAT(ÂÞÅCAT(moon_dir, getattr(F, 'relative_to')), ÁÜÙ)) in TP_CACHE:
            (native := h)
            break
        if ÐÌü(getattr(F, 'is_file')):
            break
        getattr(failed, 'append')(F)
        (F := None)
    return (name, F, native, failed)

def __ÄÊIMPORT__(p, áÒÿ, flags=ÁØã):
    print("__ÄÊIMPORT__", p, flags)
    if flags:
        Âçß('FOUND FLAGS: %s' % (flags,))
    (ÄÊPSH(MOD(Áëý, áØÁ=ÄÊCUR((1,), {}, ÄÝøÇ, ÂýÃ, áÍé))(p, ÄÊCUR((1,), {}, IMPORT_find_file, ÂýÃ, getattr(áÒÿ, 'get')('__dir__'), ÐÌü(pwd), flags))), ((name := ÄÊPKE(0)[0]), (F := ÄÊPKE(0)[1]), (native := ÄÊPKE(0)[2]), (failed := ÄÊPKE(0)[3])), ÄÊDEL(1))[1]
    ÂùÆ(F is not None, 'Unable to find module "%s"! Paths checked:%s' % (name, ÂîÊ(failed, '\n')))
    if '↺' in flags or F not in __ÄÊIMPORTS__:
        (ÄÊPSH(__ÄÊIMPORTS__), ÄÊPSH(F), ÄÊPSH(None), setitem(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3]
        try:
            (ÄÊPSH(({'__name__': name, '__file__': F, '__dir__': getattr(F, 'parent'), '__EXPORTS__': {}, '__þIMPORTS__': __ÄÊIMPORTS__, 'TP_CACHE': TP_CACHE, 'TRANSPILE_REF': TRANSPILE_REF}, {})), ((ns := ÄÊPKE(0)[0]), (áÑÕ := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
            if native is None:
                (ÄÊPSH(áÑÕ), ÄÊPSH('native_code'), ÄÊPSH(ÄÕôñ((ÄÊPSH(áÑÕ), ÄÊPSH('code'), ÄÊPSH(ÂÞÅCAT(F, ÐØó)), setitem(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3], get_code=True)), setitem(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3]
            else:
                (ÄÊPSH(áÑÕ), ÄÊPSH('native_code'), ÄÊPSH(TP_CACHE[native]), setitem(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3]
            (ns := ÄÕôñ(áÑÕ['native_code'], ns=ns, native=True))
            (ÄÊPSH(__ÄÊIMPORTS__), ÄÊPSH(F), ÄÊPSH(Module(name, ns, hardcoded=native is not None, **áÑÕ)), setitem(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3]
        except áÍÚ as Ïã:
            getattr(__ÄÊIMPORTS__, 'pop')(F, None)
            raise Ïã
    (mod := __ÄÊIMPORTS__[F])
    ÂÞÅCAT(mod['__EXPORTS__'], getattr(áÒÿ, 'update'))
    return mod

def __ÄÊADD_EXPORTS__(áÒÿ, *áÑË):
    (E := getattr(áÒÿ, 'setdefault')('__EXPORTS__', {}))
    getattr(E, 'update')({**dict(áÑË)})
    return E

def __ÄÊADDGLOBALS_CLEAN__(M, áÒÿ):
    getattr(áÒÿ, 'update')(MOD(ËãÂ, áØÁ=ë)(ÂÞÅCAT(M, áÍÙ), lambda x, y: ÄÔýò if getattr(x, 'startswith')('_') else (x, y)))
(__ÄÊGET_GLOB_MODNAME__ := (lambda *áÑË: áÑË))
(__ÄÊSET_GLOB_MODNAME__ := (lambda *áÑË: áÑË))

def show_imports():
    __ÄÊIMPORT__('text_format', globals(), '')
    (show_table := (lambda x, y: Âøî(Áÿú(ÂÛÅ(ÁØò(lambda ÂîÓ: ÂåÔ((m := ÂóÍ(Áÿú(ÂîÓ, áüíþËðâ))), Áÿú(ÂîÓ, ÄÊCUR((1,), {}, padc, ÂýÃ, m))))(ÂÛÅ(MOD(Áÿú, áØÁ=2)([x] + y, ÁÜÙ)))), ÄÊCUR((1,), {}, Âøî, ÂýÃ, '│')), '\n')))
    Âçß(show_table(ÂÛê('Static\u2009Name\u2009Path'), ËãÂ(__ÄÊIMPORTS__, lambda x, y: ('✗✓'[getattr(y, 'hardcoded')], getattr(y, 'name'), x))))
(BOOTSTRAP_GLOBALS := getattr(globals(), 'copy')())
TP_CACHE.update({'Libraries/Compiler/main.☾':strd('c$~di-H+7P6@Q<<;^qPQni!T{)Rz&HYCi^oSlH3-5Jg&6mdCy`<1%B9Y|m!5hzF9;N{}i65<((Kv_Z6u)DqH0QQDH^;lAgO;4kQ(&~xsGeeLlqkhC4ajO}~w`MT%hcf9>19+PxGCE<7yCmBhzAdHBY68<*-fIs0s@B{e$qR~gXEF3dUD6Wz2fWOc0%Jp>Gn<TN%(wto<p0KFly8K;!<Lvp)#%9-bsg<$4%<ad?*vl-33`TL!8>Q5Ch-KLginN`r*Xhiz*!9xc4e%`~m)F+LtZ%F=uWz}l>+R(Wut%^u*G9^G6I_eO8y&dbKDM|sUm}QeLF#1x|0y&}82ewyJG<7t&?U_lv3~jox_M=JtBtpC(4X<^tIJ(#Eezu^TNro|OBOmw{2S(H>B9Lqj@*@YcNvs|!+wuHwqbYod<Qp=F9)zK8&4LFq!u|sq!h<S5+J_CpC}Qx_+4t#bQr(oP7(%=ZJh>1nM1^*>iuNjd=&Hs?!-${mb6YF<010`mbgAd95TPg@9`fYP_OY%`0we+8}|YaMLy<t9Qk{@Ng#;d<4@^;WnPvgls}=G!a9;3e|GN&p}nMb(0x|I(s;DX!1p$iqr2eg>q53A{riA_%Ri&Q`X2xL49!As8ji9sN|6JqJ@K;PDD1f^H9&Q0iL_A*dCtHsX4aAPQZz>A2Vp{5a7&M*wotRveuG;7e(=GUs7L9hILzWoY6b4O&p!c@giR8ukO*y|hj!WlzstXJ$Wd{0H{n8Febgk1qGlye5}GecKCPUcq7_1gMRO&K-v_NLR~=bc{tTB*;%^UkNZ2QIh<nnZN6Yk@*tQ82FX|(eKIuXpoQx=DU&DbA29ZVb9Q1X*!1d6$mUc;DHkAd4mdpa_HeOzVco8vbHAy#_GPMj!UBzfhSr%q&oagG276R9c#`OuExohopdJ<Ci<c@8W#KIUu$=s^q(Uq%Gri}HMm)U3ptWOGQZoqoeL2h}Tv(i#=8&9jZZWOx-i@Y%_=k{#+hmpR`L#5du@PRW|1o9p~5ZHg>pVO6%H!1jZ#He-lf~6SwalrI(VYDGV+W!&1&7WdaRE`iUi`Y0wys?Xww`J&PMs7(RSTpoF;D6v>i$)2*xipBj<*lxzbvS^h?<ft7kgArYVzWO<MA=tiC45^^qvYem9JFz<TlElVlY7YE_cB~w){<ORcNZ*D25B7<mQ9n0NX;5FV1Ar<855G`7K-ni#B#Abx^4^lXg?e=*KM|-QtG-1ZOOKeg9llZU5ZqXDpgD@heolKeDiW?>tcp_ill(9GeJ2<sA+9l7vhK&kt-jPFck%%@NAyVRk6rO^b$j=L#SF5y)IAL?Grn=reu_t7I(~yUbOK^H4KZ~&huqf?<md)+Ek;v3ZbIp7`Eh^$ko-0o0Kj(aEE2Rbh4sheb3)<N{m7J^BF57GRFso{Yzl~5_m+BD*F#1t&2x}>KJ0F8IPx%Xu@~=F($w_{5n1DkP-wD>yIFl4B@31GLP5n-V(mZc(4_axudQyGp$w0B>-fA|DOHz3!(!2{KlG0z%NB89{`VQtsu^laBR~WAsQMi{R+Mg-K-WrgvEFBMO^}{OA!<Z$gGe5g_(8oXLG~Is^MmfL&WEKHVznIRg9)y9A{~kcoQfc&|OSWi|908J}$t#j-F<t6x5w{_w>f*IclB{0&iJZ93o2=rleb+jlbiMUN{#g`@Y10i1Uj7;sDD~(S&sc_H{@pC~Ze$++aGMxW4BPS)dpgi>RVm_|aQN(Z_K6i*TVsK*3UNhI{Gs=_EjxOWrJ@%8iu{(CxUZ%d4*=AofSh!yX_FPZ;b>RlI)+JJbRUgygbAb`isEA2r9KE!W*ClmxA@Fy(@FLBh~W0z9q2vI(#;m$2i&(-sUqDq}#Ef*XGPI0B$PWu}OVHMDPnO604<Li9E(OvSBbS6J&E(r6&`CNL3$nzU~>szeo=fqD{8fb_B?<v005{<bbOn&X^mgD6=d;lrv5R%8Jd3nJe!nuA$yx``L1y5bb$(j7<UrP5>1A^XiDr4EPTMU~$(uJ?Z-U>44*j@9|u&%AIz>h9+9g{{un^|rg&K5fEm0}1=1P=~sH2a<R`>v{fVgb`ja3L_apG!o%mOylJ;6Qw44S5zi^m#%CQLHG+ip$biZPlUmBXj6z%pF)OP&+b1USYG=lJorgQCcb=Y2#%ToEj3*VI6IK7lWAt#)%29~<z&#2bS4fEUJT+mc*QDqvXMp~Ux{>;WurcyV$7v<KLyV~g6Ilkuu56IY^bt(i@oi|Wp!~*7F@Js7LK{@FdRT79t@$*xvp)Pshv{S(o2Y{qCnk*F4;KbjdsVb5n5uCCHrN=Oy1aNzri6yF^tky1dfWlEZk*kJi`vqV!Pf5gElkIJ$K%o&nDTdlv>e3{EN%oW4<AGhMN>EXR1%d>&5r^!#P58e+u+fI1_d_d7Kz2YRNZ_u9OkRkt{&?`sks?6Pd1YiAZ-G|8Dc|G)@q+PZ0Yi0&M1ybusk@tVtL-1xN$S2a7NoUb_@2je~pzL9n^fBc}kN2!P^Z^DS0Zsw;%b_M7UEOYEFDCZ|MC3ZvK56^wMhPO|`hV57ti<k|g?i!B>3xaCf<B_XF!d$c2&!nX3KR?6lJZn<My1~!3icZ2_vmd-%X8?yqgARrsp0kWftqOz8bLZ87zB4!);ZO?;gQl7$fwE9K_wX{475zAP<QZieoSrRQKsVYSYgYR#2wuP%wMV@{BZKc_Y_kDU8z*m#f2jwDa1^+E+P?DZ6tyd?l2AY>D9`J!vGTtedd9Ku2AVFCLfY#U9QoGw^qZnc=ApIo%EsInGPhXKOuy0i=;Lp~5t^#Ki$AIK4>x4_&<2kk??1Mu*$dke$+b0|Xk-W5HAh4#1=1P4jf4nEvFQ!X9r!VO_U5)|{*@H~bW4euzj1Oe2OG9V0-<YF4P8P~{$B<`fd@%+ao4hK6^9CCGV{WX<TbZ=S7Hz54BmPH`pQbf(M69Tl)T&jSD)7jgiE^$*M2o<tRpqvMIJe5X{#S)c@N<~WisTSQX5XgBeyU%h0FtljxmKrV9l)zbZyijL*(U+t^U;b_V0cI#=l%3K!0i$Lkm@pZHUj7p22f}rpi{f43)Wct)n<mV<Xq;eh%~6T8~LBs-1eJl_M*m+K&_&xTczo!ye4}>i9$XSbfu%WW~X<U1ZJuZ4l6Sc1#KCq0A2Y(p_yFGZN=x6@(Ih;f@(MB4@7XNt}9;Sx&o!U?$`?>n1iK*YY@~eezV+jq1*lkqi!fI'),'Libraries/text_format.☾':strd('c$~!=Yi|@s^1FY<C=!|;XMCAm;{eWWashHey5t-I(M8%_t@bgt_t=MTcYIz4kid9t5?(eo4o-mJ@W=z=I{`tE;2_aIAip8=3+^XeRrO;YJ8N*hgk<UN>h5}VRdrPl)%sMk<ryt^fbk9fjQ>zBmM2|fG-I$@v0kba4Zgtd*v25tF7tEH5xpy;2A|`1_$p)k9RDxhz%8_w;RegH4Y@yIr`l2-M<h@9GUKQDRsKMeoa38(1t{F&pYflV7+SO(*FBaH+W>?s{IO-YwYF=dEG9@<mhopJ<)n8DIPt@J*s$Oa2tCg~`|!vi7M7kB3X|1|$r}7Tw^b-uL`cs9tX{6QER>P4Lnt_5`P+NUv9eAc!MqD%{X)C$#}=gWxDf#d-+P~>EQAcO@oJ+|aNFfV+x=G?cTBim(eqlY<=Tc>Zq}!&HP^HlJA#vDu9GU|a#{AyXf9WI{jKy{)abuXI9B~cHrH`d@Jr`S5|v0a+>Tc$PZnF-&@dU`h5vW8trL=vQ?~~H^p0g3y9{>3CUmVj@=L;nl!I~|_~<ZW!!}5H{G=Tv(w;7v0FOv(i&MR2<GF9~Glad;^jg(=9J{oSj&00lMx0TjlWo_kWtaWE*#PXb#t;}m-gw<G{Zn^MvKQJ6CxHg{HDevZc$#11>#PHWjJIJISxE<})~XG+9Wj1siAo3<-{9Q??;Z_IkdRp@+f=RUq55(Sp>Pi%VPwemC~kO;M!mro`BN6r4yvVCs{xMaS=qoH?6qv+E}Oz~Bces<XwMO6gp!7wr=yt;Nv^R`8^adY2K!*_AS&P?zd){Wm7mTy7E_W1&KY8mj6UMemL>H467~>)=ZiuQRNQfcj=TWa*Z5Onc#Z#uiH3--@hxj~z<@sjdP7<fa4F42ECN?m>$7RJ8n7LU_8~KpRYG7HnT(MVIOBNd`1ky#1OUb;g;YRcI1ktbdK4=WS#}#Vq=LK%#JEN*NZH0v%2HHrWQS7uh)aZsOW9hkH{EJTLz1+?^w4Gp2L2LqHq!M}vBF4o3-X{BWqUSb8m7emECW0!jYs3D_B?^aid%(%FUnY2OOB<q<W-`mJiD6lwmk5~K+Q^S;zRO!iJvA*mlTGKniUuTNrneMl<I>8OomVlN|p3(b$WNA?Vo2^+PKR|>&=Lau;O9j<Qs2<W)s*-;3~|F#z(7w>{GtL{#pdngVWyC_RoHr`^a&e@jc~XSN7cDQi>wHAYxm6ETXMVVkX1y*~TRNEzdu6MJuZjz8tl8R30c^xW6<FE#iz(Z5#YvXvYjL-ah68HX4aJ8tG&Y(n+!??dA~{Xmz9Mk=F%#^erH%nGm4eMg`(^7Q6ve51ckzh68udAQBjg<B!VNOF+9%;4TV~oFGw)7oH+N)Z<_}*aqHXX}4O4x>d-f(%@3*d?aKDbLusTwpT14YcUa-z7H$`<rA=8Q>7b!ATBd*$3T$8n}`O3V%fdeoQ{Sf?1^C6KSG3~`#r0Vrv~2ByW{Ny_mgT+#u3rVJ$dw@V5W^9W>Ge68!T!x$emJA$})<LiWrW4$Rcy$T^LYlB@5(7%RJhecBvDCQ(Un6r~sH#!DJEoNw>&3AU-Fuf_Z)g%7UxfN5x57ED|>`YQ*?e_X~FJTm5gOQnORgc*Z9(rZeJ<>>G!>s8pTEgarv%QHXftAi662_g+<aBr@P45=up!(B>6>McE+byD63LhEso)(juo;LT;hXHzf`W9R{RGJP4r2%&ckYxUP?dW+2CpdJ`Q61xI}pX$zylm;8HX`WH9+i(mT}Z{?=bj<e6dc-y~t$G>>jv}93rMcl|^i8u0r9bCpBPtqlbW|IxFY13alZ=yJ1$SG5@-nA&FUtKaacbEtzhQu+TEf9&wcmTNz#nUi>)t8gJ8j#E@qwMPdz|ltdGSZmSwjq@iDg|ug6J(b)$Ouyqx}iLQYk`6nP-ma$kwsO_EQ!;|Ywuv&-wpw-gc@A<kzl_g5yrCc4SoTN^b?}<ovIcRunFH&Hw|Ka&KL0pAsYfpiB`0K?BiD|jlp?)$|%jms6GNx0XW`izRu^Ps<1_Sc~s=H5g5q{h|rycyTd?;8q08lawU{!P|IeeOuF;~I^{o{XJ@A@xBhUJccx`rInydm^?4>xept!ub!=lQvl~(*AQqD)?lm%S-s4-r9hR6<K@w20w3tD)4A;Toeu@baHjn`tB>|gKF$*+R0cJ74;rjtPV#Nw-Wp#<gw9uID_g12mP|rYi)XvcTe1Wg_7WJ`ECLi~N=ZU;qrx^46I)BXXv)KC_zP<osbqkA-GyJI~;_V8*q_a>PwX=<KWW1D_1X0naP*chVENx3By-I6=Mq-N6cCup?1%~scG8}zeQs+9<*O4W8a!9c~*_<hqn-w?aQI$-}arDzEL_p0O9dxE583^YT=J*7VHut4Q%s%M_1=@~ybE<l^I8hz1%Ne@j`ks9j!xj^2?Fa?i`jpD@&RvJl9^Nk8z09<q>uW$f#^&|GY+J!)2j#ixhY4a?Yz67^Dr2<7nU2@V?T-%*R;p!B=beyL1doYeO+f|*D^{WRz@{wNHe@X<-$~B!1xiY>y)RnYy3Bv1QCE(h$o83RAISE(Y#++@k!&B!_9-!N9fbc$_8#$5gn3b}_(`w$nIM;GUaY(%*Zi#4JkxXM<lL5?+micF>os$F?zx<s({pEZZ%Oy&b#Ga&-_(%H^ggjk@Fjki+AGAx8Itl6=>*q4;Wu?}L-)Rxy-f|<48d;e-W}b$t9#$*-nY7UOJ*ux$o95u*JZn=G8x%^C);n;+k_n7knNYU-9*FvZRxJRbjrVfTRf3CrM-LoYb*Y>&;7Lx|ItJL(W4hzes|@?GrxPq@2>mZCBOTn-(B{*m;LUl-(8bWE0t1O_x8N_#qWNuhr@pNni`bf^t)H}%x(=%``s@zc*O5s*Moh!2U~CGK~ZnrqhTct+v_iUst5aiJ>}0Y`e$$O&0pu$OVHkm?&;T|z2oY|=*@k)SJb_-?p1Wp)jhp;kE3Cw|6O0c48LpeTZZ2y_^rcl1AaGuTU~-?4Sp-|gTll*8A^D;`$LZ-6j<oq3a;$?;RlaM-aTp@f>eTXQyE0IdjNS!jvWriIu|g<$A>ZCnRYgR{G|WYV^d_p2gW`~&V=9ZO@tAAI0jCO>MOo_Sb*cJcN6&C!~clEM-sE_;Ne!j-!1X;{28Orvc~W|;e?SebyZD;T`p8KsOOyXe5>E%?uDM0p2RwUs(&iQ)=A+j{HAQbfn-tCm|kl(C^jL@gnFuBz##{~Q0)frY)90oZl~-{dBG~Y6ht|FRDLj`nkXpYk78-&%}%*Jwe2DONe8Q{LZMNtyM=-o+bSYYZ($s<CiR&L%BzWtnRe1<3<-s;q_;KPCuVz?7BQ~hCV55Qrkh51(uftt5h)MP>n|-KOu~R}g%?|z@VfjYn|zFco-w@xJAXZvm4;PY_1t>fv{>A^&0TH$Pd#KOn~QCLU)cTl5YYj$A7bNhqU>;i>`?Y^f3NH!LF)8l_Z3)O*dePMJ79JH?_za-GOH{6VK1wuJk7qYWk=s+l-~^CKSg*FPKJ~I6+@&f6?r){-|(;cS<f-GSX4jkn0iFSiniG@WCof?_0ZcM>GGHr`lkn~8kTP=@{QCQC=@X0y?gLr;k}PP96NmUNTI+cYRwX)s%YoT6d!aUD;FJtQQiz7Y6*fbCIG-jjmu(OR^yf!x74^T#$vyCx;E7tHo;2G4!*HAJ2ZmI1xE0<<^W0<$piE>bS41LD7g5v4^Yt&6ji;1L{*<=sGtETwPJ0;_g~zW0H*cP>fH=ID~OLov?dgI&1jLOa3q+5xs9E}9xy&!0gd`}?YV8Q;NfTe@n)-D^q4euWpKiasP2zk1*SVOVPan4IN}93GCAYIADo5+6(4X%(9QhSId$ns?7Dajjj`~24Uik{Vy##)U|4cnhBxEZ{_PsTqt}2in`?NJE(F=OXLys<#)L83oHi@QOtIk^%?6HIMrpb=@ft?WRN6L%MZK(E%Zu_uIT8f}V&*@a{ttKjvuE968;}><&1$9Cu8<V!8yPEwHesFoN}I}YN+Yo6x1}FnJP6iQ;)r|K$XWRXrwH0C<{G73qnvA0at%~<3F={bm<g{(e^W=5O3@jdGGDU9=v`3W*@8qOu%tGPF(Bn^w*(wM*XX?ZGB^ZKeX(e6vwC~pTRU4Ii2NT{EBTZ'),'Libraries/Compiler/to_ast.☾':strd('c$~c&+iu*(^<7`VJdu>v!LCxEsDVW)TdHeRzQB@!0J1<(TuLImOR^-_UZE&pS+e3<h@*=wD{0(XHr&RRqb5a>+HI0P4A9qpL-q^&2{~tGI2_*gBHLXEnpw`wxnGB?k#%zC;>@o#!@$|ua~CgMnl%hf4eaZI6WKwiR+Octw_r9yO|K}bs>6S_d17+%%=Cp*6Vo%s>FKG7^Kgtp`^^;Y6o+6=A78i#^SKkX`H?KHrNC^x-!LOHhigQ`HRWVo!O;kO?c9Y)#Bz^3BkKV8fb5gi`k6};=X8zSB!48&HTCtw2U}O#<JIafUO(LXRz>_`Wq<v{c<I6O4=FPM<38D`D8B-<w$4!+me)$*#gPKqCVQH$ovXw2IeDb1xDj!jO+B&QsC)a%|E+~q;P^PDsAhw9f&rHNfiU34G=`pVTc+a<1Q$1^;mW{98up?Rd4?HA8i;6*{EhrT$M5*~H6OpJDA&!vHNs^ti0XK{qC|nyGMcu#6fGN$yXf)9i(X*a#$vnK1S%tIxlUzXQ5p+NhHnO;9n`Dr8vwg*P!6KNw&Q)Hqk!>K@}+)qM1fBqx=;w(*peNYQ4}Ov?aNJIx4dgMAU4BgJ7l=g92X<hgU~M+Ytw8kG)$E35!pS7<5O}^(_)`u&*!T1u?xU6HBzN-u;V2;(#R^9@!z!!IBM#v<dA$X3?0v%zI;j3Y88O;yWdm2?vX7zeoxkb$}6B#oujTO++FUIPslw1MO9#nuEmlOWWwnPR{(SvuW^SSkBNqPO`2C@_nw@Z);<9L{$Res89+c>O`Kb1_U(nR?e|rJa1lhH@$IP51Tzz?1_rT_S*Xp+WYu(hB1i#eC*KJNK_}qQE6U{5smo{Ti8Yqk0%I!*R+t&$$5|{e+hiF(faDYM4doC<K?w-`tm{OM*;FV}RhNM#o|OhhpF4|eNx(`S%{rT6x(&q%vq#c!13PL5u5#XUZSfohETIt3F+h+F@>F64wyxHz8JIweaKgl_V&-l12X$7>97-Eb;W62(eA%neBvvcQar`PfoiG&T1oNLmjT|NZP)ek)Qs1EP(iSIK+c;R;`1~9CP)ZbbQ<9)W6!@wFp*~J-GpAT)o4Lrxsdpe#D$2LYTWG%n#d8JG=(j<(llY0`%l3K`W-oBhQ~iwtUy&mr!o-neXGwgufXM(#iflSahwH)gpCFMUs5T~OcxyzcS1wnp)x~OU;b&N6VRa=1vcQI5)G~Z8gh1!Hp{xN)Rw{61i-)v*H0-8QVi$8Nji7i|g)~&Q$#MO5#5N^(%|^pmXnNMwus}n+7zPG{sAxSKIffl23gaT<^~0@yN)-m*aI%OgFj+WZ)r+eL5b!Sff~K8a@>f3Y^YM{ZRAk(Q^7>_2d4LF`AgM9vLO&~EBt~_9G%gV^QOoHeWmWaMLZx6_y=J&(OQo@*A3LMG_81ImAfU2SiE86ISkefPZbVSMs1;!k_{eb^Pz>g`cketl8n#thCFX1(rqWVrmn2K=zdHyDixRUHszQ7PL|$KZ!mF%n^O@I~kr6-4ZBP25?M)EMw{dH<z1iK^hQG}BUHSWNW_?#$e|Q6)-9<uk_A3g~XK9PuC!gsWRpKEiF;+uGk*4LuuL(jvmZ^d-yT>5n7TKXtKL#NVOA2y+@1-n<`!@?oDD~s0UYzRDCS=SMamKXr#*~;mutO_A@`T(W|I%VVfyJ6m7fSq{9*364H@dfP6h)+d8of*YLBrX9`iL_ZZ4pziXzaFI3t-hnrRgt=B5RSvN(JWmOk86kQb}p<=XTW;vjs7;#H`W%>QVQr$K8#s?#52{#jWn24!TeO00O|mI?FHC(MDN8o)oc(xOhACs<<7(rGtD!#FqBSjm*+`S+68l4tL4t^q3rUAMx=?Q5v&6e}yI`v4&e8izAFmorODHszZ1UFvi&!M&@c!A&D%n3)-J)`O=bd$ILxbTT&YSt)?FRpekbuZ`%iH7~sF5zF}dR5l>OY!MI@Jg#V`R+in9CQ0AOR<b}?K!)veuT^~g7JYn|1@3_!CV>GK)O5?*3In0w#YzMFMnjM0GI0l7nU*(uyfxgjS3h{xD42@3+JckUR6(Wlp1PZ5D87}G%3NaUcOMEipZ#|WuzOPE*SPIRYa1>0=$kPd;lTI$lp27^10-w%OPvknUgsr&TJ4_x+X(d}j<nl|AjGJaOL~@8)zS<ie*O`YZgZj{G*oNm1LI^+D!K?7VYx_oI2Cy$IOOjCH6*VM*58X`9UIuE{qGgmsWV^6zMtIBFtKBJ~J7=P-E3-R(AS<e`EQ<P1t-QqX{L|@_4b}x&8<)CUH%?E?s>}+rAm(b43Ffi`+cF;CjWR2bUuVcCnDO!*T9Qu{FJP?VB=ekKC&qM1wT1+EOwiB^`}xb$)5pYqY`yl%`vl+7d`4akez!e{^SwtyO>(`>UR>yM<2I1HbFMxbs>6mxtfLMC9xW1^#YWq*4e}}ZI(rr`9W1D<J>RgFO~>u!uaO<NX0TGYgGCCvX_t9y48#nVdLjX02K4tKi|L$eGQZqhA65grk+6!oB<!5SreoP!jaAw@mc7si*ZZsNP5A+*jk&6nq-ov=rTfYp!P1po_}jJ_E?Z_qZ|(9RlQfDMI+J@@;^oP7gKQU8=~8RjsVFPFnh<3J9d`hzNMVE56)*4(gvH&8(xHBdC{o2f=djgo{+~I#&l%X|<DcX4*qm<ODrfU8#8q*}hZokjG{~rtVR>#e>?JX}PjWxPW>5*R2{hEQxDumf+>LgSyJ8^^6?TznVcSE;(}C|AySMj;3fGKFVUqcZD|4OpE+S>mdz#~4zHF}zdinBpI2cq*QW%%7KUqv<cO@rkI_p5#j-soo6LJNo{`laF)UECi7Jx@(`|p2Q`HaVhzkvDd9iX{&^mKlwuUiev39PnLn47J35UfDJ>6Mq;OLk|tLL7}hXD?_22V|RU_KY!esTOav<h6oG<f-Pcz#7&H?76HlEVz2a`_z(K`dsduPnombv1~tL@7+IF%n)D3JxMzI^7rvmK>+13gx70!5IOFW5_!tR%<Oye8!gj8f&kzM(-UjvIgAnU11V$bBm9-qjA3ZfFPk)#{jdf!#3s7_6Q?vLm;'),'Libraries/Compiler/rewriters.☾':strd('c%0oFYjYFV^*g^p`Lw%6bR^Lv;ECH1<EBh`jWN@79FJx#uZ<?Mq>*GIzI1|<U`T)fHpYN?IFy870tqE4G!SOE-}@Ij<6n@U&~xr<@4b8XWk@?y4??TeeVlXdd7ra#$tUEqgNOd;R;zfmXWzjCqhr;o>ook?$tl0<6bmzr)}-I)x?Zv1I3E1ZhVI(E``x_<-r2SHP<43k$gce`iLUjh5gaKe!8N^o;2>O&Z!1r1*)kPO7dpX*oq8{*PPaNZ?IO8Ao_d2@3h*}*^!#2gybaq<_d0FIbDdgiwq4yg`4K?H;46qhgSKhipa-*RL*x4n>}L1BA<qDwHL^mE50QCzyX?8}agkgmKhyUw`TK3T&Uk5}D7P6es~;-rhwT%ER;NHGU+}{F-UNIY>&yjS8gkv<Z12B@90gN>zNA2}p(}5H!zX{`IvcBtj;GNf4Rw0vGo5yIvhhLJJaB~OEV*1594fdR^ZsCz2Ci$N0??o^G*ob4U8mqTry`W1$0vs&jo~t8pgtCstR4ycDL!6+29&)|7L_BRpN&1}ITq^Eg+9GSKLw3$V9YZ2?0W_{@Xzyrd`PCZ<9P>GyGrgd7V5q~S1FZtB0+%s`&-RG<v%=!s(AqT*9m%aon{iF9e(${>hS2uuCWo<b>0Ckb;(U~k6gfW8^@z|1{|>=@W{zKIK)0sVR24P$^wsE=f(4l$15+^V88(T%43UtO_!m3f`c5UjFfvY&0#R8cVQ*G`Fqe?-X@@Ve=aDM{1<ERzN0ji3=|t11&o6*ut^Yrb<)Uz+!eR2z?^(cPLOq`!9C9=Nj3ati`(`)y=tx1?5W}ii#{dyK(bGe+fp(?MqeRI;6PlSp+I+I*2V<A?@?tlPp*)sE(Lk4jLT3pI8V-#WvK*lW6$L>b(^fX&M((4-G|o$c>Nt-Kf&wyFV|L%!|P)JVEoNuVMno0uE47VukFRcPIxObAw=1k_1o2MJE+zDhT9KS-H?QbtF*BS!X(LjoUD?|fWoZ*LD1{?&8|aL^BFiP6}TJs;PoxM0LU8v<c;s(^*y{E!V3Vt@d#c&C`iEfm*D$L4-p|iz$uk0+kgA|8*lE|=}*=GU`n$sihwg6&UN|MszEqM?zoAz#3^u<Ml~7Wv_ftv+TLSd)|&;uWJM@E`+od=Dbv1;dT`9+eQId<;A`YZ%9Ctx`HhgP`>0Wo$_>940Hwz&o~PO+d78ot>GnDitCVP|JCq5kwIhDVX0BB(*%~eo0+6zU(C5KyyLSwsV>%u8?Y)1vR4PrEcKWX?H|w))<x_WVGW^ukKJ~iCy49IEVI{<H^A@aU+`?tbmU|WBUeK-i?ErO8b|<Dcgd}ycJ4#lf$8h!lj93B}=!r`?_MvIVDK{M_>k8w=So(;?r)WB34%J9jf8aIh4|Ld((%bNUm)!J1Lr+;V6W;xto}pCbCd$oLFAGwdmlXAKltbuepnl)ekbb$d-VE017#sMcE2eq!nA}J1xl9(c?Jf)!wz3N}Sg>#m_L>%I&dp8+xfD?|n88`G(s0Glx3^r!^_*fsiw17RB6**z!zM2tII8O6v)7VIBY-}9@X(&!BfAg$dH<om?B6|lVBZLW->4(_QZt&mIR)!>tIM%wkfcsvgoW{3)~}MQ65vw$er$R*=(qC|S_>kxQvDumx^enreZHi8++G7p)E2{Gy`a<dJI5jcSiM{Aw>wq8*P7Mbz9e}QilFag2vD3>d)UbljkqE$p|FUH&cZTziV%uSL&-zR0PZgNg4{5^={D-Mz%7eysW&(w5)!*d_PS-y16s*V!F@4xgv5yMEOo^J`oB={8{b}Ys84!}d`AAs$3jr7;G;TV93u;^fC9raic5&)&6mUy*I1)#z%ID1ihqbO3{p_U<5P`Xgg!8wMY47Rtuh-aD8xo*Cz0yA3fr<`h`}1z8eCVShc|(80Yv-%VNtiIMiyBa)uToqeRDVrWY|~Dn>N-gGrX%-q$`<`2A%kXoKTe%-OTgM5r|?$2$ApH=v`1<W!=LO-|1PPU#?wQb(F1e+<Ed9Rg(w>RmyTA=F#AcqTA6}C{g26CSG?Vxwhps#|U0>iUpn+9D~Kr?Xlz(aD&IuqW<YeWWkduyVhL0+VeX=rD)!6s-<TM(lTQZq@IM=DaYbk!h!3A|Bax!3x+q>HfX5DT*1FQJ8*@DVGR3<N3+weJ8I?U;V3iPS(F{~11;Xy(<)n}Ch@1Hy5JBFsscT%i(<$=!xk<b)`>J*^BaaJ<DVEk3Pb&NJ7`Y92@ecw+8+OqD>Kd(`6$K<)y@$t4Gau>`hpTn#Jmys82M-hreCOcsVYLLAGFTZw(YaoA0DYU0w!q>6cv0_BRc&SCbwIt&r6<Xv+PGTemwWwu>&!z0&z54DQLv5b$%hsT2v@+a^bwl-xvA&4cN-q3uFv#W?gvE2*AQX%#@zEJP^w=suZ(`@%dXKyTgXN@n>M-1HzdDAEC|GrLUW?ld_S?)>Q8JG16;lbaWM=M<etWN^kgS6t26Wgj2;(5#PggS-CE$%3?bxi|rFy7ETyi?w&I}8#IF1plMOGEF(%4(mZJPuUrvT%aF#B*ceY?HGXyzX=lBlops`9MLDoJ<7~)8mar~wdIOfeNIrFcm9j)XOuz#}HtIBb9AL-50(zN+&tjF(31$&1OVVeV!}6%-7g%adQ@hSqYgWG)XMePWx$4|z3gInBr9oqhh$EB>WsB~v_%oq#gn1XyUqQ)!ri>W0>2XUWYB7ePhs291D-L(qo~Z$|5d|geVKEu17q;p~7SFme-cMM0F-n(=3!^)fNEH_N&|Ma|b~wor5MD?uE3LTS{RbapJypI#cF14eK0(fh{K*|<H8m1b(253wjK|E%bSIdas|8i?l)p1|FVI#^mns2XB=piM&NBYOH(c0>7F)G&O9?E-m8Cefr$L09s1xK@25Op+NSK;hqK0~s+_`Kr=Q3w)o8|#jf7G5-wWk7x3}1~ispmHF4DBv~2upyAd(1Du!6x#$6N<^-dUGz=61$jmGMagP0Jg-h<p_XlQmxIltF1Pcmg>!jCxC3Qm$Cs3(-<AssL(D0SQ--`+p+<-spo*@#yc^-f;=`Fe$0b&@uMiQeI5pAc#!}4$>Gr~^+BGIhn~CF^Niz*9D&;j8b@tW9G9mguOh;9NkVAjKQA<?oE{Vb$~#JAkJY>x8;ml2z@6i0?!W}O&&wx>bqJGe<-ouEsVMx5O-Drzosx&`FH;B6ST8Q|qe(@KTM<fyE{>|W<gUHZLkP=d<E&m5le*8Y`KfyZGF$HjvzwOLG@_-RXcog)YqN?d=mCeuVfq<L+2i9w_J|2BSmqyAQ@JKJ8H&5-NQNpoFA3;dLxt^Dzayy*jC4|yZK2v-04}nhb)<JDJpsiMKP_wG=V;c%j|O2&<$A81Lw3S-jop+rE3jroS(Bxnz~^zt^_mfVzW`Jg7`BuEICTGyYIo_>W!Ls40x=L{5%O$I&XLm)T(Gg>mRw(Ym_eD4r!+uq=;yIp@W6@>v*bI|8y>BT-iZ`G%`MXyvskDN4SPwe$USZ|g<@-*^j>a-OOD>mqRYA8or!u4NlrP8kF9F1$5C@CXtt&Ta8rx{2{qvrtZANF(n`sm8YXFhshuZdEBMn5ACD=k8o*2gi&^r|4Wk&gg6B^8KzD&g*3e#b_#pjhex0|_$j{Vw={suEfOJ*CJ7cvL*)9u&Wb$$mj_y-(!F70>kYCyXpaw$;-En({l<6{2<HD(4P1)n$|H!|#v?FbW9cd)`36uF{ZsE_8RmxUp$qHL8OBz6-Y@ZX9omV7_Vy`@gK#7WdB3$~%>^TH(g%YFkLp04QG(ZR!t&=bXK>2`qdspq*ZtL!_Y_^>>Qfz)ZGcWGeWxr-(-<3!>c9{<+l*<yiPL_%V+7<Zy5Z&@Ih=;Oyc6VUuF)eGmQI%qkn$-xv)*xlp4q<&%Y*H<rp^!_pcu}`+`dKWJ)9wKI9Cn_^)fdSZYIqt-<*`9v+hZ1H?X!Xl_+fSCHTDbJB5qogr;Pz#j-v*26FG~HD5gjmcioxqxvh+zLwJXJ#H`Ru2jl7CedH2D8u>E`$}JYSQBtrK`G(u@sg4$1xy1^*@;*{bUt=qryr%|`S;)haxy$f68&f3`R0uO2an-~m(RBbmI}AW)(CA7f9Cq^ny-Msi<wPx`=l<dY3hHO%&M$3MG7{LdaB7Jev^Rs&PI=|atI3U17v+aQUe)B)RKC^@q`_70uSe6KE|uVUqxc9j)FQSeicyug_V^6tYQAVDba{EjRo2j++VMm)%2~2t@7BO<(4#z&4oZg(BGBA1TPR>ZOBzIFtp%n%Bbf_*5mS*yY?i4j*JXuTF`Qx{hOHqwse4+jbf$f&!4_+V7Tbh^ox+cJ3T;U|E`Yq)#~*S~=G42@PB2}iQ`d3S@Zr%>UBHU62{omLt4JE&WwVM=KbtbQ%&1XS@RQ>im@JXIw&p=zLioX&>=0py=B-A85qk;Xrg(UOt*<`TV%dp-z6bvYg2mB`@FI@5tyWC$7{&50UEbl#{tQ~I$I#*nay*d|)Tg$GV<Ez@2<Z90W<fU!+gWm*=YzRT1_w<yVv3k2tDzK?Yq)*PkZM|!<qZ@*196}^unx=G8qY&e5o4}AUM`21XY)RBU^kM{f>F&jGE6XrUW)0+MeMpPI@p6`$~3&sX0=$*t#SJKsKy~mcdqL-LO+t$SyL&g+*gWl)EV-Ga@2A1T!Ji;K#`%3IP=j2k*N`5kV|H&SAg8AD;;i%4%60D*5o<hZR!=powRo1*F|np>u5o2H#IkrXX3xS>q()ac{<(2qpobE`HayYjYKTfb7GB|A;Ovw%O>#{e9t9QtjdM>3>D_<;s6p_eb7(oR2tlVVj;`XoI{6GXx>&1(Rk<ypiysjgAQtplC<ABI_TswFT(>e9^gFqKjI&x>42%0RF>lM0pnigh*{(j$B4r5HJD<nbWOF<U<A=jx)lIi^<6DSEpT*0X`w5iz&u17gWrxS3M)ucn%fjQlCXGK0`4AZ;WJG2PHnEPcZ1~%v*NQF*a(v$eIcqP_MuwKu1Z(`b#b+`vZ<E(_&|xqHNG{Znaml@So$_1O~@fe39UH^t=G)V`67}3nP8Uq)P6B-&B>T@OUl}dj+d-AH-}L&oY`^KFv^2cY)=h)lHKohtrh)<WYk*iW3=JOJtDJ{2-H<oA)Wz$#xgZy36kcMkgMJXz?G2ja!hqRlQ<Ve53UU`hLhs#s?b;*Soa8(n#l9fb2C9dOHnC%DMd-t&&~9!pkJ6Tj~`kcBW<82UDFC$xWLBB&(R-Lh=3tWdo%(<Pk&s|f@z^2efnLkdvhS)k|{=!!UBpa?PjqGT#s}R4PfA)8IonP<Ja>2riaw0LKL(oP+hla)uTa9JsLKY{mxA5upQK9G%04|BL3vZj}_l0GNHv9hy?&^XNI1d)9rmAQam(<J@?#E8(@`@SO7ZaSo8;du!a%BG#!i(wOow=9qHekc2k(gdFP-rZfnt#r|wL6A$CS$i5aDGtrqM+ZkY5^nbqFyrDlIT8;xgMcq)w3DWPh`LNlsyJ1HWWDCcnjSvn0jPJWHm@^Q<?Dmh`33D44joJEgVJJN}@n_hO+J7GV%*7$5_)HZl{d4F<3{wjmz*JALofF)}eoSE>5@%Z5X4s1dn%ytUQD2rd5$)>s-01vRr<?w;UnCVKv$<DzdY00`3@k;qklEge9bKY%_rzACjmh=|TL<Xo<$<N|<)buJUGc3~8xj>%7vXlg`syofvhgGO#d)PCnH56AC1`XYq*QgsK9}Gd}3+X5LM%*Z8r=AE96@T!iP;h_aqrPD@es^T7ioZZt1z&Cdu6-jwZSQ5<{E7)~0t$u2;De&6gw+^30dlZU4gwtd6$lWmI?@nKFFZz`c#!&fS!>IWZ!U{@lt>T0XpkEIh){~iMSqXb(c_Ano+*4W$5}S(BF=ychj>O;`wh29PZ#TUl3EmhNiT+X5*vvN>dvWb5eg{lHcmQCd(cH4j__wi2up&BIJmYwkTF++Aqe{15ac$V{2;3%@1g!YWSk*Wm`M$boDCxsVFx6sV<U`6?Z`&7{{XRi=qL'),'Libraries/Compiler/lambdas.☾':strd('c%02z>u(cB5dY3!aeS!uE^#E=DMBDwDz837AQ8}h36bT;87xc^ogJX9Dv=auT2ydILQ^0RKp^poC=`@d(0<szB>4;Y6FRf6+g-08F%HyHa(j2PGryUgnVnhNrx)liBS*jVvsoN{b!cSx$gynJC*irth$Ordm5F?=QuTv`M@RtwIo+Q9`@a|(-n(b$Xm;Pwfjx&|24i&a08*++FlLX3M_@cUkQ&>ztr(U(dX+xP=8DDanNv7zkzS*3fbuS#qYpFW-SWa35x39rc5#LTySI7pDVIF*%|YUo$GsC_Emx~W+I$j9GW<kgZ7Le~<ZJfam&&SHqsg&^cW8J&K3Jx&>18H&iB4zIf#0vFQey$?0`u<D>-3(tJL5@plL7F+cko~V$lqEoaVodM{sTjPD!?ZkOkpZQ+VA`5G)R2mS8}KG#hgcH=qjDx?b-MIibg~;@H;dFjBe7$J~P|#sdO^Ai(AYKE7j0rsNT{Sfv*h4W`enDu%3a?DEJ{z24?p6#wTjX9YN;Ci(+w@JfUZ7YROqiU@SpGfuP&uCMU!3A^}mC=!0xAEMyt8%f7JtB7H>PD!VgyPZ=%{$Q~oUK*tB_Iq^O3CBDTD@IANjDGzhIr;G<6KtI-Qk3~}<+*adh%z@I91jZ?CoYb9a5S(g|JC*JAEZioeurv{!&egJKPnN5v!l<fX#c^c=9!-yNAMr97k8IqUC$T}5mWoZRNLm{=GvE^aof+^7{S*Cm?()W^`Hf3+!X8q5!0l14g{Ql=hhM-DYgi3aIYjVox&E3kPm;78;1v<havBeIHr0r|xt~A*9)8tIxqxdOG&OB%EM`I0=gzO!UmgECnM{^;hWTA;l+!E@Tnh0WUxT~A?MJ4b7y^;*;{cweH$zWhX&y88=`Zx}m^26)3?L*Z5>0*N$W;}YhS3PEC1!&m=VxMC|LqpB6_d`z$TfFLYGa4@Fb|ujk6Og-lfWk%cW#r|&w`*AZib(*(zr;D%%d#8lTUfP8b)9YKiMsO4L~()Bi?ZTo&s>W`Jn0M7uV-zm2(%>DC~io52QNx^MO=*M+X{4_r9)f;@XU_52SkJ?8_h9*|`nut+p%h@9FBjknY@I+w89KDo@jY(GkV2!88AQ{n~o{I^Q~6yMP+y)u@2fJ4!sH*6T~_^_$jwExgpIBu9lL+i7R$1Nsob%+c#Ue{hpt6oqcB;w*A&QOD)2qek%kO5R;NV-fXNBWw9;!FrXJua@X}>(wB871?q=ZHtq;!!&)OIYWOXk8J=$m+-8DyjB_I!?D1dh#<V{FNtU-EH07Y0%#k#L^hW-qV*cKQIgFyZ?P1}=?#(_dGpmM*{GjCwr3w<F)}gvEyRXh$nv>*;aVeRYC@3xT-WnGC}CSj9?~Tn)jZbML%7qFJb?)I9Pr`3K98=7q&-7#&^LatwGfZAgm^?j#N|VX(T9h4Sclkx4!ZOwos&-Ywww8wvt>aeJZXD|$F{5gX|Tl6EokaukKs_(I)gH@Wl(gh$nJa7@b+#2JiePPib`&t-lPAp>;2ZPXhWRV^j5T?x938drbO+a1;`p3|6wDjps4$87XE%F;w<3}%l@_{KGn1zG%Uflgw8Ez?Grn|dONI~(N2R?h6YK^D>Bk6SUyXc`Ir|x*BnJoUQ9?Qyrkyt8R1VRH<3D7M^RsLlsqNLZHp7BvFdCq{iI5~PvWgRZtr=K2id>RV+|B+n5@8rd*4z?R&>C;r}!H|InNvtwuzfGZM;S)yUWCK7iFRyR7L}&9~fgm-w}a5FRm-%y3o3)XEeXdq+s!Q(1hnhzsU)0CvAj0ZRKSw9=Q5e0(JTXcl+%bSynOYaTW>BNLLFGp5P-;xz#e{99tGhDf4y0uQy09T0RIoJa1+B@|EAvYiVf${zG<foWnC3x$4G4-b1xKqhymlbDXJ`qDj!)J~?+Cb@OA)*(LLkPaLXS$7CWQo2LX0t<_YnI7{sI(IBP;-kjkG)>*$<Hs0Xk1Bb&C<6**MJ0jB?t&_ET%H}N=o?<s|vYs_>vQ`_LEO*R0(#kX8tMee8N6oL|dO===1FyEH6z$JdddIEDRl3q?dU0-RY6ZbkhS&DA>%tE>!C&-}&r4_iKH+_ygUt!a*nWmu%5Q4K7iH|Zz|6vqK@wl+7_69+AOz;AZRD(UAO~|zD>?d!R|{cAa~N21wQan)B=dAf<_lOb9YJgyrhf{<mveSbcjOPAISZLl?hD*Q#{$b@me{z~NpZVt#(N*Z&y?UhZo$5C&rC+!CwU33%&WbVy9b9E+Zj(9n5A)GJ?ASam;w|vT5+$5{sn7;fzrq^uIAGA@u$pH;(!zLvpU)I*{*v(!O9if&Y)x=!6;`w2D_zBaFG$r&2j<|hY^eH%~M(}o)|KvpSFhL#Y(qp*~bck8Ty#6#N_}A5~(t1O0ptIRs$>2wlvga@@OxES<4|oMT(oh+izS;PWFAx4^VL793B<-nkLWAvQc;NO-bEp@ZK1iclH{m0xA<<7k~w@4{KPNFHIN0UvR9^HD4ar%I)m`<J}PTjlLmj1dd78!e=9>*RxpHHhi1ls)B2*3?{O429Z`Vt=E$+7@)xH$?RklVor<Css-h4uiZ}~K4f?GRO_zdpYyQawD2GE%=+Zqx8I#TGgYhNPnm%DCH)n@=Nw4E?jaa2(A(HU0ft-jj|^k92DZj?nHw*7znd)VD#=kUrAC8lv_p+{s?jbr%BxXPjTFCp3Xt`i_=CXIXmg8KK0R3}7s}4%>vDy}QWz*V0Sav&H}GQOf85JLcK'),'Libraries/Compiler/expr.☾':strd('c%0=LTW=KC`JG>JUeKH|6Ul3*7hGAYF|>`k!IlkAD{Hl^$7IE1cRM?7$Xl?88>az`*QPE7V}c=}(2Ay5g_I;x&o9Y7_KBa+?>o0SXXea$*U+dHE7`L<=bZ0;pP}qB`*e2xSF~EiZ|}T2J2Q8tTBTkRhha6jn0Ns>AGOZaq7L-~;(0#&7kj5pp8REb=EPKazB*k#HFX+JabUkbg*){j_|9+7%)<A|Tcw2~M;5~+vKTg7i($3Z#zR|dgT3%4ju7}zMUlQA5K1F5F-a8oQNJ>}fVW$jyCr@%&fFbaP(++ORi-5$_eoTD*$wsrx6jO0&rF>tpQ@Y>lUkC*v;`=D-^BA5{0v=}*f#r$Mz#0PE!GHIVSi=a2~u#EUrA$$D7fN|fJ`PQiTCpM&08J`qfSVGoU809wYO?I0x}}+bfQK*q@{qIZZ$)o&zD=_OC<_O%=x8)yXQ{9!O}MSC@;MtIi;+B$G#p;0+-n)`-Xirs0<32&$AeyxUR4-1+Qf%n{$J6s4ao5v(MOzR0(_mh^V*P9|9f17?xTwNl2qf%ED;z0}Ljdo8F!KUV7UWAcv-00&aL^&-j&Jp6$Op-+%dpxr`FL37o;LUw~(Z0XY*dhw=xPVn^{TCH7Nw8ovL;_^#xe-Tz}_&yVc=CD;D9jXmS`{xR47F=J23-al?>_Bd$v_<~kJ7^S*d`}(!%X6^@6oo$qcab9Kn74Q3}S3GnSPO!4nfDEnh(x@TT;{#~CkA*lj-p4|m8t-Ev<3n1=+qUm>=a=5Ey?M^*&3l7e%nxZ2TDgW+-#Bmn=l`WQYt;?t*K@XC52)}r)SELl^8Nm;jE!K`<l6b~Tf3Q^X3e7N08pj9=>W5{R4<e@45tQ{<37qMhZ~5bX-T6D0yKsz3UQ7NuxDRZovJ!_vI~YSwplpP0ue=C5(h|Q)^>!!{E1_GC851Wk#mD_iIYGUafxpzYbg&XA3IvDK&P~w*D(i{yE}(f?Ei{1-vD#zgn0`9jXh_pG8`Bk$QtiJK4u#fdZIsk0)K1JfWJF)5__&k>>J+nY_m&~%~nE0f9F%#HhQggwfC%BjXdlW#aciz?HC7zjrBtV7+-wk>%NT1&Kn#Y6NMiT14Y!pnLuVsKN_LY%+VN28gXq18XxzgF`VQFSJ-uSLm%TEGWF@m$oW*E{2+Kjh*mQ*Da}c?cHrIKzn*%Ta!}iz<xXn?h-ry%H2)KfsgZ>5AKIAWFj<b9Lg8y-e$uYRiS}uJ-3-WLc821rEN-N{do%cdRF4a;vB%Cnx-n=U4Z>T*T>4fi6&+UBjes;!qM)5FyC$gE^yMG}btGmP0UY!fayb|cNho#;33+F}3hAopJ0fen)l3@A<uD5Y4sWt&rWAnHT!iEp<h&sd`&=B>E*#M*fb&^0EreSf`<7o<`1J;R#wEAH{>*ms*yr>-p}(A7w?IC4uMvgBO>Z8AJ-E>l;$%8O;E)fKA*D3WvrLrv1*nrqt+_}jGM8JOM^T9lMZ{!_=iZlpSH*L|!CAG!aW-7?!;b;j!7ae4wcBBH(er5z1LAhVOpR$MOzl=1(D(yn7#l%;j}8$Hvyjj(PL7e1!}ATVAM>%w&xEJnvFB6;qXt*BjLA1;n8KJmh8*x9RtF-Juv)K0ksZsP2P$)@fToT8;E1N<c#)-ey}x|kTixjG+%@X`l!-1|rz(LC0BX0ly54*IabHl#NncRBo4vo52U3&_x7i<gRz(aML_wAbKak}`DppO6<!y>0aJoxo;hN?XIa6+Qh|KO?w#x0Z%dW`lWp!1^2HP!@&^30)J+Z#Vb_dNuoaD2(n^tVTMNfn{(Cs-)-rUG->9W3S9Flug_bz2<yOu=jl=i?H{aniA9=~qj#9bQs$XTZ@xidi&iaz8IR7_9Wk=MO!X^<}<c6j>bYKYv=TcYfvm4hD{<k9Q}L}H2ESmJ@PfL`Lr5WWBiC_7;_yx5N6hM#$QGf+j8s#q3ATe33GS>;{um<L0UD<5@;+zC)q;thHLq%*7V6FLhBP^f)8juy~aURr8gq?W!VUU4r?b|OpuDXkvF23|^M^E2#|iJKoEYS<voo;YyWAoleiHu%{DZK)8<%4;+`VGQAvjt1rfM$4yY-}b`mt$#E<b;i?PV^(Np8NMgX3Pe7}Jzn)Nd~L!}@(Bus>L8J3lwxnxkG*(aNNO=GSL63Oo-+dB04Qf8s+@{qaW(x!@_}A{j8qDeaF;!zBXBzXfzBk_HZV{iFpgCOv~?*6nAZfn8sg%Fp=p6Hs0U^EK$`6d{m4{i?UIj(ihW7#pZpFXw$sYZax0L59?9bQU>8KS=N%5>V?X!$uSlR+f5gSV<WfBk7g?`J&GK8WvND{&ih`ys9^Mi7<)LKb0fdaldt#)P>ewXAk*J0gaS_UcZH(a~^1tzOa8-jdv1E*(KvZX&wR6xECM{7%kXAd4YY7<J(ar>kqRFG3pMm)JB^JM8{N<6OL=ziD@D~I2h*RL}Nrg(stl(7-S^=6XBWl@ve_^L6?_%T}Fz@Pq7ejMeE!53+A|Ihm<%t|w_X~O`U3%4XRoCm~M8u73FK6+vW0nqetMXLVqD@Yjsc6QQ;~1Ifm}=t3f9{x_EhRB8LVBNUdun*YBZ;m?s#$dlk*%`(R>G7+zdrAVT)$WCw8OfWZQ{-MLqr3`y~4oNWmkv7b>V~R%iCKUHjv-5C+w~Z41!m$rHFn4cvFP&awUZ_%{A<NL#Cq0kP$ou;-_s$m+eXKe@KsM-hHgt#VJmu>)b7Q?hAR{me*a{4{XXsKt=@ylUoU25)LP*!$j)Vc*~5>YIbXBPY=8coNU?{REWXhSU|?i;cJn6Z9ZMvHw1Z)eTog2WE5w7Io$%khmvpsW>fAcN`|jYZL%*+IaS6mt8m)X)0<bCC`*m-wj5i}{i2t;v>kx_eP;$!ROY7zj@i$+PjyJV&i0F&swd7@`<(q&;ro5~!Ko@l<qOzyO&31hts8cTa`o~9HLE{+;s~;7d<MW55Y*@aP#z2frId$4Ein5g7;b712&5TvG~8l}F&ES`#ZNs=Y5nH6wfG=u?HBNQ*pT2j#QnnquRsiwx<PV|<hCTMU3tBuuGC}SPM@9gWL@<c6$RD4@c``Q?e%|ns?vIr)?EI70DvuwJ^'),'Libraries/Compiler/tree_txt.☾':strd('c$|$@TWb?R6n@XIn75g&D>U{k5Ft%M4W>=$1%xy#n`Y83-E6|{1RunQUJxl(p%)RWVv$<0Qk05_*r)SP{3V__JDapgs@;cVcII5Z^PTU^3fO|}+4+0IarCM*JzJSua2&x^C?&Vqir=ogek3fLac<#nY?mt(rplGcTzTHfmy5X>^q@fZi`ug1glpQa%;LIwJ6%hq8nVek`7rd9bRrcxUeJ(%(%uKK3%{*Qis9om8Siiwv=#FLwj!0QRM;~@ERq{b{e)6=!+<5nv@epvMB+U<imek_)$y9mZe*CQv0E&yD-)vQvrLvHg^%kfdLNG9C43z?O4kxL3dOR(0JuXyo9&RH$8&gnO{usQaZ7N`mWsM{XQit*`sMda^}Rqwef$)aO5=)}SFOds@#Gb(j|9JZQ``x54^KDX4E8j9T<yUN6aNxKf?3j`huc9Y2bzH#dzN*@J+WU!Be&C$K?6xiGB+9aBAaC;CjCenK-I|imZi2ihi78CQV_5Xr*L7j7++Rbm0z3_B5h;pM~|tJ130Ju3)r;TOgoU475i?%KD>i{JY0u2@GVO%`iYV?C~W4tt$M>X*)s_(M#P*gDP5t7bpSgQ%OLpx+wjW-vWRgKk!2v%u5w|NSF(mR&}(`!d$`9banE7{QJ)cyO99Cu>WhxrekZZUb^6kJ{IV1#Pzn>V6b9#yhTLs5oVwp$UW*2YTSUqY6^S8X%ot=w=^w%C)}sDfiZeH83>oz#PIh&F%~_Q$%EK}@!4o(pRd2vCd=!gQ51jm5F}F|@f=_Ziu<zju>}r#$rj3vBn07qkf1ZBQCZi2`ujlzpJjCCH&X4<f0yP#ZPUMXi(@8&(M?^)_h$&8VaAJk7S-Ve6BBd>O3qRmwczTTV`qN`w6XO4#`fj^RG#$dO(67V=$x*;20zQqu0!E)ZaAYVR(Y2-uJMpd6!rQ7p8~^Gw>JVL)vznT|XfWAA*p*gFG=21t0e&}J)xxhvbYl%^PYitxB|R#%gyLK55I)D)socNg%CN2'),'Libraries/Compiler/tree.☾':strd('c$|e)O>fgc5WVMDEGO?)MoQ9KL=J(34-uM(_7+*IwB8g;#*XZb6d$P&hawfxf>aPfs!*>SKyW|^4)e#D9eZsjBw#7=cy?y??VC5t;W?a+_wREljrHKsc=Y%{O729lucXfADs^0T9L9&!Fy+E!jwA3tkM8yR_lBd}z2UyRGaU5xFptVT9GJ*532kzZ#%ND&w!B8eS2N>#3+M1t2B~}!YnkfBY{sn@b6&u;%XZ)jUc*b#X)t^OOnU~G@SW$Y`0)YW6^k|iSJ;g%J63wCbyBP7Xr~rxo<!+I5|K-Ve-*!i3;4QPJc>1KP*(j<!ObA3Ob}6}D!-PSn+#46&Noh|zVLAR^w6Ig=V!R+Y~znsE8awfR1iDlMsTTO2gyP;xIfiO+91~HGP{u}@d`e6nBBOD>1;aHEQowZ*wp1VcuUuo75J<Q0e<1iIsC4b#qg|Z{T4E@*V&}$Z6tCQCoFJT&bCRrhD!q?o1|fIq<G6^dvT<Mx2B;_a0)*v>e#I=3mDe25O|$1Yfl1CRG9QuWfa{d`iTLZWO5$Q@t4*PH&5ba)-~{4OgZY_#c5InPLgQ7S*0pY;0-Fcq^gjEqZ|Wm?ikkd0>$93lWLAnJF_4qZgQ=Vi~5|T*v!Dki$M?yGvAzt1rap;O@aL|?qto|^6YKU9}Ia*7?164Xg6GMWXbQpf#-*`mkkD((^g-6$0pc!Sf{1XL(X<vc&O9$_+&$TyVMW*(+UwCxNWybyH&HBbrN=wgx!(^b1`7Aw`v(D<P6@IYBtkYhOVfH;zVNui+=#;BSJp'),'Libraries/Compiler/node_types.☾':strd('c$}?RZA&9p6#nk7m~V5(rc{NpC6Eukq}|f25qE_JSB5c}xS>fVos8W;DXiAFZgo*(Y!pSK)vhQ)ODT5QT|XS?m;MX?K>Z0l_hlx@%$+ev19~U-p7WgNyv)7lCTCkkB{y5jIF?nYDEVU9vK=L3WS*Nnx(*BQ>dQxC>G3DJPSmnFGgB}JKAEwNqR!;im@-qarj0^{XfZ`qwSbOeRvkTO*+s(%3KJ?j_V^+3YguL8F{TS<Kn4GE*};*KFH-5D!PH}YIF%e6MJ)#QRgy}2O8CsC(_{EN`EmbL56R`LN<2ZQx8MvGi2Cneb+n`YvySjRJy|oSz&!j42c#F8umL~CluAN<RzjJISx%@5KA^w_EG0fi8)i)D<$`rB-lO1W#&itFu?c}CIH9IU#mSnst>kk;Q87_Z!C7n8p%m2@cHS{njdCL>as`*fwGDHy2Rj5!Ynt+r_f<o#)EKP8D!e1EO==SHa)sH-b5)2?vkZ*WqaWLJX6=%gp6tV@;Nu$n#@H5&;&j$fg!ge}DE$;YFfw1;ZbUR{U8ukZ9ACpOi|IU^z$uxwsxd{N;M675;&iOTVv8r6My6vb`p@F%$Mn&`eAQtS-o;wPn7J(?vPEg);~cCJxX=j63Pv4fJ&+E=ETJsubI^d_iI02P$Ywa>RWivZrw~D*2w8l%*?Otc+|VM?NGn9V_?SWNoTzpxvJP*!wPPy9zf(l2!~}NXLX;^h>OKwAMAvX>8(#UA`lsAVA4#T2zeZ=;><NFWafRjT52D`gZyc+h;VRXZ3+a`zndy-97}nq{j3F+u9M<6UUQAml7F4RLm-iOcfYj4AsWzJD;WXF(A9~Lw`uh5E56n+L>x$>i+IClR9_$0TW5?l+9R?k9m$rRN19G36Shv@0Zy=*p!*b?{t%>o#9f>M-UDbV)YhwHBsH{i?_<$66wbh`>t4%;PgHS9+rP-pdJcYt90`@FK@tbcAJE$o#E#C+vd8)x4H@8Y!`4sfI8sgHYYgi@&?a5mRPu~4r??CzB``cZeq2TLo1()TexEJnCExZ(0yDh~UZt*;whhjXIo>eYUr&#XbDL{@~Wj1cY+m70Z1#ztMFycH)kI;%ZhxaVE4VX(%j>8k<g!IRd@ps>|gSr8KvZLfZ{NNtknEa|Jh-G1XMUyZ)6^pK$Cz0+|99!mILnxnj6(h4MjnSTui3@rd35NYkQHJJ6IT2$sI(?>HlA+an+`5YvJ^E#6ZYc#eq)4=4#wf_pLbtU@w40R%1C#DIlDhM^RjlZ|cFL<cZ-VWBT6<R_=pOj!y203rq)X>z&Iii3D>N))DcX+EKI$sHH!ClrD7lXA`Lf*z1C2bPDusN8UQ2rYxsqoPI(i}Gy4}Q9kzWK*K*?8>QLAL~3xV(0Ai-`K+i=^VZKq_#Du*nXWqKmJB|vv(t#v0*j8fLCB3A%!I@C?gqs6o3y6(H7_(RC5miE18?fd0C4h_w1ebu<i&q=pc?qOFKJ!@ukLF|s5`F4NnDtLT%VATB>;-1zHQlFQ14{iw_`%2*?<h41CEYZI=8LP5^H|L71Sa*H!$9K6uW0&27NfPQyIQK$b<!3Q;G$-e6-AXvfMH@)}R7b-62Wm)@W!=qk5jNR{|K_Tu7id*fxgnvi7xIqprV>rK9na=?Exz6v9K!c@|K}C_`|*CP!z+J>MKau_DD6<UVv3nyO7obNZBK=6C>qg7I*}gJp9~JAl9SyvFblAcFZOas3v;1Ou|V=)NZQ|lH@?mP2z`osKRxihrOHq@U{RC(3c;Iwi3%qmR|%Xsq!m#K6#YfvECgzmM&}yddc9hxYoX9hDYPi6^=p+mb8i!TKaP$==t1X(Rwz})yRanI*TlHsj;twX2NzLCCsHZZdwn*=5_4-TH8`Anm`;r($5G-x?r2XM'),'Libraries/peggle2/gram_tools.☾':strd('c%0Q5+iu*(^<7^v2_SGrVuD?{Z2-aBB8^?tXwwL`3>1)6g1h3b2y@8=Nj0l9En-=g3p;LX$2R2Fts@6<6WDNiafH~2+lN7)`p|EPzNF_2XNE)WMO3v)k%gco&&;{Zxz3qc$Kjj&%BeRO-a5VLIMn*rMaw3gAZofnLYYl0i%mJDIbGKe_n#Ga`c5Yb+HM+06{e?NKXuws+;!8z$&~N#-|?qpzCmc<cAG0M>Dy!mpf~tcc*ve^&yzRbIzfT%ZT=a5VH1FE^9v2W0bh3+<(K$PIt-7AsQ_Xu<8_^XTIO{C7PEcgw+X)hpk3sLKt{YE@ep{A-=%%v=poV#eupx;*jS9$JY>@GQa4RwnlXdL1HfX`@<1oQ`Zb7WlfDo#6e8T@Uv*7E6>y$pi=Ya?42cxXmeP=SiIC)yl2PHXsi_sOje}44BNGjcagWVU5%_30%8^S&4JtUzU@x#0b4dk1v6rsJp=PhqHu)d<m;7>$i0aJIBplgiPfNAsoaY9=#lNJ6S_KKvCwf-T+J`-^;>yCAALj(L5|9M?jhukA@;6}nCw}RT*B3S7XbF~*z;Ai<XHf_qFvphh9}Fcq$14jzIZ5Xfd3dfH&ow2*iIYF2#~52Wwmda#Ik_nxe~V1{O8wht%Q>5%Igi|ykaCX7mL!UmxwdfZL%v($Fd;i*!W1HWoF!&tz(yEM>AUU6N$Mp2ikCogRJjj*`@{LnO?Go60XB_<N~Sar+_mB{X#hAbLBahDlhheP)G7nwC&JE0<9BqX>~F#Nv@tM09_N}z>zCVy^vlU9P1l6+aXJbQ63{rUADtF=_%;6Y|C6b;@-;a_-CiL#Ugz)gul7rft*E!2h24>;Dr&cZt^-W(@Xw1HyTf0|wSp?Ze#8&SaE~&R)Bost16nBHN&l%WlUXU5O)6p3bBsx-5VqK)g?i9?MZNN(B3oL6)l~nC|6_6{K)fgD+*MS>4sW}Rp=lkFF(epF;I~OWC)+0LF^y8sQRaqII%ZOuD^faEp!5yeI=5UEo5vn@X-+Rn{M3)aq-^fbb&kTf`-S#Im1xBH1d4>{r67msKB~ra!G7cH=^~z;eczmy@1U(ZYD@ry1_YQf+)w<IKc|5odI^<6!SKiY3V+U2g-KAd8uU2$CQ|Me|0GX&xvIh_45F4BkVJ#tUiAZMxBE-Uvf(%46@21&wcxHT=X?qdoS0cwn;Dmk+mxiZO);zw`%UmGO%px9hn^9gzzf&9UhJkGRg#KYmgpTpQ55jgezveaF6jH!ViBem$s8&ylZrVK#C)Y-4x9KOcvbW|qT^yG5p?FK8GG*ef-&A19*+1C{`XEX@-`q$ZqcG=+IfdQMg7D{R--r_ehRSv>fJc;oWKh$Mqa95VL$AxrP+Kug?QVIL&tBA6G4Rd2IQD6^RQ%-(J)GhlHOdLwSY1a;L%A}33Bkm4w+7lPbU_cCKbwTzNQNHFRVx%d9?i?aMV<1H441MX}XEuD(44T)5Ka1x3!o=Ps2aR^6fxd0|Osb?QG<-FehMxgG&>1-Ef5nIucmyd=3@ngPU()c)(@{MLX(#XG}dE?J=z}wX_qvT_;(KJ6^nQXiK0svek;Lb{Pue`~fOehGd%a0A89)YZA~M2l{~s-hD%B5o}&0J4S(pEZAbh9jnxDnBfC?A`-DP;ZQL2XX;KnXciZx_$>M21S{gck%F~v-`JSU_Hu-?=(T-Qoz&$6cT$%Rx%^3-AmJz5M~ZM4ek7iN5H9X`g9Ib;t6al~9U_|hg4sI>s;Gkqw2;dr$yD7+9?EU?Lx3g#`D_x)r^6n{O~8?h`E+!;UJF;e*ukV-&c3Mg2SV5l{(Hz!vdO@F7mvufZ9iN&Xr(`m|FgTIAGy#v8kxn2^#?H1?e#oCe;}CRfpn2IMszl2M<n*CiHj{dZ9HY(<qxPSf3|=ja>w1FQs3rxhDuFlW(a?RDnF$T7^F+kS)<_vU&20>)@_CtbatVli;naKzi6YMKfwL67>#>{oiYaD-ys}q(iPW$a?5;yKQitYyDaOKxA={G8!a&9z*SJfMn3eIp~6J_@Q@a6VkPtzhC+V5xvuXuZ}HFgrY6*v{rLNIX&rn8&qAls2<tKwdtRp#cyoH=ESKL*)_UURa|h@>YRF|%>s(kagvAe_5z-*P*?aHV^qI2@)3bZ;J>MUvY2f^@5)R&A0}iGCxtO$Kzn8)b@ZS6Fr$CLt7gBrm-E-$cAjW3Kk+W=~?{PuohVaTS_zvZdKtCXmf_#J!)LGofZqRk=xXS;+cMA8-dFPgC5OoRmjJ<C3OV3GTH(7-ZVirpnlWB~Z-BPQuv}p%hK_es*akrc{%0t;<d5U&!HJ0Q}vUToktyXK-UaNch$+eb7;^N6UX*4igm+`V&_JN=%?ObAG4r)6kufKbZs+GU;v4Bwcj5q}UTRHkm=f*PlD-)J>qcRO$&GUj_I-s_uHDNW>tEvG*6&s*p9y5zswvxVzVvK5l!<Rfgvq_jVFuloumSJBCXcbk>*gZc!hHwVVl)9-mzk|WM_wXXj6oE|X4_?}PxH-*UWitpXOvHggjN?MH+$lp!u5frBoh^lyJ|EO!gwh!yB;948N@U@aM~Kk<Q~p<Q1UUti7AA}pGNt_C%j+jjI46IOKYlsmIMn#L3+$Y-nO2U2P`oI$<V~u07r%(H<i*fa1p`4W<$M`T{CdNZr=yQ@*kc8ItYF*xZU)1jvS`@0f^91v*A(AtlJC&NWSBA(K7di4nawC4Gh6n+$+MUzYl|gIZ`>2m+__;Of5|bj8fDpL#nRf(d|w(Mdl6&mxC%zpqktEV!C<iPE@q589)Q^+$5c3`UXlv&oivKjOJw2bV9hXM_2toZ3X7x}Z$>t^2*ptdSW$lQ8$)pE7kTDd77;uYy*Z|)Be~&B-J@fwl8_>+*ieyQuKyv0{lT+U4~SzPX^13+oJLmpmj|w-jXe$o#-I6pY9&$E`+E1@*I(R(zklzbr1hHHZhQLayZY&SgQKr`dm9_))!9Wd>fmClYHwM%A1+_gDxni5PFpQi7s`h#AK))P%yU_o`CkVTQuP'),'Libraries/Ń.☾':strd('c%01|ZEqCE`MZC`^aI*idPsLR6!oP0U>T}bZ2&n$s${Iyv7R&AuJ5k9YjSQB2~0?;q%8pqN=s5qU1-`yv`W+}s-XEW${+DB>GRCX?#%4$-I+L54Z_RL%=7*}8%6vb{{D|%yL55&aum^^V3Q&mjIynM5wyr=I=b3Va~ift5QGbZY_vt<QJS*2NJhh)BwOQAR*(($i)}{wIpI(Ehx~K?ANYNj-&|OT(|!(bZ}WTI1p+@bit=<+<WWSrJp$MOM-bybEC|B|v1fw~NE9W*qyTz=xCi_mf6*dEi=2#Gg!T9?{{z1rN`L|=a&YPOAC{YeTKx(z82|Hah-YnJ<^~F6teuS4NirZYVQJ3D+Iow;cJUkqy6*CaEtJ7W{ATaMXvjhu;zmXi5P~3E9$_JXq&X}4MUhGJe|(;PPve2-Gsbf}Tx+kx|K0tkjXg{D{*G_|qOqrA?_XRG)r)iIe?rfO;o8}Ct+04BEc(e%>n!bWUES!DN->iznUG{iHY;>$1x1Ja^P3=%f6++`pFZZl3#AmAPJu?i78Lf3jWa*yE(yNAMNj01d%Gv{@bK}c@c8&I0Xada2PoJ98D%6m{MBu=Yd@{k2GG`*{JFUfe?x;V5N=Yitwy1=$WFJi%mywiyP6o!J5qNDeh%FkdRqd$Ev;8H_J<o&l-3}mUawr4$X6A>lntA7!4LTR{NGKCRv>_@Mt$Pi6bMFi*woTDwk1YL$XKzRH5u1hvTnlKVChs?us#nU(3lymg#WiltbQ{Y4=SkO76pcd;iw?ERIMB>q!mYU^qR4l^u(`7j}<}V<D-YYB0W~XX2(R2vM7yDnsYoBh8&N^JAOB-n}JLNT^$ok`kP{wwi7%r!zL!e1}`bKSnWoA0M-xrulbAelt26-4B!Nuttn|~H;%`d;5VDa`8VYgPJh)HRg5t1Ac6Hvv4Y&s$u<qmY*lT-@<pYr5`!6z#{H~v{dwyWyX@G74Yy{qX=kgGCkg*7JYM@YaQLwrd=Ij*DW!M$(-z5EWSp_y51?oSa|h>*F83~H+fL-mw5DyZRx~JE%DgEGkb<U6WC~4aA`oxfkO61>wu&n~{HH6z%}jH-48n)pD$Y^UBn%3GFdM(5O6N(Bxj0g&@Jg$+aM{-A4~^6=#_5{gj<un)7K(xtPdt=Da%)ey^vqf6SY=};#5WDZl)@A!K#1efIAw#vvTwZxJqR0a)RvyXQhz*#C3#X3Jx;v@vq_y;c-?n*FV5oO&1*@@h@`EqExLm6#wj(_uYcHtuEhkJDGbU(vVwZl48_v9*XyVHDP6JOB7_x$Af-?z0yiWriG>Zfw^-IM7(l7-G%XP=DsI?=KUnxD!)@l>P-=F?h+~QI3@nD<tdRA^hF9?leA`{Hpkep|Vcy|?pXP}*1b$i7No!Kjj;){>aHr)DQ__l&o#Pa@!IwA6=ru=%Msg^u>@di6hVZ5bNcATLtWWJkA!7C%xk3hSU%DtnzOc|M#0E|a<vaWn=>6W4XJo(XWRgLSK0nAtzhpx!`v<w<{EpPhY$P(qT&YD^abxP!>C5QgCROVOq!=}f!GeU^d=?CImXJ!_!r8o*`I~aR2sKameg1{Wz+o*b>Uv8+@d{izLu2|bdX4H=QYoC^EF;44p#b3(brUdSziAGX(kk7wh;RnXI%aw>(}ZIg!i6th($%U80<s2@J1p=*BbfZEk|hp}zIBicH)_g6CzXC_`sk{siCy)(CtXEBuC3Rrvbp`h>+h>mYpj~M>q<5Si>#N$q`@w5YSB$MMxto2%RL*mhPztUC<wWh5C9qgLlL0Hkc05}STMt?#X~8)O6zIAsA*jkgS)N|%L>O-<qR52t*#idm~Gquv@A<#Ed0>o6ew1lO2Ze#>LxdI!sd!mMTTJTuh5jOd`pvqQU}@A+(C49j6AmZs7e(voQ1yhKEG3mYAsKbm{B>)kpG_QgzMf$=O|Hba(q#)?k?UkR+n}Y&jB3xX_j%sXRi4(hbvh)g(HZq(leb7wb3M^Xgtb|Nu)JRz<Y%osA9Z|F&KH}VCpvr3*$q6AVQzrE>0cV<B!oZ9XNJ+9pPDR-GSK+x_y*~zw6D6NwTZD7zAeD?kI01-z6rrLJW!w348r|F~n~1DCVHKlaWX<n6c|D%h`s-k1f8cx(0eG>qz5k{mf?@a~gq_dTpg2!9JkBu4e+jMfd~5#Iyhm?Se0%`Z>K<(Km4g76e9g{r?cwsm|QeI#P742{HRNggEGD!_fwFtNotNF}wUZzuz!56KkeKtzdSCKNi^v9`=>Tsk+JyBBJVo?W%xP^D}(mW<UiKf8!9S0nok+Xx{^9Ujf=j1=bu>plXSAv*k^)yogdqR`rIqsqb&<x6y1M6#SO|zPaYoW|2D46%L6iQBbDKr?B~AWtO$1F1y+Ph}|POM>a(Y*)d2VbES|cbtkD`NBZK8qZ;qn-6dRJ!VHqMU|I7-8?R3=U4Ni@_`Cdpw+57D$}WG(pW&}B6!o6t<^4}TkBUiws8zvYc)=xW>Qieb%3S;bIN&ZKe8m4s@z(vy_F}vJ{Xx5p4`&94@7|Md+U<dSbLEXTJhwZiJ8J8o?JO*o3!;#}&A${S%L{o;Lg|HN@2Gfr)jKNQ@r;V`b>_TYnl?c;CrXBX@Jh+=4hGRwR{GYx7RV<Et6`=vLGiUt#Hia#DtGW0w?>9-#ep6CBzICf;ADDYB)(?=LiYGe{y9Px4Z>Rx*RgsF-j+3aa3aS);v)<=vb<W^^Ny;sjCN+nx?6*@z3S*r=oEsAWbviVP5w9jvi#B}3*`mi0fGiv1k*TZRh@(>QR-wa{hf!hMilf@{t;F8j<EU_>P>78Md$U1KN2@7pYVV3{T5MAPoxQy`|v*Rw&GRg8M%ht*6Fgt5kRP>K_|?^8_%#BETaVz5)Os-rDZ!z<V8RJd6jV$ybShV8CrFvQQ=-4O(>PuyDQ6=sTv(jDU8HTO>oK9VADQBt(rJf3yt6hXU+steu}Q93QgPm99Oo|hx{l*F?P7H3;;KK0mP7C3b>;Ua07@*?X!cxz80K*{Z~atX@9}t-i^Zt|2W+H_;ByD!@b==hMAQ&Rw?bY0Nq=`U^D2FpwsCGZ`%=1Nbx1VrLXpO`5*aR|JB|u{}X@D8v@0t=iV>~O9yVVgrQKMy6-HVo_$wX8mG1y@uKBAsWX&tW0ZGuX;6(OzoV=hz$HVL;{(dsay8}R_XL)k{5KR5i*&ntVhJTI2E2`vk5a)Z9N4oCpM{X`^hjswTvx&n0ELYP@CR!ssa6rHA?noNp3-0^vL2SImIqO@$Ib{4(VmMDFdkvGGJMs;n9g2Uv+N-Sf98*^Zoj%99OMeBY^5Xdwd?Y^bJ6*q;uo*4M-er?aisxzdY~L0(k!Oef<f_xFR1cX=VKbN6cpE(I!A+_jqq82>w~t2d9tfU%n-}FWNooUPUDa$f3q(<I30~P(S@78Bn?9ipKWdi#`9uet}M+&-DwfPzJvtKKp5(f|6i?t<jV'),'Libraries/peggle2/main.☾':strd('c%0=uYi}IKk>B+zCJKa^S*`+-vg`|Sdpd`bo#3JeC^|Y|xgLy`Lvp3rna%7_T%9c;eu!uI71@?#Uo0y!3`2@7$nhC*WJA6H9-RNheF%R^>d`&ZJ=3#XO0=BdHZga0y1Kf$s=BJWySnA9bp7sHV9m8GC-nQLm;E`5zpZRD`*@E2y6zs&%U;f2{l(D}#}^ho&$0jaCA(>@hVf}X96D~(vh6BN8jMnJB~JQ&S_Mv%^K*MF`1JaNI7zJ}SPe#&KZJ)p!KfPyQtJqP_2Q@mD4?9-TD;*A`CjUu4%JRr*@xL1+3QU!dog<}dlS0xTJ}-)q60tQ$$snbTcAWh_nOwZ0_NrHN_I1Qi=nPLu5-?{8VxJ^w5Tv@TIc5w`K|2tj=gW#+&5fG`9Is*XE}fnK$wX3r~}Y0efBu;?s9fpC3OUdE@f{!P$6g?J$_iUOV!`YUT7VQqre3!7F&zSdZ1u=!$UMwyl2mHu!0qSn|<yKTiFXx^COq}#*DW_6=vm%{Au-ugn>cvBRh36^^>$0ty*cXA0!|#37|F(53gtU9RzU;h$KkYlW32MZQsyJ<M^z#Z^#T9HnqCeeo2r(W9Z?(iVCc;F7<dd@%vskj?M*1ih{eEy`9|`{dOY1A9zX7_Xk6wRf?0~KF;1lM!%nZ;@Cmh_u{4X+3D$@;-k-x{&3h^jl6Cc@$c0nULSb9C<+qgg^l{W^~&w7S8i=>UdF$#+_GKSi^WAvDFuOZma`h9ewrpZ&446DR1K$6)Sm8$QWphhu4%Pemi^Z&mu)Kuhe3hg038s?$prW=ma$byvKpXkf62ZsiiTmY8#psf78}4VF1p(_1e_C1m9TN`oSnh2>kqVX4ud9b+5h*oJ!h4>EWbzC+h7p-UFf+pYc-&~%kP6lN?ol)ycJ_dD@vPO2MHlcQ1_BxdA%EWXUclV>I;_e#L1r*WlhU*V08YTG!YB`?T9n&0wb{`F1?+hw*Y>#R505i9hon^W}Y8lo=eWV0E#e&kNnb^aS>@w9!O)pAXbdiud+?&DX`FitHMbx#+tbPZ0pr|#Iqf<aRflq&{_I>lb;K$L0E_Pv(52%ZzEp4jhph#RJBaB?-D2QVFD7aeX&Cl=(#bbanb$Bxp3{92O*)#k#R&3SzLDg9owBqIF}|6`nIAdvq4w9d~luimrdiU-i-7jOPcd;-0ufb%0_yFzfRe%k$7~eDt5<-;<T;}KU%gRM0iy(P{f-VE~+y?3YM<zvh8Feya=2(Ry9=-y|f*dyv*&nmRTOurJRx7I1Ir72A&^p!_Zn+u~@@92{_j3$yeBq;+N7E*{~T|M)u5AAVolQFMBHwh~Ve%AP#WBljq(-)GPwD!XJ#7i6mY5&KaQvRe3YQMy0YF$W-(|C<4M9KjE<I$zHN(B#cwoUn@>XGW1Y-&&tmZ5TZru|FFcN0}6*`b#4`A{xLA~k9GFc$thQgfuBIHA=Yt@nVgn0b&OQ*82F5)1wUrVnT&B@(GDC~y<2iLp<}f7ej#*>rLVb;uq6OE|IC5|aR#7!?g9n+SF$hY`<v_~^w%G}yLI!+?@$&*dpKjHJe;kPUQZ#+W~>+m?li&~41UPmHp1D`2mxJ-MF^!AP&b)dXdvTlV*aEhRWJ!qjpP2H7h*&*73EQp{Gj@5*H~1E(k+hDon$=>C`_)iViQ=mqz{yV<;Ib;k|q!v=OOkW308U|w#CEs6?nF_!Ab<GBbI_oo-8?2Ba)%SX%ExHu2iPzH?P8xqJve7h;;u9Mnx(rb&7yfyt@^&3Pig^AB>Gg`#kBydDMv!id}Ud^837MN>S^`5FiyHOpRT~Y_p`}#c}GLq3SEWXn9+BF>eWe9ZJ7m2)CF6vE`%!wa>sX8u}v|siHpi@N6@;BiL7}sGANhn?Qq9vpYtcN*bhgOQo3UotUFaoB+0(6%s6VG5b5CJNl9E@T&eXSTmmiD9slTP@bFFDge%SCf5J_J#;mX1#luTD$lmuYD)=fu-+D9wLKf=LK<?xBh+DxG$1tGy8bS_n6j!+s`(ikmPwyjA3o_;OVcG~#_3l51ZklXESy!I7Z;0G*q`>&pzoM`=uDkIJpk7K09$`yEvZFbZ6WF6I>qbRH_d#(X^6`v9)h)aGPWF?USDmoix&$Mxt}fKmk+WpvsWF-9m45qYW~~>_&F`yFfCsh-5EHfKTYb;99l2>BZ9XbCbl2|I)ke+Gbr1lPjb14W0m5)E2Oir2JVU1q5fzHEOI3w08o)Zj5@l1CJ!&J)b;AtPTVxEZy_$A7Ij%);9`m-p8(9DSYqW4+wDlwJ~WZmU}4=iPRM6=G9f2DDN*?=VYBaLcO6=n`0sov>Ba1B_RgGKV&tEI5$%I3_={G+vP)4yu^`9)v*iD2S&lVNkS|mMIEAhbEY!X1e*oZqb_eX&l^4OLtgN=|>6K|=s<0+PcLe|cWc{<HYjnQG^IrB*UWFSY_$f<SH~LknO%wszwSz0z-g2BKy}san(|Y2dYL9sJ@blc`y~%XBB?b8~Up1>lZ;Th1Nz;Kcp-pPxciC686eUPkyGr&7J{?0qrsx>Zs8}r2Hsz;-mYlc*4ef>rlb@PEabmj2mI=k!C9-JMA(u!wXvUdaUyUqs9)mvg{j|GgyM-YpvL2rAvMq4l_Hf`w(1c6#q5l6XS>Osz)juo5v5^!b>K4UUJotF&c)B3YsZ0}vb<c;=r1l*@>}pU}WB4aECF(SDOF*s32`&Ekq>idLviEjMl~7lKR|Haws!Aq)DlRb?r2$3xZDDGJ$OW5(LHNY&xJG=Ft4{QN*cSOYodo{bF?y}Zg1<lMXntqb?MM;5kzL<K#nA|fR0icp&=DDyH59zFF0N&mM2|9On#}_LLC5y?BElY!&r`jb!JO`_E8mwZGxw!z!ETo=Sj2vN0{b;x3ZEX>>QMagk7slE*X~%H=!dg2$o)reWmqV?U<uUWLyLHioRQyyo!osZ^GFS*Ze$uZF67%&HuVbLR%aBNbun0vE-_KDNfRyacG;9o$Rc5f9*Q?QSrwy)L3y{me`X?Ux9f3VVL<h0@9!%}+s<kcDGzL~s;elITC441m#W5#0o--1e<`oy)pczrrmm}Xp4abpe_)%3*3N1FK?1gXRUOpQ9}HM6)v<*uTyBlo!p;A&v%Bpj_5IB}H|y7BW;)8SHJZ~0h;bNkdCX2ULvQERe~3xUwxZ(Zi(yrCc2^~rubGXJ%>&A1T9ZpvCN=VyepK>M759*7&-VchAQQT~D^4n{-`;sBVhe|{`)03X4es7}C`um@l^?uopi<;G30dyiIQ|~HaeYiTgqO2_-b*b%vS^2JSJyOmzn3x*hGIhAz3cmD1KPS8I!V4Sx0!vc<?E`OEPu#%>*#G$WX99T#|@1yivk4y(0X3fle->NDtF|g{y;>jH?m9fPc9Zo$%#xvfU>`2{|VH&&3xZJ&yE(nN)*0P8p&&z!rsi2W<GVb<S0y;(fZcp@3-eH+76zw)Xs5--gY@<0tlO6lE<@vO>@3=-Zh50N>CyZK^BQ*m`^B;QAz#zgGivybC}@mTiK0Vc=$n4a6Fpu#xiX=C%kLUxfJG<IR{~y+V)T)92j)Qocu;b?L^;nWJMrsEd3j$NiB0x^uNtx;U2z9$i-2`MpD_<ALshCO_8hRC{UnRC)!s_Tlb0NPBr2Z<Z_1++WwGy=L8Ww0w7FE=D-+aOqvmaOh5SRmCNOwAPt2~J+H7!66sd6oj|od&aODBF+zr@)<-SbR7%vbCa8b7d9;rDAu#3Kq}~bvIrgHL#4#Sd(Q@>0Afolb@pcD<$`5YS%7>Y5Vk#UOn{+7>L}ZJV1eF{%x2^O|g9o!9?t#VA?5H%KWEb#c&W-F!69?M$?DH0N=w5c;RjlUAhRncglszgk1I1oBZ_v7~ZjH7vZ$gU<8GC|Fjth1l*sG+7cxmjVNf3yn0%6SG<WPjeU64MWWuj9|E#Y4izXx?!{9YI=^T{9KrIMhlI;jT9`?a}k8WUh8yy_2=<R?vnFds;mEdN2Sjfr7jw|75R9?CKyVCy&cw_bS}{@PXgi?y@|jQaBokFSkAoSn3XDx<ZtRz+Y4U3rSitu$s~S}4gMiEh<z%JT7%wlY7$ggtU#^JZ5Ot6l>1NzAp9(q;#_!HLBpKh<T5BHM-~l5~)@HS%o4)&A-!8an)Zo*Gs+2P@&1^5g_<dPc8<KkI`Jg-i2nIw+4@j+tWZOkyTVfN#$=a099_brGHGh4D&!sZip&bO^ng=K8<pd<bzW&6##hdULxLm)gM`U&n-GbG$HAR5_v&9%f8qs-7c_HewkGc9TYr@{o*4GhpPn1Lle_udPGvs+PP+Nn<%AK|ekhaJDjLPkNYZRF*v(_wHIe5VkhYdCWu-3ZsEif4CM5TRf*1FWCrqzg`c9c(}Dx8piQie=YEr<@;XL4cC_gZx9cADm>usp7p{YT20r)tHVcr_RQ0zRKpkLsO1%x&yisSCuSutL8O02TK+-IM<q#VZ;{?|8vP;rf=neQG9}c~Gt<-4E7LQlAH!Tyz1J|CuvrpCQPH~#+DSS*CF~8A^wCMr{5&VpzG0ADs9O;-97aji!zd<zy3;Dk$ru%UQ3apq01#2omYK`wg32d89#?|CgIWN{KC2A>m;!S^ho3RQ*9VxTQyNczCwoF&>nqPdaBz0TF&IAJT5$@Bh`ZIGTs=r6PWiIp%CTD24~8Wm$6m+*3iDYRH=5hMnq6|L^Zi^-z1H-cA#Jr*{sT?^Ju!`aA^TLM2BRmL<eZhOymd;Utj&1rIjeVpCg^%hdlge8X-T3QWAo&1N-ROZ!0frkLq<E8a}-OWiaZ<&Tb9u(vB{AQ=jq-c7}apG5u)Hpo!Zml!|ondD<AZ$Hz~rxnXqWHX0tWdj`Nj}n-+&lM@Dp0VH!so9orf@&5pGjE4?rc64H}qO`Gn{Y{mFx#fR^mNqm2=JucH~FlD-Gmy8(covjRn;UM%Y_Zkof=1n307#nODI^Fs)gC7Ytug(>^ZUwFzM`<roq(k(bL;9HfZgp1C8}_1M>PIkxIw#jlw;>_lCOTJMY*xC~Ek-ehGF6NQSPE%xerZ_mmTV0XU$=gP*hr>)844Y%)UMxj9*eJQ!e_>{odhQzM)SKcKn#PSq~6+SIEiK2V1Vv;>Bu-7#@{aST_yi7MD4UCa`_qOdgLdHqcHCJp%sqPt;xNU{Nytf!SPU!Pm6r3nj^_g(W&hgu++~4VH-&VSyCGK1~Zm3H_#UU<*hXp6Hp(X<(P5?u<Dr32>MABFQd`i=74fmJ&L@uJ@%kJ+^a~PjwlO>4@AIk0J^CG?az1Pcg6GW;`GM^5NI3-c`EadHIFHV-K0)bS|BkP3>K|oqcofLG?!`~9$xuL5^oH5IpEd$1QQbKRuHZCgTzmRIup0^Fu~~l>)dQ*e@WBSZKqi|PW2FMu7qRMwWmCHb1iy^jho%tc2~q-uT&--(S2o*S`1K3f0db-@f74vCbzV)0GM{RCen)r>uI@~GDB>Z4hI^I#~5Q^G#+D&fo|^)f-ny1*#Y@A8QRtj`WJP$=(E&OzOz!@ppdt^HQEH)a7LxrS6&e(_qgB%E-b5Soq)KbEm$(DLJy4Bq78!8)i9X#AW#XNg(eNsAWEBbe7R-!{a$2i%Y{u^%@oUsjRq|h-mV;1*3huS?HavpGO4RAa7%q!KtsbDmr!M)orpYQd}D5Fop1h|tht>mhZ=^Wa`c*ye}j2L%9thcus0!e^)Y$^!R;}Kl|%3PP9Ecz`*_om`x^Fnz5;Kj_;uaZQ67V`UbLETsv)~BX&aBM_*dtQE8$(KU-Y+7Do%@et4KnSdM#+CW@w!VvF52W98B^CsbmGV*iu?V4HotH?CFO7a3}|YP-M>=hH*OdJQ1PNEfACg#MeJ8*y<{j=k=mq>Uj=ts6z->N;TnRk5#c7{a@uwk5z2tsfFW5y{8wRJnF2vrkNM#DJWKx$kC#&3dn-C!jb!H+`W*M)t3O?(diXjkv9&(8zmcRl~W`iwINp6o&<v=XM5GG+WUs>eM4)3uP)h#7ZN0WKkWTSu-u_T?73?aX<3qiw&&4pF0`j3e2=n&MlzNxtU^>E7dR*qwo2C=w3J|Ehl=)$sy!hiUq^w8E>09gYfTHxI$nJmM=N2kn`%2gx^k}NsW2twTvLxzuPOa5bX1}jgXJoWz|uslj&yiB8=Mzh)T^u&WlCFO9~`3;NADXgr^+9QcwRi?&7{=akL2A25~^v)`q4DO5&B<CKiH_Xl01PbMFe>=h2}z~LDVHdAeGA&=?;d4^(exAoFICvS!<)0u370?03iT!A@Ac{DZ{cnA(r$Hl3v6Ya%iFyT+pHdvpSbLrrK`om~w+y(NcAw%8PU-))tJVSzWaIb)Dj}ia8Q7#z#%bzVq6cV}hdG6x372R{&2stZT3Q&F}ghHI*wmFzM-h?h(WV9OA}aJ>#)$x0lv~)3cBNxYK@iDeB;DjdpwMvrAi_ZEjurV(Z#BTbqCG;LE*E``Nu)m*4L^4}X5*Hul2Hy*9kGm6!Hj$|Cp*UT^*8Yo!2w5$0!0sEe&z$329*ymxQ>WR7l3+q(YlRHOCn9lq7};*Xh3z`bPewU*MQ2(eE+j|qN=xIn~M2*<^5?-1?n#?&EtaN1C{^L%>=K3IP#a;Nh5(EU=0vSOm&e1^OPe|qfj(I>ryXMTC)q_*1hoDHEhC=*1fLwn9@iwh_n`w;wX+ukXgoEu$@Srqb>noulmj>Oj6eD78)Dk$|kn8hY9nWRQ8+G6MbD&{5NOo(b0?F(c+A}%*xqD*XO(<OqH;sOs7!9ObPoH4Z{JGouEw<_%tH^lD^Y+7xoAmof7MDVhpgn@11jHf~tBs0M!k`%ViRHUHEt=g8PN^eQzb#%1K%Ee+G^+h*~#0yTT;b+`q<|n>bOK?NnX-9oj5NfT93iZry)r&mVP$OwOLp@iI`V6DyPO4)@RCUZ%mFuv%VFB*a#dx+_j7S?o2^BSsZB?^QNnHXC&y<JNY)6#LmP-!Ek^|+E$7G4FmxMl-<!teIfce0zEa5sxMM8ZFbVY}h;eiiRTA_mI@lLhRDtkAC>I!`_H8o{w_>^c^Y3hlNap+c>+9-GSpQy8^%CCRg>0ChT`?KT67f&uOJb8kqk|LDSOfo{{6Q9ym_j&B4-rSy}q^s`~6V5sR{0|E}dHAq*<lpfh7dQ!_nDWmFIJQ7)7gHONqm>53)RRrh^$basy%brM53Y^icgrgL+Nnd91LP#<wRdjARG;CnzGEuJ&v&<BcGbmAk5++i2^^_yZ6wQ<`mVDC(Wu&J9ZqN9_mXjq642>neQgfHZvX@@4UMVDosB~l#0A!p-GWxf;yLGs>jAcg^n!j`Fnru8ol?uS+=gYu1JD-p_##9Vdm*~%Oznj@#RQ8j6tM06OG_J_sXAEkEnuxBh&bwCPgP-;APlJkm&+jY$B!)@Iks4<K5Ze{nU1mJaX(=8;}dbQ4lIUgKmxF>{6{T#dwJd8SX=J-8@<k`b$)!qrjp4B!Q9GgA7V@Xpf`?3Xak5rw9Y7A;&>OK8V1mc-8iZyo)?#h0=(pQ(?XQ`s+?i{`2?7YzX4RY6zK'),'Libraries/peggle2/rgx_golfatron.☾':strd('c$~dg-)q}e6n^(#aSH?8n<yiSVK9T&CU#8By4iI+7}%b1Z8`R4OF>dWX5E8BJ6N~TX4y*F*xD@YVbJwq&@oD35BDG2IY(DNtx|`w2^2~9$N9edo$sC-^YL&noS3XsW_&i7-y97}EO;{crTnc#e}yQF9ed8kx2&OO+cTF<=f}3=F`8T8@{YXMJUrlB>ssCJCvUxd`|8Ff7oFbcUuZhhy4~KECWOv7A5IK}q6zQs^KH@D?qSDpvXf~ydN>0cs{7ZuA+V*u58F7*FpT26#dk!3S8BwZSEyZ{$W!@{3ogHw7xIL|_nExU<r2P@guTfCi2|R<ALLVB`KZOi<(|lA@=On&-<4P=YPchRmVe1V5PVa03t$Hq+t^T%Kq6jOWa|G18HjREz5oFP#CaXFhGN!OkJ%e?suQP65eyv!93II((}*SZL8Gd;0@yi>SeE58!9#pC+Sl2l6qE4*gm)@!oz>xPw0nUAl~b|?tY@1IYHnnkcXDm{-_frDeYhL7kbW(nezsZB&o<}M&u1Mi3ep)&p%sSw>g`UPcbX!i*f<b&y%y&D4BB1On|kJ)hh%obvG8sr-nWwki$Jj06IdQ17w4(@R6u7&Nkw3R_Nwk49^l+cg0u!Tsh6-GPjz;nQ%{fYX+kAo?|N<$_F8MzuzWzi3MeALW<Fr^O#rX10^W`QZ{#m<cP+re$Q(20$nQG?%LOBs3Jk7@hM%_6_wtE6<#9~FfwcZ8e@&c8%r7z98F3$p;01&HG?fGmsHtG|0Mx-z9mq3&jcrF6l1;6^NK3$a5gAFlqKSww&7Tm;QvL&_EUI@zPl#yLk?9RQ&*2Unc7x+%(;7h-^4xUHCcqhdI00qovD0H^s=>d=yOrHGFX}V|t7MUxGuKoUQCmWAOz)OsMIdk>pCVGq>^?f3Z7{y*Yyr-dGV}2TRna_5!))N0K&svrg~B!YKz<`%^5EzfQM!)o*?8bNwuK2el^37`5x5o{^Z1HGq4Oo23@Mqye3GUZ{ik?yp386LLzI=A<>fj{-j~nUu~rDEG>H!|b)XS6MT-Rjb;vdu$+)kFOW{-;i0JQJC3}$$;LfH)lN&nw(6-Fr2-BH?`K9W4frdI@18aoYdnBLp0}&(>oLPvadmz8Myl_b-Gt+_qm|!E&)6La$ei<<%67%HFRGv@l%a}#vMOr&}>{EMcfxW_ZKV!Q_TW#9;I-3?R5H?uatDszwkTJOl=gCbNHoB{XD0jjCD6YUQX#@#_;=UPIFBkXaUQ1-1H%}z>uKYVcsXk>0-1zuarhk%qY(vNSItO<INL3DTL{dPCkCu#)(0^fOp-m_9A}eK3^+N5S>c_I<tVHFDksb%;4+N!A>^)|r<HoV^M1x`oce9lV7pdo@&k3ajPD72Hb)BRV=D@@oitBm66-iUd9d$ra)l;Pa>w>BXF8tInN2*(ApP7qtycPJCS~Diwr^6|)YG<Ehn#j~)=-L42tQ74^ZKaH_v@~j>(C?!JyVYuc|Knz()jsU^`O(b22|+nZrlpEJ{4z^@3-K?+IuM8'),'Libraries/Compiler/op_table.☾':strd('c$~FZTTdHD6n^)wm_9_an_87^XaY!n;1(6dfMq+WDzH|*tPzSY$X+TU^&wC~LeexO0fH1TaS~9H64W$+qFg1W&*V3-kA2Ed=$YBs@vOZDbBQI`*_m^`bD49QSxqC;<W^sQcrX&vGzA;_grQ{$#azO`UNn*|Boo<^qIwa=sz<9K9?|o9F=6OhVT?Wt#Zo<wLMmht{ywqiI_e0bp|c~pA$T++k<98!VXOokLu86PA}<yE!|-^(=WE~JdWY3`9AFaZw3gICGo3;x*+edxPM|R_%6A}uOBhD6Mij^&&6o6|fmNk{utx#i=Si8&dl8u=%j9(sCKkwB@<FX*<mjNxCV9|7pYvqL0+|H;9sxv!ERo5eQp%2|bY-BB*S(1T2OE4U05VQ^8B^h3UR6~OS7Cv?ARh&P)hboN-(krC=G?XJ&Y1AR{?;Zqq8XI^tvfY1vCeKAr&$p5`I{P$&K7|&e97nYWqiKYRI_N59W%c#k$;pL?+#f5*e<GHoYK$ETQbh;zIHK6h*8p<T@Ww27^TE0jhk{f$f>n5a55_c4!l>(CqR3(?8I7;W8oNZE48Nj8!2a{!<wA3uydcuJ1S#^?2s~z?@4lpJ{HJzfJgAN;Ap(rW6%}Z*!}>YWTbgHEa})>Eg#P0lwz)~Ajv16<TZeH69FtTM^y}Uf`hp#3I^uJbv|~A>GWHc(5Ij+SM2ejR#5VpId|v)hn9HFwOKKi6?Ubaxql=zUOjeKqlH7a$h1!mgr<p3OYI9Xtqfs=<2>=7(o%?r^B5jh972*R{V^I}cpx0@$`<!tf0^3*xc7c<9y*67l}(gNXfUiW_8o=Hkw3@>8g%!_q5?Hl?eI{6il!Cyv7)BQodII^9w~Pqe5Q1!gwYwKNL>O}Kox^&LPL6+R4D9QvRO~nk5%^bFj;9mgEVb4KWab&v}w+=!EG2=qXn)Q{n>b>ap-rfDcbDNmg*Vn_=FxM-2mah#GNVY1H_|-o|9CXkW^46sADeohLs7mDqu82cVUsdQ6{{oKPJ)BUr{&4i+MERBy)8R(z7L<H9t=cx0~%kRj_2jVMM9k2rs&NI(E>?bt@eGi9=ia&L*e{)i+@veZSbN`0X_qLtmFDT}v*jhf7qYtCm;T#P6z7#h_aQ|4KE2S|mXMr%>yqr#Gaus_IZ{ycsW-WG_=M+KIyDTDc<834#$P!AO<BL$@iFq%QoEY;!+DdqFHA7tm-PSxXSjh-^svCY;X*W#>nZ=X}f04zC`5Xuzl8cWUnyYHAbm+&sV>G;}2{J0XOfrp=ST6*paF{rrt|Z2?_d>UBNrywt3&k#D4HtyBy>7dMuC!cdvH4^8Y;;-OyenYnML_bDmO3x}n$mDjn%6?%>1m$BOWkn=$3g(_gTUY_yvh*;a5tM!3$m05k5BG<@`8hF(`_7)vw+WqRl?^#2>IB(=T<hI?&`I2=(^YhzToOW`>>2WTM+2H2505~oXuh)_C-67A9bS<>ZqTqFB8Bj!F>{Cunz&N2~rDn+=mlgG^bVevjU2k|%ju&PS>}-unrcg*TKptwAIZ_SZtSTyXe$WtNF;y75N}E6QI=uH9Qz1Fg^Q@|%I>kBmwj%AVA&ud*X9Pj({$S3FLctp8RAZ-XTWM;-q5?d)D=N+;wkBQ_ITlj54vA+UZHdP&buMK?4s^kdenY}la-JO$qm=Y6**G{QLtYjd;204dBE4PGG3Qi}=b1B$a!n^tD8&xyJnW>%q6IVrscdybw}lAbtWd*HQz8eUM;f6=Wb{ZwbY9Nxl0|RbvB#NRRzv|I$`=eu1Xd^VX~g3Thr6((1cTz|X(tZ-*<^L(thZpe=)*D3P!E<LamtULhWwDbd^x%y6q`(SUWM3+xj`{%5G$(J&R&>u4G>lV8b^fHqq#`ePQ$wi6x^DxBL|m2*JwI<32DB3SnfYU`QT@R>N(#78>PiMyF$HIUJ0Zl9~tO%zb~o{h8_2GdWX7CK6KPa8DD|@(OH}gV&+emb-2l+U=ZQ2D-UnN-z;XKj(4}P9sTa0)vGJ}6fxM-ccHI066H<N`ck&KX3oCjA4Jxl(!q}zbN2oI_VRzrk9W7s)o1*Z()@FC{mIw4@;&<Tk@^D!aU@oLsUJgqv7j8&UIddMR|{zaK_MSnK0DHgwO^cT{_0x9!RL4IMI3y7i|=x0M2m)dyMx%=dSh;FnadB%<%i~CWq)p+f6hs^wOJ#7o8E42JR_U`ZrfLdwl;J6#+T_Y*Th6xj56lUGJi>(voAua^Jy{C#cEQFQeq_N&Q<9$g4ZYJ+A;bb*@rx5SHBSH?AE#m2QI_*{+h^+>m|(ctt)g<yZCcYG>C`Cb)PQ*r7s%m;Zx?!OLKF|oOx&7SmPe>CtI<_)g2nJIW3p?{B66R&9_Ut6$)}G9ISpo`b(uVUG~glI-{!p1Mlj%MF'),'Libraries/Compiler/generate_operators.☾':strd('c$}SB>2B0k6#k#5Fp)<0UNFd>$&OM9NN5pIA_x*vm|C8(XEfC;(RhHQh>E0a3PlPbiBduW5y}EoX@NGPl;y|$*GlvmI#19?=((#si-RDL`1r18`ObIGH9j@s96feo*cccz=&#suyh7D+OaoQM{i<85R0BjvhvU#|bmrK}kyEEf9S5UvKc6r9Nn{%NVkP4i1598FA{`ysq8kJTU88s4_nmlR@gM^o2K;<oDf=C`QuPA1C$i3;wJa;wo3*oA^0ee@DW{~Qo{_Y*l+;p6OI=#()>4m_dbQN2rG72BTFPii>zCB}CAEG@tzSy7oYI=6w5BN^yo9sGDz~0a(`EV;gA*<!Evw&8WrUFH?G-|{r$-2xZYlI+bF!u1lVhwtAy~O?A=thgob=>6sjM8+mFX8kU$<PRr&kKT>kGl_Q!Dpm<z8K~C8xH?`YGAvC57O6wjATi7K=d#dlyQjNk_%|vSk|dF`c2WIRuEY->|R1s8XR^$XDHx^vXKjz?j~k>+BsD-BQMLS^GA<H(=!bnp>+?v3LjI)etcXIo;mU4?c&#qcF-Z27c3erg+W`7<7uh2fg6+6}>NJ&k^4Jif;2A#0+B)a9iJ6L1H;bjd}VL{X@+ltqRnb0^#yvSFn!2k7>wk!ks0zP#%PZ2QjYSx;iK@W7(N5RDZaE>W_Ayuc2`hk@~HzXw%en)HG=727)o)qp@#b5tsr)pe>Ea-cH!Pqr>xa#<*Jzd`G3clPeT`oUN2=ez_LNw8i5r6lcFY=Nvgbd}wqSV{{nuAJa$lXFA9F#?s8od!dn~ICQli5a|cKka%vgXH%FZOu)S>bce2M$2AWVG1&t#F#vEZI2I=(w(>}viYHGEVF<_)ebKTle~tykLe|H87)#PQlabmIof?GK1$vucGG?WPDI`ru#2g7<c)aA`c>~m^6l&f}*tUs3&sMQ4e`5Lr0P2})fWY#g<yqqS)s`#*v~$xKbXVy-2j>I&d=MHI0PSxG&rX#Zk>!HPQYL7Zl<-`o*N+?;#d6^Vu;^OoHRkKbgdGJpRjS0=S11e5{0?Ua`tbb2pZ`pMc#D{sNtQ>m5YRb%<m_n~K{#ioAOWw%<@H!&L%PvHK_SmchiQC=&g=GUrIe{~Qx!MqF3%6LQ6Ee+bH}HpiAsamfvu>ShksiNE)PPYF*(zji0qP9Z1!9FqKVHgOEwcqwMT1+zAK2U)*jOBmcP=xyhxc?lfxu>N*`$s-c_f|NTVN5kdU}ls2Sn%c#g@efa*oynG1zHdx)qri3K^WrmoRN`iq1KbNQ;KN7(ax8R<QsOd2`!mB@iv`XgNqGk_IAi$ty!1AX8W?yfI5+HvE?Gb6``vBh|YCp_y~Z|br+6|sh);S<;<tfkq6aVaaEE8~G&Wga4NH-;9uMYn;crnN;@n9jm0GjfDT|8=^ACC#qVO+8BxtH41Qgz6(hzy>UnOA-tBzaE<+Si6qJf>$1hM3}cd=dOm+n9JhN1I?39qIAYP2?iSG+{w6&Lz;su+;qY;CI^g3fyXg8my)KD0;9n6w4}3!k$kE5lF)9(7Ag%D$GwoIvF@4RjgUKnlD5MT*>d<jqM$1fBLX(b(?<eCyJb0oV+>YUA%QCNG*<l3+ME)sNkEgmp`bQd<aL>9Q4Gpqt#@9bixIprRRdLANz^CR8X(&d*@|XD3Nj%jGNJ0%E>z0~s3U40DAvNtr{-p$^x@@@2d$9ZUd8#g0%h4zxaIh&7All;Z4Olc3r7F`wv8nB&C{KbnHd?&`V+>ylNFj}C)<ve*9G70icW&H|9ZLWcq^yJhdaQuzt?u1W?Subix{&&7o)~()t}tg^)#D=Lc&)hb^x`gf=D|x4ycu6CK>yf9<LERv7VgjZL3P?sn7?ZSz1xI>_xQOGpJtn+v$d_Nyzw1^eRWTq_k;z7xpER)^YR@7AY5^rVZ)nt)aFFZ$#}gOyHc=H}MyhIHGDK(*3q($F4MAGJZ{QknWQWrol0;X4`4O3#uF>(Nt0l6IV`uyi@Rz(v=YtD{o~G6i>0}%WRY(<J~HY%PfU`CkN*;9OB~@xX{2Eor{J=W-q567Fu;ri{`r`rnVOD0)-X?d`@6dB4C%asq2SN98U!Qtt`ycAMSJ}f=;-xv93*IBn;up$B_c70aG&P>Kk{n@C&mx=HNe{$UZyBVmNIQQ*Y0v>Gs_t#%`EQ6Qvbjcb6j)SQk#oPF9-LXO}w>kryjlU7eU2knDF5ulm&-X~e;UiGcSd46OUi(7Dg(TfJZV!jNCpXO~eV4|t&vdwWqnNj3pqqflnZjDV4B6(Fot9IuiMS|O)k^yzsUi=&33sIe|f>Y}RQ+>TaN-1l&n#x<$%z&`D0jTI}V@ttX0GL4IH>RsYKy$H@YQ^*e_g7f7>z=Jjc*n$8ot^oih8!8R<X-L%$QRhoZewO67y(RjReI;rAMxnn<9vT{QhR?CDlV=<UN4`m71be{VLVJv2X@Y&qjO&v#o67_~rMZ!i{{cEAnIH'),'Libraries/Compiler/gram.data.☾':strd('c$~c&?{gE!^<Polcywpsj14xfVQvHjx04A3k4>7iI&pK7&PHSDq@3gcgXy?2aR@CQIcfs~xF#`i+>YTxlK|mEnQ><Fwcq%z`wRRh^u2w%d%Jg%WxiAc$=ltx@ArHAb`Qt-`R32JPoF*OOno$cVdmnj;~4XmTEVR}4D(3JNdIo;^!fCWRND4!zgBm`7j38Fr|@T`{uD0%G<ad!Ie+1-bIy5xFkF5aAzkZ=^al+o=tgNKMk(k<X-1(`DK}FwlymQ1q~-mM^)07S_lg?E?@!M-v(r=W5DqRhnk8r9N=YEhUOel(_u<)DLMT)goMOdS5zd@@&w1zE`w9|LLBtqRgkbx#XDmBye=ssKGB+|Y>H+M}PODQco0?Lm3N|x+)h+u#c0O>c&fxh$oMJGaZ#1jTMk>6uliJ_->KR`v)~Z!lGr~vDj7BqH%f8zzf8xPX$urpmB6)t3!6@|GOSbKUyyg(6(kKRXq+<Mc1;BE>i35Na>lT^ngXzHxZU72wz98n$&^+-G0>pXPKFJP55#T!9{TBnc6-EnVcKW29HZz2ceneAW_S_P~1DiYGK?b{xd7o2R|I7YH>lyM8Fl+>cA+ByMGaN7tE`_V>@COkkSt}LZ{>CXm;4mwJ_v>?4xh5qAt~QYv$;HT8EYMWRaXpQGNf{9{9b@+q$B+nZlJ8-=+Z6mYQ$$fEv-hee6;tDP0)t8#!b<fLOA6i-BPsZLD)H+h<hm3RqJkTp<*LT%_BVE#>wG0}F(k=(D>NzfL>q6hAukPbMY>=mHkUAsh$rq$Q5+yHTbd6exkZ5R$Q0Eg=Jj?z#v-;jV^L2isaa%`WfU0_ge<f#3aVuSVVjuLby*7sa^asp3pcm(1FT8_-Uj?_$wFch%4)dzU48(wsP!u5mK->x$5s_B4`_Nq&z|YOZ+41h?n;cOaX6kP8Wh%7<B_!e#o-8q+qa2C>v@dCbtFJxhg4e6opRHw>T!NVgsX~T4s}N|vpr<EAtWFU<a-z`eB$_Sm2cwXpc>V*zrEPs`1_|kaMT@Ej|6%23@UV&u(X646hv(iathS|sYdJVuCd*N2=fp*!6Fn{mSkEhmR?_z=*jXYEpEhdkxJ+8LsHKiG8xx3g|o46#Q}qTNvXAUfEi+>O(ntF><m#-lWhHY1Pa}yJYD3EN{ohTW{8y`k1TG*yDdBxl@cSlwl%Kp!*gvP%(Wfk+U5#!({z=r&Bal1G&*aNPNPyTddlg{krgaPY4F{_6xK3s{}qu7uVhk)rBxZ>)W5`&B#Qrdi$q-={BXWpt=9tD?Om1N;`~+TsvuEutAz$nEuytpEqH+g_{vbD8a1e5WKvdaEc4RGM8y$==K(<<N5keyPGDGXEPEeEx-;@?lF=G#@%DC61Lv{>x`G#=Htg+2X42fN5mF4vG*BGNxc1GexICO7i(eYYi}<6*N=?}^MWJB&ewsjjrXkxtISR-_b8_W!xv}5{4a;D?3Lt;zoKsG2);C56H(Q@Er4tiBkuN$G)ohFmZ{tjr65EOZ%4Zn}8r&oGz-xF-d4<XCZ`}Vk*ReP`Cm?rJLdPUDE};ntO-iUBp^}6oy~1c7`}97_auNMnP<1QG&h6X3CSr7bC9C7CZUfFC`N-g;CW&H;7^L2Wsu_2(x>vwsM|tZKIniWJ!%$Vjv`>hNy&_Qi1gSuWmXMXh!&LGU2Ul_wx!!bxd20Ub^pI%E(x)OFx4Kj%>Jwl$Y;HK^6sr|D0N7HbWxfFZ$rOi4#+uaUppih9XAxdmIk&87W(8|cVU0E+b$atuMSFAB9<k<iKM~eDUt<@jceH!Evr}}%W!GD+myPxQaNIaepv_&Tk$&<*gaS7L%E1qvgd9(v>&PBnBRFk#s}3BvlsjeL_X2ShXRFTqVzWVUp`3Y%Zg~aOWHsj!48rZ3Ve0|>$>Zfd*3=Ks(ttEU;ucTjWRzptWs~OuFu}wfN=|~Xi(cXAadAp>C5>q4%mp=Sly#dvl~sszN!fN2pCNX>CQaCxiFW1;^q<C{>{UvQ1OpZijDdp70<?R-6~h8;sjkHJBN~=2_K71Tbuy4;70~br-OREjRtahi2ig&!`^ygV?ud~qoXO`#M)R4aT<rot!xIQz{RqKHcX;mf@Ne@ObIHJAK4aMS+YA~qvr7bsnT%<8xr}WO=d*mArBlTB=5?kd_(bto$;b(K>^A}$AIaw;3<-HCmc*9x<Krs!utXTs&^?KMygT}F2~9+kMG4Kx$?-9=Mpq)-KHb-t#d<9D-UU{bqk=GRFH~W0)^Mh%;tQ9vPLw<$Fj$9b@%}W`Sgb=0k&k^)Llz5KS%6ZfrEolhXQ#A77heW}rcPqIFA4rwp}$kaj%>ZAYOfXeHVm7^d$hRiidSV^2B6~1Q;!|JTjO0|v7Y4!K@1_#5IAkT**yJ+5j~LeW0NStd6QV;tm&}5|B$!LLuN!Z5dBT!C#eMrwV(?%>{0GNB=MP3=|P-TOzlnX2Phg;FZO<j3Oghz8O_umB@o>d7zSPupj#-orRe0#nEdIzz@AbK`Jx*o{m7&{etrDLQtsr5BjN5N3$FZoufjXGco=)f#=<*Kp{T-P2uEDF`E9uQID7)bEg<%Ecz@&G=ldI*y8vwdDE3TFbXqSut?xVQpLN!kJFR=2)|Z|2Tb<UAoz{a+>nnj*m=xLK6-S^yg+}rJ)lWx#<y!-AoY^_s&Ku_S8{zgB;r49|a}3~Zh~aQ^C*1re9l6R!gXmj<{6qjYP0`7Vf0ke7<p&9+dzR1lYG}p+HU283?9e+x@gj<_`rawV0J9bu??9Lv%Riw5mtVp<%T^X^%u&neBJ_{q90?U9<VvVW+QA)6$q!EN1v(zQjxK*7ca$VFCm}ELf1aJAOvJ~Li1cLwbI_~So7WuiI>4Hz#x=U-8?3u(Mggs$K*<yXUkvD#!I}4bYR96Ba-5Fd<r#^z!6ai^8%Fk5+KOqg&nu=mgnIR%p}b&A#q|E~EqST<g%xpAEx9<&b?VY$0x@bahq~OXCcKGBdhzDQinW~}Yr0G2JAfNZb>W7=l8&@vD0HM;I;f8DT-w}@q|IjrB5~iC4$n+UL-gNoLgOS}3~XN#@yTxd`yLyPYC(6@j1WgP3xj<JnEzLwOQXuLq}Y}lrJU@5=r8F2^_qD6NI~MvnPU#a{pg!=x6=`OxHQS+wYmo3<OGD-0JmopRaPQZrCkAuu%jh@%kmmUx9%mbJQ^!W1uCgiyzB-d`MadR=63R`q$7MMLR*rHo`<-3xWVpzpTB+-4qIuzNGhtQiUQU_H#)BSAtRUKo`pWh3v^=XWc&1fN)0N)g}^N?&~&v{iq%1A8ku(4p$xQJd%JnP#NqcM-01qW5q!vo%~~}>E43ivgjn7DbZkuhj=*<`r(W1(5~=Xsf4JDaT3FEd&Qm*`O&Orc39b<~cnCJUkLi+XC>#`l`L~Kp?2-xn5f{#_*DKdfS%SHsi+dSe9Lxu`#k!Q8OKkE_FA)OAuDgNfOKj!{uIqf$Ewd&U6gXw^?=iQ&O9`FeUP%{GoNP1~PFWDnLLwrY{Ddc71cf!!brVyCmKblM#6(JD$xa_y&_pGu*?#BlL*_cXJ*Vj-+r68~L)YL%#rBtSc$LnZtUFGz{uX-Lz8kP!vppvJ;?Dl9g~d;9y6P|e+RR--v>_vF;Xd2`qX`$w{mspFNH6#=tl<B|!t1r%rPpgP`Ff3}_&+a6o96!j^}^VD'),'Libraries/Compiler/ast_to_py.☾':strd('c%0o^>vI!F693L$u~6mgtSu^%2p6J4+!5n@R7`LIp{~kywq$8dROqqUT?hN}DBc(n!pk^7AV3Hqyzj^h2!tx8>b~CJ5P!T+`4g^tUOW4cv@-s5s<I``&h-4IyQinSr#0=ho5oD5UTxQ$S|z9$^`_hQ0;BHRt+v;!H0u9wYOAKP*B)nXZ`-TM9((pS>VB|_&_ne2*p9yv+s03S+d8&w`%c>?rswSS>Vf0=X3p5%XirrdKCyC!X<G1~ciy~Z%U?#fy}5aGhdn$xviWTo#;CnDf<4tB_{^HOjlt*fwS`HT^cww)o-#^hgC3x#=_0YP=>)xF`>s<hL*rNU@bKoH1U`L9ZxeIr(%FfbVm|-IPH)D+PwS_bE`7n9{tUCow#93_?d^8UF>zu+9zOa(&EB)OmPY)@Z9d9#f*G$RNZmic8|UgyqsH4N-pS|l)A_>GYy45oX^758p754xyA{-13gXclym`uVDtlshrW$+fYNOQw(~IYPWPMtYdUT#QI1SnK;+kwx%b(xJo2J{Ij<}F7Y!LVw72i(*5(Tk!+ZF)?I$opa>He}Q=rJm$Mc})W&sX^Oz?+NFY`glJPSJU~K+I1*85nr?-B(`u=%Y=WHf|gmdhuZG+O<oc9v-AWzY1D5UYxXyAwx;!@kvho)mO#pK0C-81_wpMF~QzVW!dlzZ`i0B1dqz9;VN%fEgR;);|-EyOY=8*L#0*g(B;Kl{=L->WRH0vEvY>7$5a<XH6A-Gdik>9sBAExV}ym4wTg_qJ&aq#r2FW8cyJJQ(P4Uo9tCb5qsQr|u!m02&*@3v?`e95o}~-)99;x)U7#0%hnMJOkiZps6-4+oy-vTOH|V$YCjE}yqPOWCdY9g#_vr)rPx>$VkbX~ppg+=|=p*`=KB2$Rr}P<pZUTz!!&?x=@H^YLlSZXERjVM%`}Ay%zn>}L`y&03M4MqXm8t6HH-`(wbs$#LHgQcm#zrzx`#wnx*#UIuuZ)n>sv@B%5jOY{y-$E)=jp@5!$ZK5pXgm8KHL+NAmgtCN1q_e;mdFt->vW|pA=@TIaOh`fR}_%mNVkhbesGh2~o%urp#^0ZeOWx0tBEK8`;$x1>3}jKqnUHO|^}IYs}OhrH>U|5U|DnBkf%yW6PwS)@MKH*)!Dxgl~nb#_?a%)5udb!EDJemmb|8@c(EU0|uGRS&S7?z(|JwN5Jl!?f6yO54;rI0z`^9%!!Ga0iVqxR>Op%uonKnZIQ5Hufc<Z^l>N`r8`#6GV0TUE^Ky#on+sEg=|d(6B85Wnh!rVEd#BzA%`Gt=ysMK(sg*Y%%EP+8FS^=j6uUROkJU$gN`)nEypLb;z)&EL`X3Q-#+{pS^)eU+b_@PK{UdEfNAZjnlo)Uvo2UPyW$77JBN!n2PWfb&H!C1!=F`JWxxv-vfBwNLEsVj9(Fa^k!tQVMQ42RBh!$b;zYE;VBd@~ShL?Re=!e#$IOrj3?NM=J=BQ{C~7foJU^LJ#PNX8rp6ZuaF{r+z;Y__jZa$WRGb1E`6X#46u1xpDK{8G)C9P6?8(xxUw-@X(tj^ql@csw8Ti}6cd~!JTYuoi#Y?784P5#&`Va*cSz(2#NC2E*YQ}8^er4<|@X_Ni^(ma1poj*A(gd7+;!%#dZt|ODT1kRZNiWi;Bmo3Qo~GY2F{K+gROmZguWymGHEYwC#c2o6qAL?yL_p!ROyS0CaNa<LCIpxJIsJif2Il0{gB6P}suEiXY~_GyPi#fP_mv7JJymEbXrGyS9igX{aw&x@fR+XDKZgfe$MX!qouj|9_p{>tihPeU>I`R8PO}u?xjF%O;!WjT7bQ0MT+lw}rK`PVWR$D}UwhqTV!aGE)2JS>q@ZB&rlsvcT<joM1#b7aR!ALIe6f0%0^Bab)BFAMY2gU{`-}~zf$dhjO4HZPObQX;3izSba!mDwF+T@RPI&MzZhqR+Fr7YX8ek-qDoVA`HX7eqR+@FJnpU^X#u<X{dl!}<h$FvWKJ|0dI(9`J>5MP%{*5YQu;?Cr9HUtk#8xw63y;iXZ+ywfCh<_G!(|ebfzY`FurIlEx~Z92t5*Z)Iark($|~*;bxYTuI6lrK4xtkV&E=@!vT$Wn6Cw5Iec~ElKCa1r__df7SLBFK1F3rWje6A~g`9z5z18tZ%MNpC{=9|~ZQUY$C>#(8%8IxriWuvf=FTw7F~pyP0mS{M4f>3pf<bK;0JDySNJEVloTV@<HfmZOJJJeqiU7z`R+cAI^iz{}D#|lFLLGA^NIdR4x%?c68@r9hItEdq=dRT`?40loB{#TdxQ&U!^nf*Bf&?#^S$px|#obTL*!kP1QIEzFu0_TphZ39Zc+QAogGWrklxa$p$+*Be$&~8=1l&ihkm6uW5sOJh40kS9Ki?_!vsA{!J`70K9g*Fja1ZNsXZ`Eh%}Q6hPJaa*HZ|sD-kT>fTaexm-WpjB1jURED~Dv;*m977J^g%zFo?0sL9t^6VfZfxW2JOM_|(gValIcH7sa$U#QSyF<CctCZt1bEwslM8nA@Edo)65`&Njc5mL|izWWt!sNKJ+Lkz*hdyo!lze`ZRz>MEjQ2Ac)np%0G1@nUDs*>9ocg45<Cy&{fc5!G<U;Df8N2N-9BAy2`=mj0ZzHQd;y2DFKl%QGZQIgue5sHLV(k{p#`Et`G7H`zG96$^X$mq=VHhODs|V4_wqppFZOa2StzM*PUfXndSqwWj*?IwvM(`^d5t<5{-5z+lM)E0-B4?of7>lo4&Gpz%DtV8s&}2?s*Exng48&8QBA^XN-3`ac08Az2ol4{{X&{I}^<l451jl~wo06B;XMX++ZEQa)Cff|;J5Qs^U|N@kWoaM>qI{-1dgO{H8HmsPIas0S*o!sgAGQ0cWB5L}8!p1g^X3Go9!>mcDb&N+ou-P`i(+VFmt<@m-%c4>QG%Xb&_d^b;a=lJc?GIrPdA5^>*vJu=o5BO`CwTr=D-p;?gFMIwW7Bfc=fvmZw%ln-7xg7TF1(i8>CK4rg&X(r2&uM#WWpbFkSKlkGQO?8*7KI%D8dH%ObwfLk{}gfC^xOvC#;^l;NP8SRh{N7^XA|=Pqhkw`MkGgWM|u}yy^E7k*MnF(UrL$dL_cT-_R{>mY>bI}R63*fzE^KJMEWHBCIHs-3SZEfn2p4orgmje(D(|vi)6xwMLjStDZ|e=tWCDA<76l)MS}G>L`)b6UNhk?m876gBr~MkYDYIfCf-)tP4^{u8#zwY)ry9&ClAv(xC{o?r*&%U;)#-FaVK!RR==rOlDN81I3&chooeA~NNhi8kF%#$P)7ZN7IN*D1>!zMmyB(x^TIP@XYuh%<Z|N}vRW8SZLL(4&uF3g#+{QR^hVTk8#FkzTVnLL#9UguhURHVx-vr@y9~w%uEoHVS4gni?9}j5+*;oj5gT(SqIaNcje-n6VpH;M$mWzAJsvyqnu$&)B3@|TNXra#4EIZ{_{7Q_gYg0}EK+ke<ZCGcO;Ku1ug!|<I<1-+`c@@9)1alkRpNS+QHW+;vxN10RyDV}!E$D+j*EBJ9j_s><a;}@Ke;+SU&&?ld42i(qOeg^8irMcVFP^W=KFU`kdLR&KiMPB?I~=<h<eL+JS0?*3HOYLB`ngNp6z~58pd9$neW0FWxlMaN?8OXoh3iB`;PgWP9Rk9ae^-B88zjuWc6!79nySy64qZu3x#G`g^(yFLQ}}SA&ckg#!?e?wSKa6qJXHIl^=_xNVBHvrac!3bm-MNN0%rTN_4HdY^SIyxLfp)5=v^_3zJdKs9Ex^PhR<1vapMFKi=iaGlK?zsB|BI#T#5JdNVnlrLm$hu_RQ8PI+9cY{Tx=hEr+TPUM6U9ZP9AxUA?wIF|18763=>lv4`77{7=(d>81=4uVciR<KGW2!waK|JlzOis=X?E3vdnt!BGzKW%9_qh8LJ!flnZP{&jS@zB9^P3;@0=hDh1yI3ftw3gONV!0BN(=kg%9n&Vfl1U^^SZ?O7zAh_;JN%@Txo$86byb-p5%n9@^BN&mnh5K%J!f~l-6Eqo!wpLjnNt3QjqvFby`Y_8WEA<&%OOX@Vj~wt2zJf|hdoiGI6gX#&nLy^a+zQ30v2m>a#gQ>avu(ks^&cUhJ_rP3?JdJq8f$+Lh@{(&5A1*x?^j&(y)ed0R(uSYwEpT?jwyB#TIpkQ{yO~h`l(7dMjw#zE=e>(QMHoeINj(D4N#{P3dgXiq0xsbk*%NXF$<n0?9H!-K$6LosuKyN&2AQSt4VKQ5TNuQU@+aJ#vT=a3ln<T=fLokhe$)`MaICIlN=pZ$(^_bj^$$!b0sdgOE^E?b$fafuRS%ClD*R;-FoLR9n)c&4`lmH5H}cq#VA&fboU-4Nug);pNd$wnxSOOjfmpE7I_KdM1-2R!bNi_f`~dgr&t4mTD%X7fXwhrR!cAqSE9@Oq(-W<-Eql?a2$V__4&!ww}HC&I}`l9@UEsR29&m?d78)I3o_vC^vcSnZO34S8v%(bmnysc-zeWKN4#TUE&Ug61(Qa$%CVXE4*WC`lU4*h=r^Uv4AaXkgKZyHG9qpvV;33y+RU4iYol)OUHv9mJuoW=SGW(#tuBkDGQgh)do_nO4G4FsCd3?^&A(ziB1}m7%^PfbiL8AWrO`*yW#luRK>4Xbw`kN`u)M6DB}XRmSuvYAmSD2GRz_F9RK-GJmzHn%wdvDZz$(8bhvNO1=5GB#uYVe=&k=)TE<+wmvfbnEkGqwQ5czvbBS9E#SiA`-H6_bF&1gQUToL!(2?mx&tG_81&L6NL|+gN@5X;>3KO!gfj5`vDi>72n?ZA?#R!^VbivzYD-f1(E=!jfBkT>dA11-Ac|Dv!Y!Gv}U2{qkEm4Jl`*v?@rir8=AS)MMUk|b=$35oh-QX>oZxq&>=rJFLO^Eror{R?&t47f0dQ6WHv17~;&ug=T$ejz`18kg6_15myhJb-kk%0Oktv&L0{N?Qq+a}ttZHcM&FNBZkGkXG2m??vEV(uEj`ZD-$S^onRIt66')})
__dir__=(__file__:=áÌî(moon_dir/'/home/ganer/Projects/Moon_BETA/Libraries/Compiler/main.☾')).parent
from sys import stdin as ÂÐðþáÐâ
from time import time as áÏÖ
from subprocess import Popen
__ÄÊIMPORT__('text_format', globals(), '')
(ÄÊPSH(__ÄÊIMPORT__('to_ast', globals(), '')), __ÄÊADDGLOBALS_CLEAN__(ÄÊPKE(), globals()), ÄÊPOP())[-1]
(ÄÊPSH(__ÄÊIMPORT__('ast_to_py', globals(), '')), __ÄÊADDGLOBALS_CLEAN__(ÄÊPKE(), globals()), ÄÊPOP())[-1]
(ÄÊPSH(__ÄÊIMPORT__('tree', globals(), '')), __ÄÊADDGLOBALS_CLEAN__(ÄÊPKE(), globals()), ÄÊPOP())[-1]
(IDENT := 'ι')
(BASE := ÂÞÅCAT('/home/ganer/Projects/Moon_BETA', áÌî))
(TMP := mkd('/tmp/%s' % (IDENT,)))
(áÑð := ÂÑÖ()(show_preast=False, show_ast=False, show_py_ast=False, dbg_parser=0))
(header_com := ÁØÿþÁÙÇ(lambda ÂîÓ, ÂîÒ: ÐÌü(getattr(ð(ÂîÓ, '%s.☾' % (ÂîÒ,)), 'resolve')))(ð(BASE, 'Header'), ÄÝöÞ(ÐØó(ð(BASE, 'Header/builtins')))))
(pathlib_import := ('from pathlib import Path as %s\nmoon_dir = %s(%s)' % (PEV('𝐩'), PEV('𝐩'), ÂÞÅCAT(ÂÞÅCAT(BASE, ÁÜÙ), repr))))
(to_py := (lambda áÖï, *áÑË, **áÑÕ: lambda *áÑË, **áÑÕ: ast_to_py(*áÑË, áÖï=áÖï, **áÑÕ)))
(moon_to_py := (lambda áÖï, áÖÝ={}, áÏè={}: c[h] if (h := sha(áÖï, áÖÝ, áÏè)) in (c := getattr(moon_to_py, 'áÐñ')) else (ÄÊPSH(c), ÄÊPSH(h), ÄÊPSH(to_py(áÖï)(to_ast(áÖï, **áÖÝ), **{'reparse': True, **áÏè})), setitem(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3]))
(ÄÊPSH(moon_to_py), ÄÊPSH('áÐñ'), ÄÊPSH({}), setattr(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3]

def moon_to_py_debug(áÖï, show_ast=True, show_out=True, show_out_no_rename=False, show_preast=False, show_in=False, **áÑÕ):
    if show_in:
        Âçß(BOX(title('IN', show_code(áÖï))))
    (ÄÕÒü := to_ast(áÖï, dbg_show_gram_tree=show_preast, **áÑÕ))
    if show_ast:
        áÍñþáÍñ(ÄÕÒü, 'AST')
    (áÕÃ := to_py(áÖï)(ÐÌü(getattr(ÄÕÒü, 'cpr')), reparse=True))
    if show_out_no_rename:
        Âçß(BOX(title('OUT', show_code(áÕÃ))))
    if show_out:
        Âçß(BOX(title('OUT', show_code(to_py(áÖï)(ÐÌü(getattr(ÄÕÒü, 'cpr')), no_rename_vars=True)))))
    return áÕÃ
(decorate_code := (lambda áÖï, áÖý: '__dir__=(__file__:=%s(moon_dir/%s)).parent\n%s' % (PEV('𝐩'), repr(ÂÞÅCAT(áÖý, ÁÜÙ)), áÖï)))

def compile_code(áÖï, áÖý=None):
    if áÖý is True:
        (ÄÊPSH((ÂÞÅCAT(áÖï, ÐØó), áÖï)), ((áÖï := ÄÊPKE(0)[0]), (áÖý := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    (áÕÃ := moon_to_py(áÖï))
    if áÖý is not None:
        (ÄÊPSH(áÕÃ), ÄÊPSH(ÂÞÅCAT(ÄÊPKE(0), ÄÊCUR((1,), {}, decorate_code, ÂýÃ, (ÄÊPSH(áÖý), ÄÊPSH(ÂÞÅCAT(ÄÊPKE(0), áÌî)), (áÖý := ÄÊPKE(0)), ÄÊDEL(2))[2]))), (áÕÃ := ÄÊPKE(0)), ÄÊDEL(2))[2]
    return áÕÃ
(compile_files := (lambda F: Âøî(ÐôÅ(F, lambda ÂîÓ: Âåß((áÕÃ := compile_code((áÖï := ÂÞÅCAT(ÂîÓ, ÐØó)), ÂîÓ)), Âçß('Compiled %s %s ⭢ %s' % (MOD(ÄÕéý, áØÁ=dotrim)(ÂÞÅCAT(ÂîÓ, ÁÜÙ), 25), MOD(ÄÕéý, áØÁ=dotrim)(MOD(ÄÔéÄ, áØÁ=áÖï)('\n', '𝗻'), 35), MOD(ÄÕéý, áØÁ=dotrim)(MOD(ÄÔéÄ, áØÁ=áÕÃ)('\n', '𝗻'), 35))))), '\n')))

def generate_bootstrap(dest=ÂÞÅCAT('/tmp/bootstrap.py', áÌî)):
    (ÄÊPSH(PL_FORK(compile_code, __file__, True)), ((_ := ÄÊPKE(0)[0]), (Æå := ÄÊPKE(0)[1])), ÄÊDEL(1))[1]
    (pyc := ('%s\n%s\n%s\n%s' % (pathlib_import, ÂÞÅCAT(header_com, compile_files), ÐÌü(dump_cached_imports), ÐÌü(Æå))))
    if dest:
        ÐØì(dest, pyc)
    return pyc

def update_importer():
    ÐÌü(getattr(TP_CACHE, 'clear'))
    (reimps := ÂÚü())
    for k, v in [*__ÄÊIMPORTS__]:
        if not (getattr(v, 'hardcoded') or getattr(v, 'name') == 'Compiler'):
            continue
        if ÐÌü(getattr((f := getattr(v, '__file__')), 'is_file')):
            getattr(reimps, 'append')(f)
        getattr(__ÄÊIMPORTS__, 'pop')(k)
    ËãÂ(ÐôÅ(reimps, lambda ÂîÓ: Âåß((sha((c := ÂÞÅCAT(ÂîÓ, ÐØó)), {}, {}), ÂÞÅCAT(c, moon_to_py)), Âçß('Transpiledddd %s' % (ÂîÓ,)))), lambda x, y: (ÄÊPSH(getattr(moon_to_py, 'áÐñ')), ÄÊPSH(x), ÄÊPSH(y), setitem(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3])
    print('importing lol')
    __ÄÊIMPORT__('Compiler', globals(), '')
    TRANSPILE_REF(moon_to_py)

def moon_cli():
    import traceback, readline
    (ns := globals())
    (ÄÊPSH(ns), ÄÊPSH('globals'), ÄÊPSH(lambda: ns), setitem(ÄÊPKE(2), ÄÊPKE(1), ÄÊPKE(0)), ÄÊDEL(3))[3]
    (pfx := Åøþáüì('✝ ', 'f0a', rl=True))
    while True:
        (áÖï := ÂÞÅCAT(pfx, input))
        if not áÖï:
            Âçß('God is good!')
        elif áÖï == 'clear':
            getattr(os, 'system')('clear')
        else:
            Âçß('%s\x1b[1A%s\x1b[K' % (pfx, ÂÞÅCAT(áÖï, __highlighter__)))
            (áÕÃ := compile_code(áÖï))
            Âçß(ÂÞÅCAT(ÂÞÅCAT(áÕÃ, VEP), __highlighter__))
            try:
                Âçß(ÄÕôñ(áÕÃ, ns=ns, native=True, Æå=eval, ret=True))
            except:
                try:
                    ÄÕôñ(áÕÃ, ns=ns, native=True, Æå=exec, ret=True)
                except áÍÚ as Ïã:
                    Âçß(Âøî(ÂÞÅCAT(Ïã, getattr(traceback, 'format_exception')), ÁØã))

def transpiler_cli(*áÒø):
    (show_docs := (lambda: Âçß('Usage: e <str_to_encode>\n       d <str_to_decode>\n       b <boostrap_dest>\n       B <boostrap_dest> (updates compiler)\n       o <file_in> <file_out?stdout> (header ✗)\n       O <file_in> <file_out?stdout> (header ✓)\n       r <code_to_run>               (header ✗)\n       R <code_to_run>               (header ✓)')))
    if ãÊú(áÒø):
        (ÄÊPSH(áÒø), ((m := ÄÊPKE(0)[0]), *(áÒø := ÄÊPKE(0)[slice(1, None, None)])), ÄÊDEL(1))[1]
        (Æå := (moon_to_py_debug if 'a' in m else moon_to_py))
        if 'e' in m:
            ÁØò(lambda ÂîÓ: Âçß('%s ⟶ %s' % (ÂîÓ, PEV(ÂîÓ))))(áÒø)
        elif 'd' in m:
            ÁØò(lambda ÂîÓ: Âçß('%s ⟶ %s' % (ÂîÓ, VEP(ÂîÓ))))(áÒø)
        elif 'b' in m:
            generate_bootstrap(ÂÞÅCAT(áÒø[0], áÌî))
        elif 'B' in m:
            ÐÌü(update_importer)
            Âçß(Åøþáüì('Reloaded frozen imports!', 'f0f'))
            generate_bootstrap(ÂÞÅCAT(áÒø[0], áÌî))
            Âçß(Åøþáüì('Generated bootstrap!', 'f0f'))
        elif 'o' in m:
            ÐôÅ(Ááú(áÒø, [0, 1, 2]), lambda x: ÂÞÅCAT(compile_code(ÂÞÅCAT(x[0], ÐØó)), ÄÊCUR((2,), {}, ÐØì, x[1], ÂýÃ) if x[1] else Âçß))
        elif 'O' in m:
            ÐØì(áÒø[-1], compile_files(header_com) + ÂîÊ(Áÿú(áÒø[slice(None, -1)], Âåæ(Æå, ÐØó)), '\n'))
        elif 'r' in m:
            ÂÞÅCAT(Æå(Âøî(áÒø, ' ')), exec)
        elif 'R' in m:
            ÂÞÅCAT(pathlib_import + '\n' + compile_files(header_com) + '\n' + Æå(Âøî(áÒø, ' ')), ÄÊCUR((1,), {}, exec, ÂýÃ, {}))
        elif 'D' in m:
            while True:
                Âçß(ÂÞÅCAT(ÂÞÅCAT(ÐÌü(input), VEP), __highlighter__))
        elif 'h' in m:
            ÐÌü(show_docs)
        else:
            ÂåÔ(Âçß('Invalid mode(s): %s' % (m,)), ÐÌü(show_docs))
    else:
        ÐÌü(moon_cli)
__ÄÊADD_EXPORTS__(globals(), ('moon_to_py', moon_to_py), ('moon_to_py_debug', moon_to_py_debug), ('compile_files', compile_files), ('generate_bootstrap', generate_bootstrap), ('transpiler_cli', transpiler_cli), ('moon_cli', moon_cli), ('update_importer', update_importer))
TRANSPILE_REF(moon_to_py)
if __name__ == '__main__':
    transpiler_cli(*áÑË[slice(1, None)])